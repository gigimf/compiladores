# CP3 — Giovana (AST + Visitor)

Entrega do Checkpoint 3 sobre a mesma gramática LL(1) e o mesmo scanner do CP1.

## Estrutura

- `src/` — `Scanner.java`, `Token.java`, `TipoToken.java` (CP1, hashes em `cp1-sha256.txt`), `Parser.java`, `ParseResult.java`, `Main.java`
- `src/ast/` — nós da AST (pacote default, compatível com o scanner)
- `src/visitor/` — `Visitor`, `TreePrinter`, `SourcePrinter`
- `test/` — `ParserTest` (regressão CP2), `AstTest`, `TreeDump`, `esperado/`
- `ast-design.md` — hierarquia, mapeamento e formato do impressor
- `grammar.bnf` — gramática do CP2 (inalterada)

## Compilar e testar

```bash
cd cp3-giovana
# Scanner/Token/TipoToken devem ser byte-a-byte iguais ao CP1 (hashes em cp1-sha256.txt)
cp ../cp2giovana/src/Scanner.java ../cp2giovana/src/Token.java ../cp2giovana/src/TipoToken.java src/
mkdir -p out
javac --release 17 -encoding UTF-8 -d out $(find src test -name '*.java')
java -cp out ParserTest
# Se AstTest falhar nas árvores: regenere test/esperado a partir do impressor e revise
java -cp out GenEsperado
java -cp out AstTest
python tools/verify_all.py
```

## Utilitários

- Impressão da AST: `java -cp out TreeDump "int x = a + b;" > /tmp/tree.txt`
- Parse + veredito: `java -cp out Main examples/01-types.smol`

Se `AstTest` falhar só em `@L…C…`, regenere o trecho com `TreeDump` e ajuste `test/esperado/*.txt` (colunas dependem do lexema).
