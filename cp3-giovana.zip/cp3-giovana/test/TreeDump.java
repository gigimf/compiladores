/** Utility to print tree output while authoring test/esperado files. */
public class TreeDump {
    public static void main(String[] args) {
        String source = args.length > 0 ? args[0] : "int x = a + b * c;";
        Parser parser = new Parser(new Scanner(source).scanTokens());
        ParseResult result = parser.parseWithAst();
        if (!result.isValid()) {
            parser.getErros().forEach(System.out::println);
            System.exit(1);
        }
        ProgramNode program = result.getProgram();
        System.out.print(new TreePrinter().print(program));
    }
}
