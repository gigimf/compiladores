import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;

/**
 * Regenerates test/esperado/*.txt from TreePrinter (run once after changing parser/printer).
 * For authoring: review output, then keep as hand-verified expected files.
 */
public class GenEsperado {
    private static final Path OUT = Path.of("test", "esperado");
    private static final TreePrinter TREE = new TreePrinter();

    public static void main(String[] args) throws IOException {
        Files.createDirectories(OUT);
        write("five-types",
                "int count = 3; double rate <- 2.5; bool active = true; char letter = 'a'; string message = \"hello\";");
        write("control-flow",
                "main() { if (true) { int x = 1; } else { x = 0; } while (x < 2) { x <- x + 1; } }");
        write("functions",
                "int f(int a) { return a; } p() { return; } main() { int x = f(1); p(); }");
        write("prec-add-mul", "int x = a + b * c;");
        write("prec-sub-left", "int x = a - b - c;");
        write("prec-parens", "int x = a - (b - c);");
        write("parens-redundant", "int x = (((a)));");
        write("parens-plain", "int x = a;");
        System.out.println("Wrote " + OUT.toAbsolutePath());
    }

    private static void write(String basename, String source) throws IOException {
        Parser parser = new Parser(new Scanner(source).scanTokens());
        ParseResult result = parser.parseWithAst();
        if (!result.isValid()) {
            throw new AssertionError(basename + ": " + parser.getErros());
        }
        String tree = TREE.print(result.getProgram()) + "\n";
        Path file = OUT.resolve(basename + ".txt");
        Files.writeString(file, tree, StandardCharsets.UTF_8);
        System.out.println("  " + file);
    }
}
