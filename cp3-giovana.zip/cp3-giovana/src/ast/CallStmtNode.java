import java.util.List;

public final class CallStmtNode extends Node {
    private final String name;
    private final List<Node> arguments;

    public CallStmtNode(String name, List<Node> arguments, int linha, int coluna) {
        super(linha, coluna);
        this.name = name;
        this.arguments = List.copyOf(arguments);
    }

    public String getName() {
        return name;
    }

    public List<Node> getArguments() {
        return arguments;
    }

    @Override
    public <T> T accept(Visitor<T> visitor) {
        return visitor.visitCallStmt(this);
    }
}
