public final class BoolLitNode extends Node {
    private final boolean value;

    public BoolLitNode(boolean value, int linha, int coluna) {
        super(linha, coluna);
        this.value = value;
    }

    public boolean getValue() {
        return value;
    }

    @Override
    public <T> T accept(Visitor<T> visitor) {
        return visitor.visitBoolLit(this);
    }
}
