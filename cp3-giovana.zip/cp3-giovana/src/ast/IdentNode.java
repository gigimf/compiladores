public final class IdentNode extends Node {
    private final String name;

    public IdentNode(String name, int linha, int coluna) {
        super(linha, coluna);
        this.name = name;
    }

    public String getName() {
        return name;
    }

    @Override
    public <T> T accept(Visitor<T> visitor) {
        return visitor.visitIdent(this);
    }
}
