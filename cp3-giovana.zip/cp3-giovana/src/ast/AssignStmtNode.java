public final class AssignStmtNode extends Node {
    private final String name;
    private final AssignOp operator;
    private final Node expression;

    public AssignStmtNode(String name, AssignOp operator, Node expression, int linha, int coluna) {
        super(linha, coluna);
        this.name = name;
        this.operator = operator;
        this.expression = expression;
    }

    public String getName() {
        return name;
    }

    public AssignOp getOperator() {
        return operator;
    }

    public Node getExpression() {
        return expression;
    }

    @Override
    public <T> T accept(Visitor<T> visitor) {
        return visitor.visitAssignStmt(this);
    }
}
