public final class UnaryOpNode extends Node {
    private final TipoToken operator;
    private final Node operand;

    public UnaryOpNode(TipoToken operator, Node operand, int linha, int coluna) {
        super(linha, coluna);
        this.operator = operator;
        this.operand = operand;
    }

    public TipoToken getOperator() {
        return operator;
    }

    public Node getOperand() {
        return operand;
    }

    @Override
    public <T> T accept(Visitor<T> visitor) {
        return visitor.visitUnaryOp(this);
    }
}
