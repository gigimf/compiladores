public final class BinOpNode extends Node {
    private final TipoToken operator;
    private final Node left;
    private final Node right;

    public BinOpNode(TipoToken operator, Node left, Node right, int linha, int coluna) {
        super(linha, coluna);
        this.operator = operator;
        this.left = left;
        this.right = right;
    }

    public TipoToken getOperator() {
        return operator;
    }

    public Node getLeft() {
        return left;
    }

    public Node getRight() {
        return right;
    }

    @Override
    public <T> T accept(Visitor<T> visitor) {
        return visitor.visitBinOp(this);
    }
}
