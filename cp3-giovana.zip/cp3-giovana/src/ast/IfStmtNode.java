public final class IfStmtNode extends Node {
    private final Node condition;
    private final BlockNode thenBranch;
    private final BlockNode elseBranch;

    public IfStmtNode(Node condition, BlockNode thenBranch, BlockNode elseBranch, int linha, int coluna) {
        super(linha, coluna);
        this.condition = condition;
        this.thenBranch = thenBranch;
        this.elseBranch = elseBranch;
    }

    public Node getCondition() {
        return condition;
    }

    public BlockNode getThenBranch() {
        return thenBranch;
    }

    public BlockNode getElseBranch() {
        return elseBranch;
    }

    public boolean hasElse() {
        return elseBranch != null;
    }

    @Override
    public <T> T accept(Visitor<T> visitor) {
        return visitor.visitIfStmt(this);
    }
}
