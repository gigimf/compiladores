public final class StringLitNode extends Node {
    private final String lexeme;

    public StringLitNode(String lexeme, int linha, int coluna) {
        super(linha, coluna);
        this.lexeme = lexeme;
    }

    public String getLexeme() {
        return lexeme;
    }

    @Override
    public <T> T accept(Visitor<T> visitor) {
        return visitor.visitStringLit(this);
    }
}
