public final class FloatLitNode extends Node {
    private final String lexeme;

    public FloatLitNode(String lexeme, int linha, int coluna) {
        super(linha, coluna);
        this.lexeme = lexeme;
    }

    public String getLexeme() {
        return lexeme;
    }

    @Override
    public <T> T accept(Visitor<T> visitor) {
        return visitor.visitFloatLit(this);
    }
}
