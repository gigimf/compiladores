import java.util.List;

public final class FuncDeclNode extends Node {
    private final TypeKind returnType;
    private final String name;
    private final List<ParamNode> parameters;
    private final BlockNode body;

    public FuncDeclNode(TypeKind returnType, String name, List<ParamNode> parameters, BlockNode body,
                        int linha, int coluna) {
        super(linha, coluna);
        this.returnType = returnType;
        this.name = name;
        this.parameters = List.copyOf(parameters);
        this.body = body;
    }

    public TypeKind getReturnType() {
        return returnType;
    }

    public String getName() {
        return name;
    }

    public List<ParamNode> getParameters() {
        return parameters;
    }

    public BlockNode getBody() {
        return body;
    }

    @Override
    public <T> T accept(Visitor<T> visitor) {
        return visitor.visitFuncDecl(this);
    }
}
