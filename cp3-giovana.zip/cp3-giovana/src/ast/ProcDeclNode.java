import java.util.List;

public final class ProcDeclNode extends Node {
    private final String name;
    private final List<ParamNode> parameters;
    private final BlockNode body;

    public ProcDeclNode(String name, List<ParamNode> parameters, BlockNode body, int linha, int coluna) {
        super(linha, coluna);
        this.name = name;
        this.parameters = List.copyOf(parameters);
        this.body = body;
    }

    public String getName() {
        return name;
    }

    public List<ParamNode> getParameters() {
        return parameters;
    }

    public BlockNode getBody() {
        return body;
    }

    @Override
    public <T> T accept(Visitor<T> visitor) {
        return visitor.visitProcDecl(this);
    }
}
