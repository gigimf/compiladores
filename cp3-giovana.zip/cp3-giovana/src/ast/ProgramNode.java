import java.util.List;

public final class ProgramNode extends Node {
    private final List<Node> declarations;

    public ProgramNode(List<Node> declarations, int linha, int coluna) {
        super(linha, coluna);
        this.declarations = List.copyOf(declarations);
    }

    public List<Node> getDeclarations() {
        return declarations;
    }

    @Override
    public <T> T accept(Visitor<T> visitor) {
        return visitor.visitProgram(this);
    }
}
