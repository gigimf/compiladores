public abstract class Node {
    private final int linha;
    private final int coluna;

    protected Node(int linha, int coluna) {
        this.linha = linha;
        this.coluna = coluna;
    }

    public int getLinha() {
        return linha;
    }

    public int getColuna() {
        return coluna;
    }

    public abstract <T> T accept(Visitor<T> visitor);
}
