public final class WhileStmtNode extends Node {
    private final Node condition;
    private final BlockNode body;

    public WhileStmtNode(Node condition, BlockNode body, int linha, int coluna) {
        super(linha, coluna);
        this.condition = condition;
        this.body = body;
    }

    public Node getCondition() {
        return condition;
    }

    public BlockNode getBody() {
        return body;
    }

    @Override
    public <T> T accept(Visitor<T> visitor) {
        return visitor.visitWhileStmt(this);
    }
}
