public enum TypeKind {
    INT, DOUBLE, BOOL, CHAR, STRING;

    public static TypeKind fromToken(TipoToken token) {
        return switch (token) {
            case INT -> INT;
            case DOUBLE -> DOUBLE;
            case BOOL -> BOOL;
            case CHAR -> CHAR;
            case STRING_TYPE -> STRING;
            default -> throw new IllegalArgumentException("not a type token: " + token);
        };
    }

    public String keyword() {
        return switch (this) {
            case INT -> "int";
            case DOUBLE -> "double";
            case BOOL -> "bool";
            case CHAR -> "char";
            case STRING -> "string";
        };
    }
}
