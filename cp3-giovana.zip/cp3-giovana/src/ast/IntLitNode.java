public final class IntLitNode extends Node {
    private final String lexeme;

    public IntLitNode(String lexeme, int linha, int coluna) {
        super(linha, coluna);
        this.lexeme = lexeme;
    }

    public String getLexeme() {
        return lexeme;
    }

    @Override
    public <T> T accept(Visitor<T> visitor) {
        return visitor.visitIntLit(this);
    }
}
