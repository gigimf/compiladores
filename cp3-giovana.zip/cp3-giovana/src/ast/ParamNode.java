public final class ParamNode extends Node {
    private final TypeKind type;
    private final String name;

    public ParamNode(TypeKind type, String name, int linha, int coluna) {
        super(linha, coluna);
        this.type = type;
        this.name = name;
    }

    public TypeKind getType() {
        return type;
    }

    public String getName() {
        return name;
    }

    @Override
    public <T> T accept(Visitor<T> visitor) {
        return visitor.visitParam(this);
    }
}
