import java.util.List;

public final class BlockNode extends Node {
    private final List<Node> statements;

    public BlockNode(List<Node> statements, int linha, int coluna) {
        super(linha, coluna);
        this.statements = List.copyOf(statements);
    }

    public List<Node> getStatements() {
        return statements;
    }

    @Override
    public <T> T accept(Visitor<T> visitor) {
        return visitor.visitBlock(this);
    }
}
