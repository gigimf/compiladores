public final class VarDeclNode extends Node {
    private final TypeKind type;
    private final String name;
    private final AssignOp assignOp;
    private final Node initializer;

    public VarDeclNode(TypeKind type, String name, AssignOp assignOp, Node initializer, int linha, int coluna) {
        super(linha, coluna);
        this.type = type;
        this.name = name;
        this.assignOp = assignOp;
        this.initializer = initializer;
    }

    public TypeKind getType() {
        return type;
    }

    public String getName() {
        return name;
    }

    public AssignOp getAssignOp() {
        return assignOp;
    }

    public Node getInitializer() {
        return initializer;
    }

    public boolean hasInitializer() {
        return initializer != null;
    }

    @Override
    public <T> T accept(Visitor<T> visitor) {
        return visitor.visitVarDecl(this);
    }
}
