public enum AssignOp {
    IGUAL, ATRIBUI;

    public static AssignOp fromToken(TipoToken token) {
        return token == TipoToken.ATRIBUI ? ATRIBUI : IGUAL;
    }

    public String symbol() {
        return this == ATRIBUI ? "<-" : "=";
    }
}
