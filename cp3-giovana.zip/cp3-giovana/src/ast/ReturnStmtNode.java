public final class ReturnStmtNode extends Node {
    private final Node value;

    public ReturnStmtNode(Node value, int linha, int coluna) {
        super(linha, coluna);
        this.value = value;
    }

    public Node getValue() {
        return value;
    }

    public boolean hasValue() {
        return value != null;
    }

    @Override
    public <T> T accept(Visitor<T> visitor) {
        return visitor.visitReturnStmt(this);
    }
}
