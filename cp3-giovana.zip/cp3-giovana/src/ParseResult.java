import java.util.List;

public final class ParseResult {
    private final ProgramNode program;
    private final List<String> errors;

    public ParseResult(ProgramNode program, List<String> errors) {
        this.program = program;
        this.errors = List.copyOf(errors);
    }

    public ProgramNode getProgram() {
        return program;
    }

    public List<String> getErrors() {
        return errors;
    }

    public boolean isValid() {
        return program != null && errors.isEmpty();
    }
}
