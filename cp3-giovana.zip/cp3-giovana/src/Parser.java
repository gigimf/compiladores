import java.util.ArrayList;
import java.util.EnumSet;
import java.util.List;
import java.util.Set;

/**
 * LL(1) recursive-descent parser building an AST. Same SELECT/FOLLOW tables as CP2.
 */
public final class Parser {
    private final List<Token> tokens;
    private final List<String> errors = new ArrayList<>();
    private int current;
    private ParseResult lastResult;

    public Parser(List<Token> tokens) {
        if (tokens == null || tokens.isEmpty()) {
            throw new IllegalArgumentException("Token stream must end in EOF");
        }
        this.tokens = List.copyOf(tokens);
        for (int i = 0; i < tokens.size(); i++) {
            if (tokens.get(i).getTipo() == null
                    || (tokens.get(i).getTipo() == TipoToken.EOF) != (i == tokens.size() - 1)) {
                throw new IllegalArgumentException("Exactly one EOF is required, at the end");
            }
        }
    }

    public boolean parse() {
        lastResult = parseWithAst();
        return lastResult.isValid();
    }

    public ParseResult parseWithAst() {
        current = 0;
        errors.clear();
        ProgramNode program = parseProgram();
        if (!errors.isEmpty()) {
            return new ParseResult(null, errors);
        }
        return new ParseResult(program, errors);
    }

    public ParseResult getLastResult() {
        return lastResult;
    }

    public List<String> getErros() {
        return List.copyOf(errors);
    }

    private Token lookahead() {
        return tokens.get(current);
    }

    private void advance() {
        if (lookahead().getTipo() != TipoToken.EOF) {
            current++;
        }
    }

    private Token matchToken(TipoToken expected) {
        if (lookahead().getTipo() != expected) {
            throw new SyntaxFailure("esperado " + expected);
        }
        Token token = lookahead();
        advance();
        return token;
    }

    private void match(TipoToken expected) {
        matchToken(expected);
    }

    private void recover(String rule, SyntaxFailure failure, Set<TipoToken> follow) {
        Token token = lookahead();
        errors.add("erro sintatico na linha " + token.getLinha() + ", coluna "
                + token.getColuna() + " em " + rule + ": " + failure.getMessage()
                + "; encontrado " + token.getTipo() + " '" + token.getLexema() + "'");
        while (lookahead().getTipo() != TipoToken.EOF && !follow.contains(lookahead().getTipo())) {
            advance();
        }
    }

    private static final class SyntaxFailure extends RuntimeException {
        private static final long serialVersionUID = 1L;

        SyntaxFailure(String message) {
            super(message, null, false, false);
        }
    }

    private record InitializerParts(AssignOp assignOp, Node expression) {}

    private static final Set<TipoToken> FOLLOW_Program = EnumSet.of(TipoToken.EOF);
    private static final Set<TipoToken> FOLLOW_Declarations = EnumSet.of(TipoToken.EOF);
    private static final Set<TipoToken> FOLLOW_Declaration = EnumSet.of(TipoToken.BOOL, TipoToken.CHAR, TipoToken.DOUBLE, TipoToken.EOF, TipoToken.IDENTIFICADOR, TipoToken.INT, TipoToken.STRING_TYPE);
    private static final Set<TipoToken> FOLLOW_DeclarationRest = EnumSet.of(TipoToken.BOOL, TipoToken.CHAR, TipoToken.DOUBLE, TipoToken.EOF, TipoToken.IDENTIFICADOR, TipoToken.INT, TipoToken.STRING_TYPE);
    private static final Set<TipoToken> FOLLOW_Type = EnumSet.of(TipoToken.IDENTIFICADOR);
    private static final Set<TipoToken> FOLLOW_Initializer = EnumSet.of(TipoToken.PONTO_VIRGULA);
    private static final Set<TipoToken> FOLLOW_AssignmentOperator = EnumSet.of(TipoToken.BOOLEANO, TipoToken.CHAR_LITERAL, TipoToken.FLOAT, TipoToken.IDENTIFICADOR, TipoToken.INTEGER, TipoToken.LPAREN, TipoToken.MAIS, TipoToken.MENOS, TipoToken.NAO, TipoToken.STRING);
    private static final Set<TipoToken> FOLLOW_Parameters = EnumSet.of(TipoToken.RPAREN);
    private static final Set<TipoToken> FOLLOW_ParametersTail = EnumSet.of(TipoToken.RPAREN);
    private static final Set<TipoToken> FOLLOW_Parameter = EnumSet.of(TipoToken.RPAREN, TipoToken.VIRGULA);
    private static final Set<TipoToken> FOLLOW_Block = EnumSet.of(TipoToken.ABRE_CHAVE, TipoToken.BOOL, TipoToken.CHAR, TipoToken.DOUBLE, TipoToken.ELSE, TipoToken.EOF, TipoToken.FECHA_CHAVE, TipoToken.IDENTIFICADOR, TipoToken.IF, TipoToken.INT, TipoToken.RETURN, TipoToken.STRING_TYPE, TipoToken.WHILE);
    private static final Set<TipoToken> FOLLOW_Statements = EnumSet.of(TipoToken.FECHA_CHAVE);
    private static final Set<TipoToken> FOLLOW_Statement = EnumSet.of(TipoToken.ABRE_CHAVE, TipoToken.BOOL, TipoToken.CHAR, TipoToken.DOUBLE, TipoToken.FECHA_CHAVE, TipoToken.IDENTIFICADOR, TipoToken.IF, TipoToken.INT, TipoToken.RETURN, TipoToken.STRING_TYPE, TipoToken.WHILE);
    private static final Set<TipoToken> FOLLOW_IdentifierStatement = EnumSet.of(TipoToken.ABRE_CHAVE, TipoToken.BOOL, TipoToken.CHAR, TipoToken.DOUBLE, TipoToken.FECHA_CHAVE, TipoToken.IDENTIFICADOR, TipoToken.IF, TipoToken.INT, TipoToken.RETURN, TipoToken.STRING_TYPE, TipoToken.WHILE);
    private static final Set<TipoToken> FOLLOW_ElsePart = EnumSet.of(TipoToken.ABRE_CHAVE, TipoToken.BOOL, TipoToken.CHAR, TipoToken.DOUBLE, TipoToken.FECHA_CHAVE, TipoToken.IDENTIFICADOR, TipoToken.IF, TipoToken.INT, TipoToken.RETURN, TipoToken.STRING_TYPE, TipoToken.WHILE);
    private static final Set<TipoToken> FOLLOW_ReturnValue = EnumSet.of(TipoToken.PONTO_VIRGULA);
    private static final Set<TipoToken> FOLLOW_Arguments = EnumSet.of(TipoToken.RPAREN);
    private static final Set<TipoToken> FOLLOW_ArgumentsTail = EnumSet.of(TipoToken.RPAREN);
    private static final Set<TipoToken> FOLLOW_Expression = EnumSet.of(TipoToken.PONTO_VIRGULA, TipoToken.RPAREN, TipoToken.VIRGULA);
    private static final Set<TipoToken> FOLLOW_Equality = EnumSet.of(TipoToken.PONTO_VIRGULA, TipoToken.RPAREN, TipoToken.VIRGULA);
    private static final Set<TipoToken> FOLLOW_EqualityTail = EnumSet.of(TipoToken.PONTO_VIRGULA, TipoToken.RPAREN, TipoToken.VIRGULA);
    private static final Set<TipoToken> FOLLOW_EqualityOperator = EnumSet.of(TipoToken.BOOLEANO, TipoToken.CHAR_LITERAL, TipoToken.FLOAT, TipoToken.IDENTIFICADOR, TipoToken.INTEGER, TipoToken.LPAREN, TipoToken.MAIS, TipoToken.MENOS, TipoToken.NAO, TipoToken.STRING);
    private static final Set<TipoToken> FOLLOW_Relational = EnumSet.of(TipoToken.DIFERENTE, TipoToken.IGUAL_IGUAL, TipoToken.PONTO_VIRGULA, TipoToken.RPAREN, TipoToken.VIRGULA);
    private static final Set<TipoToken> FOLLOW_RelationalTail = EnumSet.of(TipoToken.DIFERENTE, TipoToken.IGUAL_IGUAL, TipoToken.PONTO_VIRGULA, TipoToken.RPAREN, TipoToken.VIRGULA);
    private static final Set<TipoToken> FOLLOW_RelationalOperator = EnumSet.of(TipoToken.BOOLEANO, TipoToken.CHAR_LITERAL, TipoToken.FLOAT, TipoToken.IDENTIFICADOR, TipoToken.INTEGER, TipoToken.LPAREN, TipoToken.MAIS, TipoToken.MENOS, TipoToken.NAO, TipoToken.STRING);
    private static final Set<TipoToken> FOLLOW_Additive = EnumSet.of(TipoToken.DIFERENTE, TipoToken.IGUAL_IGUAL, TipoToken.MAIOR, TipoToken.MAIOR_IGUAL, TipoToken.MENOR, TipoToken.MENOR_IGUAL, TipoToken.PONTO_VIRGULA, TipoToken.RPAREN, TipoToken.VIRGULA);
    private static final Set<TipoToken> FOLLOW_AdditiveTail = EnumSet.of(TipoToken.DIFERENTE, TipoToken.IGUAL_IGUAL, TipoToken.MAIOR, TipoToken.MAIOR_IGUAL, TipoToken.MENOR, TipoToken.MENOR_IGUAL, TipoToken.PONTO_VIRGULA, TipoToken.RPAREN, TipoToken.VIRGULA);
    private static final Set<TipoToken> FOLLOW_AdditiveOperator = EnumSet.of(TipoToken.BOOLEANO, TipoToken.CHAR_LITERAL, TipoToken.FLOAT, TipoToken.IDENTIFICADOR, TipoToken.INTEGER, TipoToken.LPAREN, TipoToken.MAIS, TipoToken.MENOS, TipoToken.NAO, TipoToken.STRING);
    private static final Set<TipoToken> FOLLOW_Multiplicative = EnumSet.of(TipoToken.DIFERENTE, TipoToken.IGUAL_IGUAL, TipoToken.MAIOR, TipoToken.MAIOR_IGUAL, TipoToken.MAIS, TipoToken.MENOR, TipoToken.MENOR_IGUAL, TipoToken.MENOS, TipoToken.PONTO_VIRGULA, TipoToken.RPAREN, TipoToken.VIRGULA);
    private static final Set<TipoToken> FOLLOW_MultiplicativeTail = EnumSet.of(TipoToken.DIFERENTE, TipoToken.IGUAL_IGUAL, TipoToken.MAIOR, TipoToken.MAIOR_IGUAL, TipoToken.MAIS, TipoToken.MENOR, TipoToken.MENOR_IGUAL, TipoToken.MENOS, TipoToken.PONTO_VIRGULA, TipoToken.RPAREN, TipoToken.VIRGULA);
    private static final Set<TipoToken> FOLLOW_MultiplicativeOperator = EnumSet.of(TipoToken.BOOLEANO, TipoToken.CHAR_LITERAL, TipoToken.FLOAT, TipoToken.IDENTIFICADOR, TipoToken.INTEGER, TipoToken.LPAREN, TipoToken.MAIS, TipoToken.MENOS, TipoToken.NAO, TipoToken.STRING);
    private static final Set<TipoToken> FOLLOW_Unary = EnumSet.of(TipoToken.DIFERENTE, TipoToken.DIVIDIR, TipoToken.IGUAL_IGUAL, TipoToken.MAIOR, TipoToken.MAIOR_IGUAL, TipoToken.MAIS, TipoToken.MENOR, TipoToken.MENOR_IGUAL, TipoToken.MENOS, TipoToken.PONTO_VIRGULA, TipoToken.RPAREN, TipoToken.VEZES, TipoToken.VIRGULA);
    private static final Set<TipoToken> FOLLOW_Primary = EnumSet.of(TipoToken.DIFERENTE, TipoToken.DIVIDIR, TipoToken.IGUAL_IGUAL, TipoToken.MAIOR, TipoToken.MAIOR_IGUAL, TipoToken.MAIS, TipoToken.MENOR, TipoToken.MENOR_IGUAL, TipoToken.MENOS, TipoToken.PONTO_VIRGULA, TipoToken.RPAREN, TipoToken.VEZES, TipoToken.VIRGULA);

    private ProgramNode parseProgram() {
        try {
            int linha = lookahead().getLinha();
            int coluna = lookahead().getColuna();
            switch (lookahead().getTipo()) {
                case BOOL, CHAR, DOUBLE, EOF, IDENTIFICADOR, INT, STRING_TYPE -> {
                    List<Node> declarations = parseDeclarations();
                    match(TipoToken.EOF);
                    return new ProgramNode(declarations, linha, coluna);
                }
                default -> throw new SyntaxFailure("esperado um de { BOOL, CHAR, DOUBLE, EOF, IDENTIFICADOR, INT, STRING_TYPE }");
            }
        } catch (SyntaxFailure failure) {
            recover("Program", failure, FOLLOW_Program);
            return null;
        }
    }

    private List<Node> parseDeclarations() {
        List<Node> declarations = new ArrayList<>();
        try {
            while (true) {
                switch (lookahead().getTipo()) {
                    case BOOL, CHAR, DOUBLE, IDENTIFICADOR, INT, STRING_TYPE -> {
                        Node declaration = parseDeclaration();
                        if (declaration != null) {
                            declarations.add(declaration);
                        }
                    }
                    case EOF -> {
                        return declarations;
                    }
                    default -> throw new SyntaxFailure("esperado um de { BOOL, CHAR, DOUBLE, EOF, IDENTIFICADOR, INT, STRING_TYPE }");
                }
            }
        } catch (SyntaxFailure failure) {
            recover("Declarations", failure, FOLLOW_Declarations);
            return declarations;
        }
    }

    private Node parseDeclaration() {
        try {
            switch (lookahead().getTipo()) {
                case BOOL, CHAR, DOUBLE, INT, STRING_TYPE -> {
                    int linha = lookahead().getLinha();
                    int coluna = lookahead().getColuna();
                    TypeKind type = parseType();
                    Token name = matchToken(TipoToken.IDENTIFICADOR);
                    return parseDeclarationRest(type, name.getLexema(), linha, coluna);
                }
                case IDENTIFICADOR -> {
                    Token name = matchToken(TipoToken.IDENTIFICADOR);
                    match(TipoToken.LPAREN);
                    List<ParamNode> parameters = parseParameters();
                    match(TipoToken.RPAREN);
                    BlockNode body = parseBlock();
                    return new ProcDeclNode(name.getLexema(), parameters, body, name.getLinha(), name.getColuna());
                }
                default -> throw new SyntaxFailure("esperado um de { BOOL, CHAR, DOUBLE, IDENTIFICADOR, INT, STRING_TYPE }");
            }
        } catch (SyntaxFailure failure) {
            recover("Declaration", failure, FOLLOW_Declaration);
            return null;
        }
    }

    private Node parseDeclarationRest(TypeKind type, String name, int linha, int coluna) {
        try {
            switch (lookahead().getTipo()) {
                case LPAREN -> {
                    match(TipoToken.LPAREN);
                    List<ParamNode> parameters = parseParameters();
                    match(TipoToken.RPAREN);
                    BlockNode body = parseBlock();
                    return new FuncDeclNode(type, name, parameters, body, linha, coluna);
                }
                case ATRIBUI, IGUAL, PONTO_VIRGULA -> {
                    InitializerParts init = parseInitializer();
                    match(TipoToken.PONTO_VIRGULA);
                    return new VarDeclNode(type, name, init.assignOp(), init.expression(), linha, coluna);
                }
                default -> throw new SyntaxFailure("esperado um de { ATRIBUI, IGUAL, LPAREN, PONTO_VIRGULA }");
            }
        } catch (SyntaxFailure failure) {
            recover("DeclarationRest", failure, FOLLOW_DeclarationRest);
            return null;
        }
    }

    private TypeKind parseType() {
        try {
            TipoToken kind = lookahead().getTipo();
            switch (kind) {
                case INT, DOUBLE, BOOL, CHAR, STRING_TYPE -> {
                    advance();
                    return TypeKind.fromToken(kind);
                }
                default -> throw new SyntaxFailure("esperado um de { BOOL, CHAR, DOUBLE, INT, STRING_TYPE }");
            }
        } catch (SyntaxFailure failure) {
            recover("Type", failure, FOLLOW_Type);
            return null;
        }
    }

    private InitializerParts parseInitializer() {
        try {
            switch (lookahead().getTipo()) {
                case ATRIBUI, IGUAL -> {
                    AssignOp op = parseAssignmentOperator();
                    Node expression = parseExpression();
                    return new InitializerParts(op, expression);
                }
                case PONTO_VIRGULA -> {
                    return new InitializerParts(null, null);
                }
                default -> throw new SyntaxFailure("esperado um de { ATRIBUI, IGUAL, PONTO_VIRGULA }");
            }
        } catch (SyntaxFailure failure) {
            recover("Initializer", failure, FOLLOW_Initializer);
            return new InitializerParts(null, null);
        }
    }

    private AssignOp parseAssignmentOperator() {
        try {
            switch (lookahead().getTipo()) {
                case IGUAL -> {
                    advance();
                    return AssignOp.IGUAL;
                }
                case ATRIBUI -> {
                    advance();
                    return AssignOp.ATRIBUI;
                }
                default -> throw new SyntaxFailure("esperado um de { ATRIBUI, IGUAL }");
            }
        } catch (SyntaxFailure failure) {
            recover("AssignmentOperator", failure, FOLLOW_AssignmentOperator);
            return AssignOp.IGUAL;
        }
    }

    private List<ParamNode> parseParameters() {
        List<ParamNode> parameters = new ArrayList<>();
        try {
            switch (lookahead().getTipo()) {
                case BOOL, CHAR, DOUBLE, INT, STRING_TYPE -> {
                    ParamNode first = parseParameter();
                    if (first != null) {
                        parameters.add(first);
                    }
                    parseParametersTail(parameters);
                    return parameters;
                }
                case RPAREN -> {
                    return parameters;
                }
                default -> throw new SyntaxFailure("esperado um de { BOOL, CHAR, DOUBLE, INT, RPAREN, STRING_TYPE }");
            }
        } catch (SyntaxFailure failure) {
            recover("Parameters", failure, FOLLOW_Parameters);
            return parameters;
        }
    }

    private void parseParametersTail(List<ParamNode> parameters) {
        try {
            while (true) {
                switch (lookahead().getTipo()) {
                    case VIRGULA -> {
                        match(TipoToken.VIRGULA);
                        ParamNode parameter = parseParameter();
                        if (parameter != null) {
                            parameters.add(parameter);
                        }
                    }
                    case RPAREN -> {
                        return;
                    }
                    default -> throw new SyntaxFailure("esperado um de { RPAREN, VIRGULA }");
                }
            }
        } catch (SyntaxFailure failure) {
            recover("ParametersTail", failure, FOLLOW_ParametersTail);
        }
    }

    private ParamNode parseParameter() {
        try {
            int linha = lookahead().getLinha();
            int coluna = lookahead().getColuna();
            switch (lookahead().getTipo()) {
                case BOOL, CHAR, DOUBLE, INT, STRING_TYPE -> {
                    TypeKind type = parseType();
                    Token name = matchToken(TipoToken.IDENTIFICADOR);
                    return new ParamNode(type, name.getLexema(), linha, coluna);
                }
                default -> throw new SyntaxFailure("esperado um de { BOOL, CHAR, DOUBLE, INT, STRING_TYPE }");
            }
        } catch (SyntaxFailure failure) {
            recover("Parameter", failure, FOLLOW_Parameter);
            return null;
        }
    }

    private BlockNode parseBlock() {
        try {
            switch (lookahead().getTipo()) {
                case ABRE_CHAVE -> {
                    Token open = matchToken(TipoToken.ABRE_CHAVE);
                    List<Node> statements = parseStatements();
                    match(TipoToken.FECHA_CHAVE);
                    return new BlockNode(statements, open.getLinha(), open.getColuna());
                }
                default -> throw new SyntaxFailure("esperado um de { ABRE_CHAVE }");
            }
        } catch (SyntaxFailure failure) {
            recover("Block", failure, FOLLOW_Block);
            return null;
        }
    }

    private List<Node> parseStatements() {
        List<Node> statements = new ArrayList<>();
        try {
            while (true) {
                switch (lookahead().getTipo()) {
                    case ABRE_CHAVE, BOOL, CHAR, DOUBLE, IDENTIFICADOR, IF, INT, RETURN, STRING_TYPE, WHILE -> {
                        Node statement = parseStatement();
                        if (statement != null) {
                            statements.add(statement);
                        }
                    }
                    case FECHA_CHAVE -> {
                        return statements;
                    }
                    default -> throw new SyntaxFailure("esperado um de { ABRE_CHAVE, BOOL, CHAR, DOUBLE, FECHA_CHAVE, IDENTIFICADOR, IF, INT, RETURN, STRING_TYPE, WHILE }");
                }
            }
        } catch (SyntaxFailure failure) {
            recover("Statements", failure, FOLLOW_Statements);
            return statements;
        }
    }

    private Node parseStatement() {
        try {
            switch (lookahead().getTipo()) {
                case BOOL, CHAR, DOUBLE, INT, STRING_TYPE -> {
                    int linha = lookahead().getLinha();
                    int coluna = lookahead().getColuna();
                    TypeKind type = parseType();
                    Token name = matchToken(TipoToken.IDENTIFICADOR);
                    InitializerParts init = parseInitializer();
                    match(TipoToken.PONTO_VIRGULA);
                    return new VarDeclNode(type, name.getLexema(), init.assignOp(), init.expression(), linha, coluna);
                }
                case IDENTIFICADOR -> {
                    Token name = matchToken(TipoToken.IDENTIFICADOR);
                    return parseIdentifierStatement(name);
                }
                case IF -> {
                    Token token = matchToken(TipoToken.IF);
                    match(TipoToken.LPAREN);
                    Node condition = parseExpression();
                    match(TipoToken.RPAREN);
                    BlockNode thenBranch = parseBlock();
                    BlockNode elseBranch = parseElsePart();
                    return new IfStmtNode(condition, thenBranch, elseBranch, token.getLinha(), token.getColuna());
                }
                case WHILE -> {
                    Token token = matchToken(TipoToken.WHILE);
                    match(TipoToken.LPAREN);
                    Node condition = parseExpression();
                    match(TipoToken.RPAREN);
                    BlockNode body = parseBlock();
                    return new WhileStmtNode(condition, body, token.getLinha(), token.getColuna());
                }
                case RETURN -> {
                    Token token = matchToken(TipoToken.RETURN);
                    Node value = parseReturnValue();
                    match(TipoToken.PONTO_VIRGULA);
                    return new ReturnStmtNode(value, token.getLinha(), token.getColuna());
                }
                case ABRE_CHAVE -> {
                    return parseBlock();
                }
                default -> throw new SyntaxFailure("esperado um de { ABRE_CHAVE, BOOL, CHAR, DOUBLE, IDENTIFICADOR, IF, INT, RETURN, STRING_TYPE, WHILE }");
            }
        } catch (SyntaxFailure failure) {
            recover("Statement", failure, FOLLOW_Statement);
            return null;
        }
    }

    private Node parseIdentifierStatement(Token name) {
        try {
            switch (lookahead().getTipo()) {
                case ATRIBUI, IGUAL -> {
                    AssignOp operator = parseAssignmentOperator();
                    Node expression = parseExpression();
                    match(TipoToken.PONTO_VIRGULA);
                    return new AssignStmtNode(name.getLexema(), operator, expression, name.getLinha(), name.getColuna());
                }
                case LPAREN -> {
                    match(TipoToken.LPAREN);
                    List<Node> arguments = parseArguments();
                    match(TipoToken.RPAREN);
                    match(TipoToken.PONTO_VIRGULA);
                    return new CallStmtNode(name.getLexema(), arguments, name.getLinha(), name.getColuna());
                }
                default -> throw new SyntaxFailure("esperado um de { ATRIBUI, IGUAL, LPAREN }");
            }
        } catch (SyntaxFailure failure) {
            recover("IdentifierStatement", failure, FOLLOW_IdentifierStatement);
            return null;
        }
    }

    private BlockNode parseElsePart() {
        try {
            switch (lookahead().getTipo()) {
                case ELSE -> {
                    match(TipoToken.ELSE);
                    return parseBlock();
                }
                case ABRE_CHAVE, BOOL, CHAR, DOUBLE, FECHA_CHAVE, IDENTIFICADOR, IF, INT, RETURN, STRING_TYPE, WHILE -> {
                    return null;
                }
                default -> throw new SyntaxFailure("esperado um de { ABRE_CHAVE, BOOL, CHAR, DOUBLE, ELSE, FECHA_CHAVE, IDENTIFICADOR, IF, INT, RETURN, STRING_TYPE, WHILE }");
            }
        } catch (SyntaxFailure failure) {
            recover("ElsePart", failure, FOLLOW_ElsePart);
            return null;
        }
    }

    private Node parseReturnValue() {
        try {
            switch (lookahead().getTipo()) {
                case BOOLEANO, CHAR_LITERAL, FLOAT, IDENTIFICADOR, INTEGER, LPAREN, MAIS, MENOS, NAO, STRING -> {
                    return parseExpression();
                }
                case PONTO_VIRGULA -> {
                    return null;
                }
                default -> throw new SyntaxFailure("esperado um de { BOOLEANO, CHAR_LITERAL, FLOAT, IDENTIFICADOR, INTEGER, LPAREN, MAIS, MENOS, NAO, PONTO_VIRGULA, STRING }");
            }
        } catch (SyntaxFailure failure) {
            recover("ReturnValue", failure, FOLLOW_ReturnValue);
            return null;
        }
    }

    private List<Node> parseArguments() {
        List<Node> arguments = new ArrayList<>();
        try {
            switch (lookahead().getTipo()) {
                case BOOLEANO, CHAR_LITERAL, FLOAT, IDENTIFICADOR, INTEGER, LPAREN, MAIS, MENOS, NAO, STRING -> {
                    Node first = parseExpression();
                    if (first != null) {
                        arguments.add(first);
                    }
                    parseArgumentsTail(arguments);
                    return arguments;
                }
                case RPAREN -> {
                    return arguments;
                }
                default -> throw new SyntaxFailure("esperado um de { BOOLEANO, CHAR_LITERAL, FLOAT, IDENTIFICADOR, INTEGER, LPAREN, MAIS, MENOS, NAO, RPAREN, STRING }");
            }
        } catch (SyntaxFailure failure) {
            recover("Arguments", failure, FOLLOW_Arguments);
            return arguments;
        }
    }

    private void parseArgumentsTail(List<Node> arguments) {
        try {
            while (true) {
                switch (lookahead().getTipo()) {
                    case VIRGULA -> {
                        match(TipoToken.VIRGULA);
                        Node argument = parseExpression();
                        if (argument != null) {
                            arguments.add(argument);
                        }
                    }
                    case RPAREN -> {
                        return;
                    }
                    default -> throw new SyntaxFailure("esperado um de { RPAREN, VIRGULA }");
                }
            }
        } catch (SyntaxFailure failure) {
            recover("ArgumentsTail", failure, FOLLOW_ArgumentsTail);
        }
    }

    private Node parseExpression() {
        try {
            switch (lookahead().getTipo()) {
                case BOOLEANO, CHAR_LITERAL, FLOAT, IDENTIFICADOR, INTEGER, LPAREN, MAIS, MENOS, NAO, STRING -> {
                    return parseEquality();
                }
                default -> throw new SyntaxFailure("esperado um de { BOOLEANO, CHAR_LITERAL, FLOAT, IDENTIFICADOR, INTEGER, LPAREN, MAIS, MENOS, NAO, STRING }");
            }
        } catch (SyntaxFailure failure) {
            recover("Expression", failure, FOLLOW_Expression);
            return null;
        }
    }

    private Node parseEquality() {
        try {
            Node left = parseRelational();
            return parseEqualityTail(left);
        } catch (SyntaxFailure failure) {
            recover("Equality", failure, FOLLOW_Equality);
            return null;
        }
    }

    private Node parseEqualityTail(Node left) {
        try {
            while (true) {
                switch (lookahead().getTipo()) {
                    case DIFERENTE, IGUAL_IGUAL -> {
                        Token operator = lookahead();
                        advance();
                        Node right = parseRelational();
                        left = new BinOpNode(operator.getTipo(), left, right, operator.getLinha(), operator.getColuna());
                    }
                    case PONTO_VIRGULA, RPAREN, VIRGULA -> {
                        return left;
                    }
                    default -> throw new SyntaxFailure("esperado um de { DIFERENTE, IGUAL_IGUAL, PONTO_VIRGULA, RPAREN, VIRGULA }");
                }
            }
        } catch (SyntaxFailure failure) {
            recover("EqualityTail", failure, FOLLOW_EqualityTail);
            return left;
        }
    }

    private Node parseRelational() {
        try {
            Node left = parseAdditive();
            return parseRelationalTail(left);
        } catch (SyntaxFailure failure) {
            recover("Relational", failure, FOLLOW_Relational);
            return null;
        }
    }

    private Node parseRelationalTail(Node left) {
        try {
            while (true) {
                switch (lookahead().getTipo()) {
                    case MAIOR, MAIOR_IGUAL, MENOR, MENOR_IGUAL -> {
                        Token operator = lookahead();
                        advance();
                        Node right = parseAdditive();
                        left = new BinOpNode(operator.getTipo(), left, right, operator.getLinha(), operator.getColuna());
                    }
                    case DIFERENTE, IGUAL_IGUAL, PONTO_VIRGULA, RPAREN, VIRGULA -> {
                        return left;
                    }
                    default -> throw new SyntaxFailure("esperado um de { DIFERENTE, IGUAL_IGUAL, MAIOR, MAIOR_IGUAL, MENOR, MENOR_IGUAL, PONTO_VIRGULA, RPAREN, VIRGULA }");
                }
            }
        } catch (SyntaxFailure failure) {
            recover("RelationalTail", failure, FOLLOW_RelationalTail);
            return left;
        }
    }

    private Node parseAdditive() {
        try {
            Node left = parseMultiplicative();
            return parseAdditiveTail(left);
        } catch (SyntaxFailure failure) {
            recover("Additive", failure, FOLLOW_Additive);
            return null;
        }
    }

    private Node parseAdditiveTail(Node left) {
        try {
            while (true) {
                switch (lookahead().getTipo()) {
                    case MAIS, MENOS -> {
                        Token operator = lookahead();
                        advance();
                        Node right = parseMultiplicative();
                        left = new BinOpNode(operator.getTipo(), left, right, operator.getLinha(), operator.getColuna());
                    }
                    case DIFERENTE, IGUAL_IGUAL, MAIOR, MAIOR_IGUAL, MENOR, MENOR_IGUAL, PONTO_VIRGULA, RPAREN, VIRGULA -> {
                        return left;
                    }
                    default -> throw new SyntaxFailure("esperado um de { DIFERENTE, IGUAL_IGUAL, MAIOR, MAIOR_IGUAL, MAIS, MENOR, MENOR_IGUAL, MENOS, PONTO_VIRGULA, RPAREN, VIRGULA }");
                }
            }
        } catch (SyntaxFailure failure) {
            recover("AdditiveTail", failure, FOLLOW_AdditiveTail);
            return left;
        }
    }

    private Node parseMultiplicative() {
        try {
            Node left = parseUnary();
            return parseMultiplicativeTail(left);
        } catch (SyntaxFailure failure) {
            recover("Multiplicative", failure, FOLLOW_Multiplicative);
            return null;
        }
    }

    private Node parseMultiplicativeTail(Node left) {
        try {
            while (true) {
                switch (lookahead().getTipo()) {
                    case DIVIDIR, VEZES -> {
                        Token operator = lookahead();
                        advance();
                        Node right = parseUnary();
                        left = new BinOpNode(operator.getTipo(), left, right, operator.getLinha(), operator.getColuna());
                    }
                    case DIFERENTE, IGUAL_IGUAL, MAIOR, MAIOR_IGUAL, MAIS, MENOR, MENOR_IGUAL, MENOS, PONTO_VIRGULA, RPAREN, VIRGULA -> {
                        return left;
                    }
                    default -> throw new SyntaxFailure("esperado um de { DIFERENTE, DIVIDIR, IGUAL_IGUAL, MAIOR, MAIOR_IGUAL, MAIS, MENOR, MENOR_IGUAL, MENOS, PONTO_VIRGULA, RPAREN, VEZES, VIRGULA }");
                }
            }
        } catch (SyntaxFailure failure) {
            recover("MultiplicativeTail", failure, FOLLOW_MultiplicativeTail);
            return left;
        }
    }

    private Node parseUnary() {
        try {
            switch (lookahead().getTipo()) {
                case NAO, MENOS, MAIS -> {
                    Token operator = lookahead();
                    advance();
                    Node operand = parseUnary();
                    return new UnaryOpNode(operator.getTipo(), operand, operator.getLinha(), operator.getColuna());
                }
                case BOOLEANO, CHAR_LITERAL, FLOAT, IDENTIFICADOR, INTEGER, LPAREN, STRING -> {
                    return parsePrimary();
                }
                default -> throw new SyntaxFailure("esperado um de { BOOLEANO, CHAR_LITERAL, FLOAT, IDENTIFICADOR, INTEGER, LPAREN, MAIS, MENOS, NAO, STRING }");
            }
        } catch (SyntaxFailure failure) {
            recover("Unary", failure, FOLLOW_Unary);
            return null;
        }
    }

    private Node parsePrimary() {
        try {
            switch (lookahead().getTipo()) {
                case IDENTIFICADOR -> {
                    Token identifier = matchToken(TipoToken.IDENTIFICADOR);
                    if (lookahead().getTipo() == TipoToken.LPAREN) {
                        match(TipoToken.LPAREN);
                        List<Node> arguments = parseArguments();
                        match(TipoToken.RPAREN);
                        return new CallExprNode(identifier.getLexema(), arguments, identifier.getLinha(), identifier.getColuna());
                    }
                    return new IdentNode(identifier.getLexema(), identifier.getLinha(), identifier.getColuna());
                }
                case INTEGER -> {
                    Token token = matchToken(TipoToken.INTEGER);
                    return new IntLitNode(token.getLexema(), token.getLinha(), token.getColuna());
                }
                case FLOAT -> {
                    Token token = matchToken(TipoToken.FLOAT);
                    return new FloatLitNode(token.getLexema(), token.getLinha(), token.getColuna());
                }
                case BOOLEANO -> {
                    Token token = matchToken(TipoToken.BOOLEANO);
                    boolean value = "true".equals(token.getLexema());
                    return new BoolLitNode(value, token.getLinha(), token.getColuna());
                }
                case CHAR_LITERAL -> {
                    Token token = matchToken(TipoToken.CHAR_LITERAL);
                    return new CharLitNode(token.getLexema(), token.getLinha(), token.getColuna());
                }
                case STRING -> {
                    Token token = matchToken(TipoToken.STRING);
                    return new StringLitNode(token.getLexema(), token.getLinha(), token.getColuna());
                }
                case LPAREN -> {
                    match(TipoToken.LPAREN);
                    Node inner = parseExpression();
                    match(TipoToken.RPAREN);
                    return inner;
                }
                default -> throw new SyntaxFailure("esperado um de { BOOLEANO, CHAR_LITERAL, FLOAT, IDENTIFICADOR, INTEGER, LPAREN, STRING }");
            }
        } catch (SyntaxFailure failure) {
            recover("Primary", failure, FOLLOW_Primary);
            return null;
        }
    }
}
