public interface Visitor<T> {
    T visitProgram(ProgramNode node);
    T visitVarDecl(VarDeclNode node);
    T visitFuncDecl(FuncDeclNode node);
    T visitProcDecl(ProcDeclNode node);
    T visitParam(ParamNode node);
    T visitBlock(BlockNode node);
    T visitAssignStmt(AssignStmtNode node);
    T visitCallStmt(CallStmtNode node);
    T visitIfStmt(IfStmtNode node);
    T visitWhileStmt(WhileStmtNode node);
    T visitReturnStmt(ReturnStmtNode node);
    T visitIntLit(IntLitNode node);
    T visitFloatLit(FloatLitNode node);
    T visitBoolLit(BoolLitNode node);
    T visitCharLit(CharLitNode node);
    T visitStringLit(StringLitNode node);
    T visitIdent(IdentNode node);
    T visitBinOp(BinOpNode node);
    T visitUnaryOp(UnaryOpNode node);
    T visitCallExpr(CallExprNode node);
}
