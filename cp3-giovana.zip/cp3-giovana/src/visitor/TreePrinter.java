public final class TreePrinter implements Visitor<Void> {
    private final StringBuilder out = new StringBuilder();
    private int depth;

    public String print(Node root) {
        out.setLength(0);
        depth = 0;
        root.accept(this);
        return out.toString().stripTrailing();
    }

    private void line(String text) {
        out.append("  ".repeat(depth)).append(text).append('\n');
    }

    private void pos(Node node) {
        line("@L" + node.getLinha() + "C" + node.getColuna());
    }

    @Override
    public Void visitProgram(ProgramNode node) {
        line("Program");
        pos(node);
        depth++;
        for (Node decl : node.getDeclarations()) {
            decl.accept(this);
        }
        depth--;
        return null;
    }

    @Override
    public Void visitVarDecl(VarDeclNode node) {
        line("VarDecl type=" + node.getType().keyword() + " name=" + node.getName()
                + (node.hasInitializer() ? " op=" + node.getAssignOp().symbol() : ""));
        pos(node);
        if (node.hasInitializer()) {
            depth++;
            node.getInitializer().accept(this);
            depth--;
        }
        return null;
    }

    @Override
    public Void visitFuncDecl(FuncDeclNode node) {
        line("FuncDecl type=" + node.getReturnType().keyword() + " name=" + node.getName());
        pos(node);
        depth++;
        for (ParamNode param : node.getParameters()) {
            param.accept(this);
        }
        node.getBody().accept(this);
        depth--;
        return null;
    }

    @Override
    public Void visitProcDecl(ProcDeclNode node) {
        line("ProcDecl name=" + node.getName());
        pos(node);
        depth++;
        for (ParamNode param : node.getParameters()) {
            param.accept(this);
        }
        node.getBody().accept(this);
        depth--;
        return null;
    }

    @Override
    public Void visitParam(ParamNode node) {
        line("Param type=" + node.getType().keyword() + " name=" + node.getName());
        pos(node);
        return null;
    }

    @Override
    public Void visitBlock(BlockNode node) {
        line("Block");
        pos(node);
        depth++;
        for (Node stmt : node.getStatements()) {
            stmt.accept(this);
        }
        depth--;
        return null;
    }

    @Override
    public Void visitAssignStmt(AssignStmtNode node) {
        line("Assign name=" + node.getName() + " op=" + node.getOperator().symbol());
        pos(node);
        depth++;
        node.getExpression().accept(this);
        depth--;
        return null;
    }

    @Override
    public Void visitCallStmt(CallStmtNode node) {
        line("CallStmt name=" + node.getName());
        pos(node);
        depth++;
        for (Node arg : node.getArguments()) {
            arg.accept(this);
        }
        depth--;
        return null;
    }

    @Override
    public Void visitIfStmt(IfStmtNode node) {
        line("If");
        pos(node);
        depth++;
        node.getCondition().accept(this);
        node.getThenBranch().accept(this);
        if (node.hasElse()) {
            node.getElseBranch().accept(this);
        }
        depth--;
        return null;
    }

    @Override
    public Void visitWhileStmt(WhileStmtNode node) {
        line("While");
        pos(node);
        depth++;
        node.getCondition().accept(this);
        node.getBody().accept(this);
        depth--;
        return null;
    }

    @Override
    public Void visitReturnStmt(ReturnStmtNode node) {
        line("Return" + (node.hasValue() ? "" : " void"));
        pos(node);
        if (node.hasValue()) {
            depth++;
            node.getValue().accept(this);
            depth--;
        }
        return null;
    }

    @Override
    public Void visitIntLit(IntLitNode node) {
        line("IntLit value=" + node.getLexeme());
        pos(node);
        return null;
    }

    @Override
    public Void visitFloatLit(FloatLitNode node) {
        line("FloatLit value=" + node.getLexeme());
        pos(node);
        return null;
    }

    @Override
    public Void visitBoolLit(BoolLitNode node) {
        line("BoolLit value=" + node.getValue());
        pos(node);
        return null;
    }

    @Override
    public Void visitCharLit(CharLitNode node) {
        line("CharLit value=" + node.getLexeme());
        pos(node);
        return null;
    }

    @Override
    public Void visitStringLit(StringLitNode node) {
        line("StringLit value=" + node.getLexeme());
        pos(node);
        return null;
    }

    @Override
    public Void visitIdent(IdentNode node) {
        line("Ident name=" + node.getName());
        pos(node);
        return null;
    }

    @Override
    public Void visitBinOp(BinOpNode node) {
        line("BinOp op=" + opLabel(node.getOperator()));
        pos(node);
        depth++;
        node.getLeft().accept(this);
        node.getRight().accept(this);
        depth--;
        return null;
    }

    @Override
    public Void visitUnaryOp(UnaryOpNode node) {
        line("UnaryOp op=" + opLabel(node.getOperator()));
        pos(node);
        depth++;
        node.getOperand().accept(this);
        depth--;
        return null;
    }

    @Override
    public Void visitCallExpr(CallExprNode node) {
        line("CallExpr name=" + node.getName());
        pos(node);
        depth++;
        for (Node arg : node.getArguments()) {
            arg.accept(this);
        }
        depth--;
        return null;
    }

    private static String opLabel(TipoToken op) {
        return switch (op) {
            case MAIS -> "+";
            case MENOS -> "-";
            case VEZES -> "*";
            case DIVIDIR -> "/";
            case IGUAL_IGUAL -> "==";
            case DIFERENTE -> "!=";
            case MENOR -> "<";
            case MENOR_IGUAL -> "<=";
            case MAIOR -> ">";
            case MAIOR_IGUAL -> ">=";
            case NAO -> "!";
            default -> op.name();
        };
    }
}
