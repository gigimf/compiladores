public final class SourcePrinter implements Visitor<String> {
    public String print(Node root) {
        return root.accept(this);
    }

    @Override
    public String visitProgram(ProgramNode node) {
        StringBuilder out = new StringBuilder();
        for (int i = 0; i < node.getDeclarations().size(); i++) {
            if (i > 0) {
                out.append('\n');
            }
            out.append(node.getDeclarations().get(i).accept(this));
        }
        return out.toString();
    }

    @Override
    public String visitVarDecl(VarDeclNode node) {
        StringBuilder out = new StringBuilder();
        out.append(node.getType().keyword()).append(' ').append(node.getName());
        if (node.hasInitializer()) {
            out.append(' ').append(node.getAssignOp().symbol()).append(' ')
                    .append(node.getInitializer().accept(this));
        }
        return out.append(';').toString();
    }

    @Override
    public String visitFuncDecl(FuncDeclNode node) {
        StringBuilder out = new StringBuilder();
        out.append(node.getReturnType().keyword()).append(' ').append(node.getName())
                .append('(').append(printParams(node.getParameters())).append(") ")
                .append(node.getBody().accept(this));
        return out.toString();
    }

    @Override
    public String visitProcDecl(ProcDeclNode node) {
        return node.getName() + "(" + printParams(node.getParameters()) + ") "
                + node.getBody().accept(this);
    }

    @Override
    public String visitParam(ParamNode node) {
        return node.getType().keyword() + " " + node.getName();
    }

    @Override
    public String visitBlock(BlockNode node) {
        StringBuilder out = new StringBuilder("{");
        for (Node stmt : node.getStatements()) {
            out.append(' ').append(stmt.accept(this));
        }
        if (!node.getStatements().isEmpty()) {
            out.append(' ');
        }
        return out.append('}').toString();
    }

    @Override
    public String visitAssignStmt(AssignStmtNode node) {
        return node.getName() + " " + node.getOperator().symbol() + " "
                + node.getExpression().accept(this) + ";";
    }

    @Override
    public String visitCallStmt(CallStmtNode node) {
        return node.getName() + "(" + printArgs(node.getArguments()) + ");";
    }

    @Override
    public String visitIfStmt(IfStmtNode node) {
        StringBuilder out = new StringBuilder();
        out.append("if (").append(node.getCondition().accept(this)).append(") ")
                .append(node.getThenBranch().accept(this));
        if (node.hasElse()) {
            out.append(" else ").append(node.getElseBranch().accept(this));
        }
        return out.toString();
    }

    @Override
    public String visitWhileStmt(WhileStmtNode node) {
        return "while (" + node.getCondition().accept(this) + ") " + node.getBody().accept(this);
    }

    @Override
    public String visitReturnStmt(ReturnStmtNode node) {
        if (node.hasValue()) {
            return "return " + node.getValue().accept(this) + ";";
        }
        return "return;";
    }

    @Override
    public String visitIntLit(IntLitNode node) {
        return node.getLexeme();
    }

    @Override
    public String visitFloatLit(FloatLitNode node) {
        return node.getLexeme();
    }

    @Override
    public String visitBoolLit(BoolLitNode node) {
        return Boolean.toString(node.getValue());
    }

    @Override
    public String visitCharLit(CharLitNode node) {
        return node.getLexeme();
    }

    @Override
    public String visitStringLit(StringLitNode node) {
        return node.getLexeme();
    }

    @Override
    public String visitIdent(IdentNode node) {
        return node.getName();
    }

    @Override
    public String visitBinOp(BinOpNode node) {
        return "(" + node.getLeft().accept(this) + " " + opSymbol(node.getOperator()) + " "
                + node.getRight().accept(this) + ")";
    }

    @Override
    public String visitUnaryOp(UnaryOpNode node) {
        return "(" + opSymbol(node.getOperator()) + node.getOperand().accept(this) + ")";
    }

    @Override
    public String visitCallExpr(CallExprNode node) {
        return node.getName() + "(" + printArgs(node.getArguments()) + ")";
    }

    private String printParams(java.util.List<ParamNode> params) {
        StringBuilder out = new StringBuilder();
        for (int i = 0; i < params.size(); i++) {
            if (i > 0) {
                out.append(", ");
            }
            out.append(params.get(i).accept(this));
        }
        return out.toString();
    }

    private String printArgs(java.util.List<Node> args) {
        StringBuilder out = new StringBuilder();
        for (int i = 0; i < args.size(); i++) {
            if (i > 0) {
                out.append(", ");
            }
            out.append(args.get(i).accept(this));
        }
        return out.toString();
    }

    private static String opSymbol(TipoToken op) {
        return switch (op) {
            case MAIS -> "+";
            case MENOS -> "-";
            case VEZES -> "*";
            case DIVIDIR -> "/";
            case IGUAL_IGUAL -> "==";
            case DIFERENTE -> "!=";
            case MENOR -> "<";
            case MENOR_IGUAL -> "<=";
            case MAIOR -> ">";
            case MAIOR_IGUAL -> ">=";
            case NAO -> "!";
            default -> op.name();
        };
    }
}
