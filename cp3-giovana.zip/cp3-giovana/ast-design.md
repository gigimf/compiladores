# CP3 — Projeto da AST (grupo Giovana)

## 1. Hierarquia de nós

| Nó | Atributos | Produção(ões) |
|----|-----------|----------------|
| `ProgramNode` | `declarations: List<Node>` | `Program → Declarations EOF` |
| `VarDeclNode` | `type: TypeKind`, `name: String`, `assignOp: AssignOp?`, `initializer: Node?` | `Declaration → Type id DeclarationRest` com `Initializer ;`; `Statement → Type id Initializer ;` |
| `FuncDeclNode` | `returnType: TypeKind`, `name: String`, `parameters: List<ParamNode>`, `body: BlockNode` | `DeclarationRest → ( Parameters ) Block` |
| `ProcDeclNode` | `name: String`, `parameters: List<ParamNode>`, `body: BlockNode` | `Declaration → id ( Parameters ) Block` |
| `ParamNode` | `type: TypeKind`, `name: String` | `Parameter → Type id` |
| `BlockNode` | `statements: List<Node>` | `Block → { Statements }`; também ramo de `Statement` |
| `AssignStmtNode` | `name: String`, `operator: AssignOp`, `expression: Node` | `IdentifierStatement → AssignmentOperator Expression ;` |
| `CallStmtNode` | `name: String`, `arguments: List<Node>` | `IdentifierStatement → ( Arguments ) ;` |
| `IfStmtNode` | `condition: Node`, `thenBranch: BlockNode`, `elseBranch: BlockNode?` | `Statement → if ( Expression ) Block ElsePart` |
| `WhileStmtNode` | `condition: Node`, `body: BlockNode` | `Statement → while ( Expression ) Block` |
| `ReturnStmtNode` | `value: Node?` | `Statement → return ReturnValue ;` |
| `IntLitNode` | `lexeme: String` | `Primary → INTEGER` |
| `FloatLitNode` | `lexeme: String` | `Primary → FLOAT` |
| `BoolLitNode` | `value: boolean` | `Primary → BOOLEANO` |
| `CharLitNode` | `lexeme: String` | `Primary → CHAR_LITERAL` |
| `StringLitNode` | `lexeme: String` | `Primary → STRING` |
| `IdentNode` | `name: String` | `Primary → id` (sem chamada) |
| `BinOpNode` | `operator: TipoToken`, `left: Node`, `right: Node` | `EqualityTail`, `RelationalTail`, `AdditiveTail`, `MultiplicativeTail` |
| `UnaryOpNode` | `operator: TipoToken`, `operand: Node` | `Unary → ! / - / + Unary` |
| `CallExprNode` | `name: String`, `arguments: List<Node>` | `Primary → id ( Arguments )` |

Campos reservados para fases futuras (não implementados agora): `IdentNode` poderá referenciar símbolo na tabela; nós de expressão poderão carregar tipo inferido.

## 2. Mapeamento gramática → árvore

| Não-terminal | Destino na AST |
|--------------|----------------|
| `Program` | nó `ProgramNode` |
| `Declarations` | lista em `ProgramNode` (ε → lista vazia) |
| `Declaration` | `VarDeclNode`, `FuncDeclNode` ou `ProcDeclNode` |
| `DeclarationRest` | ramifica função vs variável global |
| `Type` | enum `TypeKind` (atributo, sem nó) |
| `Initializer` | expressão opcional + `AssignOp` em `VarDeclNode` |
| `AssignmentOperator` | enum `AssignOp` |
| `Parameters`, `ParametersTail` | lista de `ParamNode` |
| `Parameter` | `ParamNode` |
| `Block`, `Statements` | `BlockNode` / lista de comandos |
| `Statement` | nó de comando concreto |
| `IdentifierStatement` | `AssignStmtNode` ou `CallStmtNode` |
| `ElsePart` | `BlockNode` opcional em `IfStmtNode` |
| `ReturnValue` | filho opcional de `ReturnStmtNode` |
| `Arguments`, `ArgumentsTail` | listas em chamadas |
| `Expression` … `Primary` | subárvore de expressão (nós acima) |
| `Equality`, `Relational`, `Additive`, `Multiplicative`, `Unary` | estrutura via `BinOpNode` / `UnaryOpNode` |
| **Precedência (a)** `Equality`, `Relational`, `Additive`, `Multiplicative` | não são nós; viram `BinOpNode` com operador do nível |
| **Recursão à esquerda (b)** `EqualityTail`, `RelationalTail`, `AdditiveTail`, `MultiplicativeTail`, `ParametersTail`, `ArgumentsTail`, `Statements`, `Declarations` | laços no parser; operandos já montados viram `BinOpNode` aninhado à esquerda |
| **Fatoração (c)** `DeclarationRest`, `IdentifierStatement`, `CallSuffix` | escolha de ramo vira construtor/atributos do nó pai, sem nó extra |
| `CallSuffix` | fundido em `IdentNode` vs `CallExprNode` |
| Parênteses, vírgulas, `;`, chaves | apenas delimitam parsing; não geram nó |
| `LPAREN Expression RPAREN` | devolve a subárvore interna (parênteses descartados) |

## 3. Posição

Todo nó guarda `linha` e `coluna` do primeiro token que originou o nó (`Node` base). Literais e identificadores usam o token correspondente; `BinOpNode` usa o operador; blocos usam `{`.

## 4. Formato do impressor (`TreePrinter`)

Determinístico, um nó por linha:

1. Indentação: 2 espaços × profundidade (raiz profundidade 0).
2. Linha do nó: `NomeDoNó` + atributos `chave=valor` separados por espaço (ordem fixa documentada em cada `visit*`).
3. Linha seguinte: `@L<linha>C<coluna>` exclusivamente com a posição.

Exemplo (`a - b - c * d` como corpo de declaração):

```
Program
@L1C1
  VarDecl type=int name=x op==
@L1C1
    BinOp op=-
@L1C11
      Ident name=a
@L1C9
      BinOp op=-
@L1C15
        Ident name=b
@L1C13
        BinOp op=*
@L1C17
          Ident name=c
@L1C15
          Ident name=d
@L1C19
```

## 5. Reimpressor (`SourcePrinter`)

Forma canônica: toda expressão binária e unária entre parênteses; `=` e `<-` preservados; blocos `{ ... }`; ponto e vírgula após comandos. Deve ser re-analisável pelo mesmo parser (testes de ida e volta).

Adicionar `SourcePrinter` não exigiu alterar classes de nó — apenas `Visitor` + `accept` já existentes.

**Organização do código:** pastas `src/ast/` e `src/visitor/` são apenas agrupamento; as classes ficam no pacote default (sem `package`) para compilar junto com o scanner do CP1, cujos arquivos não usam pacote nomeado.

## 6. Erros sintáticos

`parseWithAst()` devolve `ParseResult`: `program == null` se houve qualquer erro; `getErros()` lista mensagens no mesmo formato do CP2. `parse()` mantém booleano para regressão.

## 7. Árvore desenhada (programa exemplo)

Programa:

```
int max(int a, int b) {
  if (a < b) {
    return b;
  } else {
    return a;
  }
}
main() {
  int i = 0;
  while (i < 10) {
    i <- i + 1;
  }
}
```

Esboço (≥15 nós):

```
Program
├── FuncDecl max
│   ├── Param a
│   ├── Param b
│   └── Block
│       └── If
│           ├── BinOp <
│           │   ├── Ident a
│           │   └── Ident b
│           ├── Block → Return → Ident b
│           └── Block → Return → Ident a
├── ProcDecl main
│   └── Block
│       ├── VarDecl i = IntLit 0
│       └── While
│           ├── BinOp <
│           └── Block → Assign i ← BinOp + ...
```

**Derivação descartada pela AST (3 exemplos):**

1. Cadeia `Expression → Equality → Relational → Additive → … → Primary → id` vira só `IdentNode`.
2. Nós `AdditiveTail` e `MultiplicativeTail` da derivação viram uma cadeia plana de `BinOpNode`.
3. Tokens `(`, `)`, `{`, `}` não aparecem — só estrutura via `BlockNode` / subexpressão de parênteses.

## 8. Testes

- `test/esperado/*.txt`: árvores esperadas (impressor), escritas à mão.
- `AstTest`: compara impressor, precedência, parênteses redundantes, ida e volta.
- `ParserTest`: regressão CP2 (mesmos vereditos e erros).

Para ajustar colunas após editar o impressor: `java -cp out TreeDump "fonte"`.
