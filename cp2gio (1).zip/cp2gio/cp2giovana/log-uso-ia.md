# Log de uso de IA — CP2

Esta versão é uma referência de estudo produzida com assistência substancial de IA, a pedido de Leandro. Não deve ser descrita como uma implementação independente das autoras do CP1. A restrição da seção 6 do enunciado não foi aplicada a esta versão de estudo, conforme solicitado; geração completa de gramática/parser não se enquadra nas categorias permitidas daquela seção.

| Data | Ferramenta | Solicitação e uso efetivo | Relação com o enunciado |
|---|---|---|---|
| 2026-10-13 | Claude Code (registro preexistente, não verificado nesta sessão) | O log anterior registrava a criação da infraestrutura genérica e modelos. Os arquivos encontrados eram esqueletos com TODOs, sem gramática e sem métodos parseX implementados. | Boilerplate declarado como permitido no registro anterior. |
| 2026-10-13 | OpenAI Codex | Leitura do enunciado e do CP1; definição da sintaxe compatível com os tokens existentes; gramática completa; cálculo e verificação FIRST/FOLLOW/LL(1); implementação dos métodos do parser e recuperação; CLI; testes, exemplos e documentação. | Assistência integral para estudo; excede as permissões da seção 6. |
| 2026-10-13 | OpenAI Codex com execução local de Java/Python | Compilação, execução de testes, comparação com reconhecedor independente, teste de integração da CLI e comparação dos arquivos léxicos por SHA-256. | Validação automatizada da versão de estudo. Resultados reproduzíveis em test/verification.log. |

Não foram usados serviços externos para enviar o código nem alterados os arquivos léxicos do CP1. A escolha de procedimentos sem tipo, a obrigatoriedade de chaves e demais decisões sintáticas foram feitas nesta revisão; não há evidência de que representem a sintaxe originalmente pretendida pelas autoras.
