import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

/** Single-threaded CLI. The CP1 scanner reports lexical errors on stdout. */
public final class Main {
    private Main() {}

    public static void main(String[] args) {
        if (args.length != 1) {
            System.err.println("Uso: java -cp out Main arquivo.smol");
            System.exit(2);
        }
        try {
            String source = Files.readString(Path.of(args[0]), StandardCharsets.UTF_8);
            ByteArrayOutputStream diagnostics = new ByteArrayOutputStream();
            PrintStream original = System.out;
            List<Token> tokens;
            // Adapt the legacy diagnostic channel without editing Scanner/Token.
            try (PrintStream capture = new PrintStream(diagnostics, true, StandardCharsets.UTF_8)) {
                System.setOut(capture);
                try {
                    tokens = new Scanner(source).scanTokens();
                } finally {
                    System.setOut(original);
                }
            }
            String lexicalErrors = diagnostics.toString(StandardCharsets.UTF_8);
            Parser parser = new Parser(tokens);
            boolean syntaxAccepted = parser.parse();
            if (!lexicalErrors.isEmpty()) System.err.print(lexicalErrors);
            parser.getErros().forEach(System.err::println);
            boolean accepted = syntaxAccepted && lexicalErrors.isEmpty();
            System.out.println(accepted ? "ACEITO" : "REJEITADO");
            if (!accepted) System.exit(1);
        } catch (IOException exception) {
            System.err.println("Falha ao ler arquivo: " + exception.getMessage());
            System.exit(2);
        }
    }
}
