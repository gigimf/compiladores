import java.util.ArrayList;
import java.util.EnumSet;
import java.util.List;
import java.util.Set;

/**
 * LL(1) recursive-descent recognizer. No AST and no semantic analysis.
 * Each switch is the SELECT table of exactly one BNF nonterminal.
 * Right-tail recursion is implemented as iteration to bound stack usage.
 * Reproduce/check the translation with tools/verify_grammar.py.
 */
public final class Parser {
    private final List<Token> tokens;
    private final List<String> errors = new ArrayList<>();
    private int current;

    public Parser(List<Token> tokens) {
        if (tokens == null || tokens.isEmpty()) {
            throw new IllegalArgumentException("Token stream must end in EOF");
        }
        this.tokens = List.copyOf(tokens);
        for (int i = 0; i < tokens.size(); i++) {
            if (tokens.get(i).getTipo() == null
                    || (tokens.get(i).getTipo() == TipoToken.EOF) != (i == tokens.size() - 1)) {
                throw new IllegalArgumentException("Exactly one EOF is required, at the end");
            }
        }
    }

    /** Restart recognition, returning true only if no syntax errors occurred. */
    public boolean parse() {
        current = 0;
        errors.clear();
        parseProgram();
        return errors.isEmpty();
    }

    public List<String> getErros() {
        return List.copyOf(errors);
    }

    private Token lookahead() { return tokens.get(current); }

    private void advance() {
        if (lookahead().getTipo() != TipoToken.EOF) current++;
    }

    private void match(TipoToken expected) {
        if (lookahead().getTipo() != expected) {
            throw new SyntaxFailure("esperado " + expected);
        }
        advance();
    }

    private void recover(String rule, SyntaxFailure failure, Set<TipoToken> follow) {
        Token token = lookahead();
        errors.add("erro sintatico na linha " + token.getLinha() + ", coluna "
                + token.getColuna() + " em " + rule + ": " + failure.getMessage()
                + "; encontrado " + token.getTipo() + " '" + token.getLexema() + "'");
        while (lookahead().getTipo() != TipoToken.EOF
                && !follow.contains(lookahead().getTipo())) {
            advance();
        }
    }

    private static final class SyntaxFailure extends RuntimeException {
        private static final long serialVersionUID = 1L;
        SyntaxFailure(String message) { super(message, null, false, false); }
    }

    private static final Set<TipoToken> FOLLOW_Program = EnumSet.of(TipoToken.EOF);
    private static final Set<TipoToken> FOLLOW_Declarations = EnumSet.of(TipoToken.EOF);
    private static final Set<TipoToken> FOLLOW_Declaration = EnumSet.of(TipoToken.BOOL, TipoToken.CHAR, TipoToken.DOUBLE, TipoToken.EOF, TipoToken.IDENTIFICADOR, TipoToken.INT, TipoToken.STRING_TYPE);
    private static final Set<TipoToken> FOLLOW_DeclarationRest = EnumSet.of(TipoToken.BOOL, TipoToken.CHAR, TipoToken.DOUBLE, TipoToken.EOF, TipoToken.IDENTIFICADOR, TipoToken.INT, TipoToken.STRING_TYPE);
    private static final Set<TipoToken> FOLLOW_Type = EnumSet.of(TipoToken.IDENTIFICADOR);
    private static final Set<TipoToken> FOLLOW_Initializer = EnumSet.of(TipoToken.PONTO_VIRGULA);
    private static final Set<TipoToken> FOLLOW_AssignmentOperator = EnumSet.of(TipoToken.BOOLEANO, TipoToken.CHAR_LITERAL, TipoToken.FLOAT, TipoToken.IDENTIFICADOR, TipoToken.INTEGER, TipoToken.LPAREN, TipoToken.MAIS, TipoToken.MENOS, TipoToken.NAO, TipoToken.STRING);
    private static final Set<TipoToken> FOLLOW_Parameters = EnumSet.of(TipoToken.RPAREN);
    private static final Set<TipoToken> FOLLOW_ParametersTail = EnumSet.of(TipoToken.RPAREN);
    private static final Set<TipoToken> FOLLOW_Parameter = EnumSet.of(TipoToken.RPAREN, TipoToken.VIRGULA);
    private static final Set<TipoToken> FOLLOW_Block = EnumSet.of(TipoToken.ABRE_CHAVE, TipoToken.BOOL, TipoToken.CHAR, TipoToken.DOUBLE, TipoToken.ELSE, TipoToken.EOF, TipoToken.FECHA_CHAVE, TipoToken.IDENTIFICADOR, TipoToken.IF, TipoToken.INT, TipoToken.RETURN, TipoToken.STRING_TYPE, TipoToken.WHILE);
    private static final Set<TipoToken> FOLLOW_Statements = EnumSet.of(TipoToken.FECHA_CHAVE);
    private static final Set<TipoToken> FOLLOW_Statement = EnumSet.of(TipoToken.ABRE_CHAVE, TipoToken.BOOL, TipoToken.CHAR, TipoToken.DOUBLE, TipoToken.FECHA_CHAVE, TipoToken.IDENTIFICADOR, TipoToken.IF, TipoToken.INT, TipoToken.RETURN, TipoToken.STRING_TYPE, TipoToken.WHILE);
    private static final Set<TipoToken> FOLLOW_IdentifierStatement = EnumSet.of(TipoToken.ABRE_CHAVE, TipoToken.BOOL, TipoToken.CHAR, TipoToken.DOUBLE, TipoToken.FECHA_CHAVE, TipoToken.IDENTIFICADOR, TipoToken.IF, TipoToken.INT, TipoToken.RETURN, TipoToken.STRING_TYPE, TipoToken.WHILE);
    private static final Set<TipoToken> FOLLOW_ElsePart = EnumSet.of(TipoToken.ABRE_CHAVE, TipoToken.BOOL, TipoToken.CHAR, TipoToken.DOUBLE, TipoToken.FECHA_CHAVE, TipoToken.IDENTIFICADOR, TipoToken.IF, TipoToken.INT, TipoToken.RETURN, TipoToken.STRING_TYPE, TipoToken.WHILE);
    private static final Set<TipoToken> FOLLOW_ReturnValue = EnumSet.of(TipoToken.PONTO_VIRGULA);
    private static final Set<TipoToken> FOLLOW_Arguments = EnumSet.of(TipoToken.RPAREN);
    private static final Set<TipoToken> FOLLOW_ArgumentsTail = EnumSet.of(TipoToken.RPAREN);
    private static final Set<TipoToken> FOLLOW_Expression = EnumSet.of(TipoToken.PONTO_VIRGULA, TipoToken.RPAREN, TipoToken.VIRGULA);
    private static final Set<TipoToken> FOLLOW_Equality = EnumSet.of(TipoToken.PONTO_VIRGULA, TipoToken.RPAREN, TipoToken.VIRGULA);
    private static final Set<TipoToken> FOLLOW_EqualityTail = EnumSet.of(TipoToken.PONTO_VIRGULA, TipoToken.RPAREN, TipoToken.VIRGULA);
    private static final Set<TipoToken> FOLLOW_EqualityOperator = EnumSet.of(TipoToken.BOOLEANO, TipoToken.CHAR_LITERAL, TipoToken.FLOAT, TipoToken.IDENTIFICADOR, TipoToken.INTEGER, TipoToken.LPAREN, TipoToken.MAIS, TipoToken.MENOS, TipoToken.NAO, TipoToken.STRING);
    private static final Set<TipoToken> FOLLOW_Relational = EnumSet.of(TipoToken.DIFERENTE, TipoToken.IGUAL_IGUAL, TipoToken.PONTO_VIRGULA, TipoToken.RPAREN, TipoToken.VIRGULA);
    private static final Set<TipoToken> FOLLOW_RelationalTail = EnumSet.of(TipoToken.DIFERENTE, TipoToken.IGUAL_IGUAL, TipoToken.PONTO_VIRGULA, TipoToken.RPAREN, TipoToken.VIRGULA);
    private static final Set<TipoToken> FOLLOW_RelationalOperator = EnumSet.of(TipoToken.BOOLEANO, TipoToken.CHAR_LITERAL, TipoToken.FLOAT, TipoToken.IDENTIFICADOR, TipoToken.INTEGER, TipoToken.LPAREN, TipoToken.MAIS, TipoToken.MENOS, TipoToken.NAO, TipoToken.STRING);
    private static final Set<TipoToken> FOLLOW_Additive = EnumSet.of(TipoToken.DIFERENTE, TipoToken.IGUAL_IGUAL, TipoToken.MAIOR, TipoToken.MAIOR_IGUAL, TipoToken.MENOR, TipoToken.MENOR_IGUAL, TipoToken.PONTO_VIRGULA, TipoToken.RPAREN, TipoToken.VIRGULA);
    private static final Set<TipoToken> FOLLOW_AdditiveTail = EnumSet.of(TipoToken.DIFERENTE, TipoToken.IGUAL_IGUAL, TipoToken.MAIOR, TipoToken.MAIOR_IGUAL, TipoToken.MENOR, TipoToken.MENOR_IGUAL, TipoToken.PONTO_VIRGULA, TipoToken.RPAREN, TipoToken.VIRGULA);
    private static final Set<TipoToken> FOLLOW_AdditiveOperator = EnumSet.of(TipoToken.BOOLEANO, TipoToken.CHAR_LITERAL, TipoToken.FLOAT, TipoToken.IDENTIFICADOR, TipoToken.INTEGER, TipoToken.LPAREN, TipoToken.MAIS, TipoToken.MENOS, TipoToken.NAO, TipoToken.STRING);
    private static final Set<TipoToken> FOLLOW_Multiplicative = EnumSet.of(TipoToken.DIFERENTE, TipoToken.IGUAL_IGUAL, TipoToken.MAIOR, TipoToken.MAIOR_IGUAL, TipoToken.MAIS, TipoToken.MENOR, TipoToken.MENOR_IGUAL, TipoToken.MENOS, TipoToken.PONTO_VIRGULA, TipoToken.RPAREN, TipoToken.VIRGULA);
    private static final Set<TipoToken> FOLLOW_MultiplicativeTail = EnumSet.of(TipoToken.DIFERENTE, TipoToken.IGUAL_IGUAL, TipoToken.MAIOR, TipoToken.MAIOR_IGUAL, TipoToken.MAIS, TipoToken.MENOR, TipoToken.MENOR_IGUAL, TipoToken.MENOS, TipoToken.PONTO_VIRGULA, TipoToken.RPAREN, TipoToken.VIRGULA);
    private static final Set<TipoToken> FOLLOW_MultiplicativeOperator = EnumSet.of(TipoToken.BOOLEANO, TipoToken.CHAR_LITERAL, TipoToken.FLOAT, TipoToken.IDENTIFICADOR, TipoToken.INTEGER, TipoToken.LPAREN, TipoToken.MAIS, TipoToken.MENOS, TipoToken.NAO, TipoToken.STRING);
    private static final Set<TipoToken> FOLLOW_Unary = EnumSet.of(TipoToken.DIFERENTE, TipoToken.DIVIDIR, TipoToken.IGUAL_IGUAL, TipoToken.MAIOR, TipoToken.MAIOR_IGUAL, TipoToken.MAIS, TipoToken.MENOR, TipoToken.MENOR_IGUAL, TipoToken.MENOS, TipoToken.PONTO_VIRGULA, TipoToken.RPAREN, TipoToken.VEZES, TipoToken.VIRGULA);
    private static final Set<TipoToken> FOLLOW_Primary = EnumSet.of(TipoToken.DIFERENTE, TipoToken.DIVIDIR, TipoToken.IGUAL_IGUAL, TipoToken.MAIOR, TipoToken.MAIOR_IGUAL, TipoToken.MAIS, TipoToken.MENOR, TipoToken.MENOR_IGUAL, TipoToken.MENOS, TipoToken.PONTO_VIRGULA, TipoToken.RPAREN, TipoToken.VEZES, TipoToken.VIRGULA);
    private static final Set<TipoToken> FOLLOW_CallSuffix = EnumSet.of(TipoToken.DIFERENTE, TipoToken.DIVIDIR, TipoToken.IGUAL_IGUAL, TipoToken.MAIOR, TipoToken.MAIOR_IGUAL, TipoToken.MAIS, TipoToken.MENOR, TipoToken.MENOR_IGUAL, TipoToken.MENOS, TipoToken.PONTO_VIRGULA, TipoToken.RPAREN, TipoToken.VEZES, TipoToken.VIRGULA);

    // Program -> Declarations EOF
    private void parseProgram() {
        try {
            switch (lookahead().getTipo()) {
                case BOOL, CHAR, DOUBLE, EOF, IDENTIFICADOR, INT, STRING_TYPE -> {
                    parseDeclarations();
                    match(TipoToken.EOF);
                    return;
                }
                default -> throw new SyntaxFailure("esperado um de { BOOL, CHAR, DOUBLE, EOF, IDENTIFICADOR, INT, STRING_TYPE }");
            }
        } catch (SyntaxFailure failure) {
            recover("Program", failure, FOLLOW_Program);
        }
    }

    // Declarations -> Declaration Declarations | epsilon
    private void parseDeclarations() {
        try {
            while (true) {
                switch (lookahead().getTipo()) {
                    case BOOL, CHAR, DOUBLE, IDENTIFICADOR, INT, STRING_TYPE -> {
                        parseDeclaration();
                    }
                    case EOF -> {
                        // Epsilon is selected only on FOLLOW, never by default.
                        return;
                    }
                    default -> throw new SyntaxFailure("esperado um de { BOOL, CHAR, DOUBLE, EOF, IDENTIFICADOR, INT, STRING_TYPE }");
                }
            }
        } catch (SyntaxFailure failure) {
            recover("Declarations", failure, FOLLOW_Declarations);
        }
    }

    // Declaration -> Type IDENTIFICADOR DeclarationRest | IDENTIFICADOR LPAREN Parameters RPAREN Block
    private void parseDeclaration() {
        try {
            switch (lookahead().getTipo()) {
                case BOOL, CHAR, DOUBLE, INT, STRING_TYPE -> {
                    parseType();
                    match(TipoToken.IDENTIFICADOR);
                    parseDeclarationRest();
                    return;
                }
                case IDENTIFICADOR -> {
                    match(TipoToken.IDENTIFICADOR);
                    match(TipoToken.LPAREN);
                    parseParameters();
                    match(TipoToken.RPAREN);
                    parseBlock();
                    return;
                }
                default -> throw new SyntaxFailure("esperado um de { BOOL, CHAR, DOUBLE, IDENTIFICADOR, INT, STRING_TYPE }");
            }
        } catch (SyntaxFailure failure) {
            recover("Declaration", failure, FOLLOW_Declaration);
        }
    }

    // DeclarationRest -> LPAREN Parameters RPAREN Block | Initializer PONTO_VIRGULA
    private void parseDeclarationRest() {
        try {
            switch (lookahead().getTipo()) {
                case LPAREN -> {
                    match(TipoToken.LPAREN);
                    parseParameters();
                    match(TipoToken.RPAREN);
                    parseBlock();
                    return;
                }
                case ATRIBUI, IGUAL, PONTO_VIRGULA -> {
                    parseInitializer();
                    match(TipoToken.PONTO_VIRGULA);
                    return;
                }
                default -> throw new SyntaxFailure("esperado um de { ATRIBUI, IGUAL, LPAREN, PONTO_VIRGULA }");
            }
        } catch (SyntaxFailure failure) {
            recover("DeclarationRest", failure, FOLLOW_DeclarationRest);
        }
    }

    // Type -> INT | DOUBLE | BOOL | CHAR | STRING_TYPE
    private void parseType() {
        try {
            switch (lookahead().getTipo()) {
                case INT -> {
                    match(TipoToken.INT);
                    return;
                }
                case DOUBLE -> {
                    match(TipoToken.DOUBLE);
                    return;
                }
                case BOOL -> {
                    match(TipoToken.BOOL);
                    return;
                }
                case CHAR -> {
                    match(TipoToken.CHAR);
                    return;
                }
                case STRING_TYPE -> {
                    match(TipoToken.STRING_TYPE);
                    return;
                }
                default -> throw new SyntaxFailure("esperado um de { BOOL, CHAR, DOUBLE, INT, STRING_TYPE }");
            }
        } catch (SyntaxFailure failure) {
            recover("Type", failure, FOLLOW_Type);
        }
    }

    // Initializer -> AssignmentOperator Expression | epsilon
    private void parseInitializer() {
        try {
            switch (lookahead().getTipo()) {
                case ATRIBUI, IGUAL -> {
                    parseAssignmentOperator();
                    parseExpression();
                    return;
                }
                case PONTO_VIRGULA -> {
                    // Epsilon is selected only on FOLLOW, never by default.
                    return;
                }
                default -> throw new SyntaxFailure("esperado um de { ATRIBUI, IGUAL, PONTO_VIRGULA }");
            }
        } catch (SyntaxFailure failure) {
            recover("Initializer", failure, FOLLOW_Initializer);
        }
    }

    // AssignmentOperator -> IGUAL | ATRIBUI
    private void parseAssignmentOperator() {
        try {
            switch (lookahead().getTipo()) {
                case IGUAL -> {
                    match(TipoToken.IGUAL);
                    return;
                }
                case ATRIBUI -> {
                    match(TipoToken.ATRIBUI);
                    return;
                }
                default -> throw new SyntaxFailure("esperado um de { ATRIBUI, IGUAL }");
            }
        } catch (SyntaxFailure failure) {
            recover("AssignmentOperator", failure, FOLLOW_AssignmentOperator);
        }
    }

    // Parameters -> Parameter ParametersTail | epsilon
    private void parseParameters() {
        try {
            switch (lookahead().getTipo()) {
                case BOOL, CHAR, DOUBLE, INT, STRING_TYPE -> {
                    parseParameter();
                    parseParametersTail();
                    return;
                }
                case RPAREN -> {
                    // Epsilon is selected only on FOLLOW, never by default.
                    return;
                }
                default -> throw new SyntaxFailure("esperado um de { BOOL, CHAR, DOUBLE, INT, RPAREN, STRING_TYPE }");
            }
        } catch (SyntaxFailure failure) {
            recover("Parameters", failure, FOLLOW_Parameters);
        }
    }

    // ParametersTail -> VIRGULA Parameter ParametersTail | epsilon
    private void parseParametersTail() {
        try {
            while (true) {
                switch (lookahead().getTipo()) {
                    case VIRGULA -> {
                        match(TipoToken.VIRGULA);
                        parseParameter();
                    }
                    case RPAREN -> {
                        // Epsilon is selected only on FOLLOW, never by default.
                        return;
                    }
                    default -> throw new SyntaxFailure("esperado um de { RPAREN, VIRGULA }");
                }
            }
        } catch (SyntaxFailure failure) {
            recover("ParametersTail", failure, FOLLOW_ParametersTail);
        }
    }

    // Parameter -> Type IDENTIFICADOR
    private void parseParameter() {
        try {
            switch (lookahead().getTipo()) {
                case BOOL, CHAR, DOUBLE, INT, STRING_TYPE -> {
                    parseType();
                    match(TipoToken.IDENTIFICADOR);
                    return;
                }
                default -> throw new SyntaxFailure("esperado um de { BOOL, CHAR, DOUBLE, INT, STRING_TYPE }");
            }
        } catch (SyntaxFailure failure) {
            recover("Parameter", failure, FOLLOW_Parameter);
        }
    }

    // Block -> ABRE_CHAVE Statements FECHA_CHAVE
    private void parseBlock() {
        try {
            switch (lookahead().getTipo()) {
                case ABRE_CHAVE -> {
                    match(TipoToken.ABRE_CHAVE);
                    parseStatements();
                    match(TipoToken.FECHA_CHAVE);
                    return;
                }
                default -> throw new SyntaxFailure("esperado um de { ABRE_CHAVE }");
            }
        } catch (SyntaxFailure failure) {
            recover("Block", failure, FOLLOW_Block);
        }
    }

    // Statements -> Statement Statements | epsilon
    private void parseStatements() {
        try {
            while (true) {
                switch (lookahead().getTipo()) {
                    case ABRE_CHAVE, BOOL, CHAR, DOUBLE, IDENTIFICADOR, IF, INT, RETURN, STRING_TYPE, WHILE -> {
                        parseStatement();
                    }
                    case FECHA_CHAVE -> {
                        // Epsilon is selected only on FOLLOW, never by default.
                        return;
                    }
                    default -> throw new SyntaxFailure("esperado um de { ABRE_CHAVE, BOOL, CHAR, DOUBLE, FECHA_CHAVE, IDENTIFICADOR, IF, INT, RETURN, STRING_TYPE, WHILE }");
                }
            }
        } catch (SyntaxFailure failure) {
            recover("Statements", failure, FOLLOW_Statements);
        }
    }

    // Statement -> Type IDENTIFICADOR Initializer PONTO_VIRGULA | IDENTIFICADOR IdentifierStatement | IF LPAREN Expression RPAREN Block ElsePart | WHILE LPAREN Expression RPAREN Block | RETURN ReturnValue PONTO_VIRGULA | Block
    private void parseStatement() {
        try {
            switch (lookahead().getTipo()) {
                case BOOL, CHAR, DOUBLE, INT, STRING_TYPE -> {
                    parseType();
                    match(TipoToken.IDENTIFICADOR);
                    parseInitializer();
                    match(TipoToken.PONTO_VIRGULA);
                    return;
                }
                case IDENTIFICADOR -> {
                    match(TipoToken.IDENTIFICADOR);
                    parseIdentifierStatement();
                    return;
                }
                case IF -> {
                    match(TipoToken.IF);
                    match(TipoToken.LPAREN);
                    parseExpression();
                    match(TipoToken.RPAREN);
                    parseBlock();
                    parseElsePart();
                    return;
                }
                case WHILE -> {
                    match(TipoToken.WHILE);
                    match(TipoToken.LPAREN);
                    parseExpression();
                    match(TipoToken.RPAREN);
                    parseBlock();
                    return;
                }
                case RETURN -> {
                    match(TipoToken.RETURN);
                    parseReturnValue();
                    match(TipoToken.PONTO_VIRGULA);
                    return;
                }
                case ABRE_CHAVE -> {
                    parseBlock();
                    return;
                }
                default -> throw new SyntaxFailure("esperado um de { ABRE_CHAVE, BOOL, CHAR, DOUBLE, IDENTIFICADOR, IF, INT, RETURN, STRING_TYPE, WHILE }");
            }
        } catch (SyntaxFailure failure) {
            recover("Statement", failure, FOLLOW_Statement);
        }
    }

    // IdentifierStatement -> AssignmentOperator Expression PONTO_VIRGULA | LPAREN Arguments RPAREN PONTO_VIRGULA
    private void parseIdentifierStatement() {
        try {
            switch (lookahead().getTipo()) {
                case ATRIBUI, IGUAL -> {
                    parseAssignmentOperator();
                    parseExpression();
                    match(TipoToken.PONTO_VIRGULA);
                    return;
                }
                case LPAREN -> {
                    match(TipoToken.LPAREN);
                    parseArguments();
                    match(TipoToken.RPAREN);
                    match(TipoToken.PONTO_VIRGULA);
                    return;
                }
                default -> throw new SyntaxFailure("esperado um de { ATRIBUI, IGUAL, LPAREN }");
            }
        } catch (SyntaxFailure failure) {
            recover("IdentifierStatement", failure, FOLLOW_IdentifierStatement);
        }
    }

    // ElsePart -> ELSE Block | epsilon
    private void parseElsePart() {
        try {
            switch (lookahead().getTipo()) {
                case ELSE -> {
                    match(TipoToken.ELSE);
                    parseBlock();
                    return;
                }
                case ABRE_CHAVE, BOOL, CHAR, DOUBLE, FECHA_CHAVE, IDENTIFICADOR, IF, INT, RETURN, STRING_TYPE, WHILE -> {
                    // Epsilon is selected only on FOLLOW, never by default.
                    return;
                }
                default -> throw new SyntaxFailure("esperado um de { ABRE_CHAVE, BOOL, CHAR, DOUBLE, ELSE, FECHA_CHAVE, IDENTIFICADOR, IF, INT, RETURN, STRING_TYPE, WHILE }");
            }
        } catch (SyntaxFailure failure) {
            recover("ElsePart", failure, FOLLOW_ElsePart);
        }
    }

    // ReturnValue -> Expression | epsilon
    private void parseReturnValue() {
        try {
            switch (lookahead().getTipo()) {
                case BOOLEANO, CHAR_LITERAL, FLOAT, IDENTIFICADOR, INTEGER, LPAREN, MAIS, MENOS, NAO, STRING -> {
                    parseExpression();
                    return;
                }
                case PONTO_VIRGULA -> {
                    // Epsilon is selected only on FOLLOW, never by default.
                    return;
                }
                default -> throw new SyntaxFailure("esperado um de { BOOLEANO, CHAR_LITERAL, FLOAT, IDENTIFICADOR, INTEGER, LPAREN, MAIS, MENOS, NAO, PONTO_VIRGULA, STRING }");
            }
        } catch (SyntaxFailure failure) {
            recover("ReturnValue", failure, FOLLOW_ReturnValue);
        }
    }

    // Arguments -> Expression ArgumentsTail | epsilon
    private void parseArguments() {
        try {
            switch (lookahead().getTipo()) {
                case BOOLEANO, CHAR_LITERAL, FLOAT, IDENTIFICADOR, INTEGER, LPAREN, MAIS, MENOS, NAO, STRING -> {
                    parseExpression();
                    parseArgumentsTail();
                    return;
                }
                case RPAREN -> {
                    // Epsilon is selected only on FOLLOW, never by default.
                    return;
                }
                default -> throw new SyntaxFailure("esperado um de { BOOLEANO, CHAR_LITERAL, FLOAT, IDENTIFICADOR, INTEGER, LPAREN, MAIS, MENOS, NAO, RPAREN, STRING }");
            }
        } catch (SyntaxFailure failure) {
            recover("Arguments", failure, FOLLOW_Arguments);
        }
    }

    // ArgumentsTail -> VIRGULA Expression ArgumentsTail | epsilon
    private void parseArgumentsTail() {
        try {
            while (true) {
                switch (lookahead().getTipo()) {
                    case VIRGULA -> {
                        match(TipoToken.VIRGULA);
                        parseExpression();
                    }
                    case RPAREN -> {
                        // Epsilon is selected only on FOLLOW, never by default.
                        return;
                    }
                    default -> throw new SyntaxFailure("esperado um de { RPAREN, VIRGULA }");
                }
            }
        } catch (SyntaxFailure failure) {
            recover("ArgumentsTail", failure, FOLLOW_ArgumentsTail);
        }
    }

    // Expression -> Equality
    private void parseExpression() {
        try {
            switch (lookahead().getTipo()) {
                case BOOLEANO, CHAR_LITERAL, FLOAT, IDENTIFICADOR, INTEGER, LPAREN, MAIS, MENOS, NAO, STRING -> {
                    parseEquality();
                    return;
                }
                default -> throw new SyntaxFailure("esperado um de { BOOLEANO, CHAR_LITERAL, FLOAT, IDENTIFICADOR, INTEGER, LPAREN, MAIS, MENOS, NAO, STRING }");
            }
        } catch (SyntaxFailure failure) {
            recover("Expression", failure, FOLLOW_Expression);
        }
    }

    // Equality -> Relational EqualityTail
    private void parseEquality() {
        try {
            switch (lookahead().getTipo()) {
                case BOOLEANO, CHAR_LITERAL, FLOAT, IDENTIFICADOR, INTEGER, LPAREN, MAIS, MENOS, NAO, STRING -> {
                    parseRelational();
                    parseEqualityTail();
                    return;
                }
                default -> throw new SyntaxFailure("esperado um de { BOOLEANO, CHAR_LITERAL, FLOAT, IDENTIFICADOR, INTEGER, LPAREN, MAIS, MENOS, NAO, STRING }");
            }
        } catch (SyntaxFailure failure) {
            recover("Equality", failure, FOLLOW_Equality);
        }
    }

    // EqualityTail -> EqualityOperator Relational EqualityTail | epsilon
    private void parseEqualityTail() {
        try {
            while (true) {
                switch (lookahead().getTipo()) {
                    case DIFERENTE, IGUAL_IGUAL -> {
                        parseEqualityOperator();
                        parseRelational();
                    }
                    case PONTO_VIRGULA, RPAREN, VIRGULA -> {
                        // Epsilon is selected only on FOLLOW, never by default.
                        return;
                    }
                    default -> throw new SyntaxFailure("esperado um de { DIFERENTE, IGUAL_IGUAL, PONTO_VIRGULA, RPAREN, VIRGULA }");
                }
            }
        } catch (SyntaxFailure failure) {
            recover("EqualityTail", failure, FOLLOW_EqualityTail);
        }
    }

    // EqualityOperator -> IGUAL_IGUAL | DIFERENTE
    private void parseEqualityOperator() {
        try {
            switch (lookahead().getTipo()) {
                case IGUAL_IGUAL -> {
                    match(TipoToken.IGUAL_IGUAL);
                    return;
                }
                case DIFERENTE -> {
                    match(TipoToken.DIFERENTE);
                    return;
                }
                default -> throw new SyntaxFailure("esperado um de { DIFERENTE, IGUAL_IGUAL }");
            }
        } catch (SyntaxFailure failure) {
            recover("EqualityOperator", failure, FOLLOW_EqualityOperator);
        }
    }

    // Relational -> Additive RelationalTail
    private void parseRelational() {
        try {
            switch (lookahead().getTipo()) {
                case BOOLEANO, CHAR_LITERAL, FLOAT, IDENTIFICADOR, INTEGER, LPAREN, MAIS, MENOS, NAO, STRING -> {
                    parseAdditive();
                    parseRelationalTail();
                    return;
                }
                default -> throw new SyntaxFailure("esperado um de { BOOLEANO, CHAR_LITERAL, FLOAT, IDENTIFICADOR, INTEGER, LPAREN, MAIS, MENOS, NAO, STRING }");
            }
        } catch (SyntaxFailure failure) {
            recover("Relational", failure, FOLLOW_Relational);
        }
    }

    // RelationalTail -> RelationalOperator Additive RelationalTail | epsilon
    private void parseRelationalTail() {
        try {
            while (true) {
                switch (lookahead().getTipo()) {
                    case MAIOR, MAIOR_IGUAL, MENOR, MENOR_IGUAL -> {
                        parseRelationalOperator();
                        parseAdditive();
                    }
                    case DIFERENTE, IGUAL_IGUAL, PONTO_VIRGULA, RPAREN, VIRGULA -> {
                        // Epsilon is selected only on FOLLOW, never by default.
                        return;
                    }
                    default -> throw new SyntaxFailure("esperado um de { DIFERENTE, IGUAL_IGUAL, MAIOR, MAIOR_IGUAL, MENOR, MENOR_IGUAL, PONTO_VIRGULA, RPAREN, VIRGULA }");
                }
            }
        } catch (SyntaxFailure failure) {
            recover("RelationalTail", failure, FOLLOW_RelationalTail);
        }
    }

    // RelationalOperator -> MENOR | MENOR_IGUAL | MAIOR | MAIOR_IGUAL
    private void parseRelationalOperator() {
        try {
            switch (lookahead().getTipo()) {
                case MENOR -> {
                    match(TipoToken.MENOR);
                    return;
                }
                case MENOR_IGUAL -> {
                    match(TipoToken.MENOR_IGUAL);
                    return;
                }
                case MAIOR -> {
                    match(TipoToken.MAIOR);
                    return;
                }
                case MAIOR_IGUAL -> {
                    match(TipoToken.MAIOR_IGUAL);
                    return;
                }
                default -> throw new SyntaxFailure("esperado um de { MAIOR, MAIOR_IGUAL, MENOR, MENOR_IGUAL }");
            }
        } catch (SyntaxFailure failure) {
            recover("RelationalOperator", failure, FOLLOW_RelationalOperator);
        }
    }

    // Additive -> Multiplicative AdditiveTail
    private void parseAdditive() {
        try {
            switch (lookahead().getTipo()) {
                case BOOLEANO, CHAR_LITERAL, FLOAT, IDENTIFICADOR, INTEGER, LPAREN, MAIS, MENOS, NAO, STRING -> {
                    parseMultiplicative();
                    parseAdditiveTail();
                    return;
                }
                default -> throw new SyntaxFailure("esperado um de { BOOLEANO, CHAR_LITERAL, FLOAT, IDENTIFICADOR, INTEGER, LPAREN, MAIS, MENOS, NAO, STRING }");
            }
        } catch (SyntaxFailure failure) {
            recover("Additive", failure, FOLLOW_Additive);
        }
    }

    // AdditiveTail -> AdditiveOperator Multiplicative AdditiveTail | epsilon
    private void parseAdditiveTail() {
        try {
            while (true) {
                switch (lookahead().getTipo()) {
                    case MAIS, MENOS -> {
                        parseAdditiveOperator();
                        parseMultiplicative();
                    }
                    case DIFERENTE, IGUAL_IGUAL, MAIOR, MAIOR_IGUAL, MENOR, MENOR_IGUAL, PONTO_VIRGULA, RPAREN, VIRGULA -> {
                        // Epsilon is selected only on FOLLOW, never by default.
                        return;
                    }
                    default -> throw new SyntaxFailure("esperado um de { DIFERENTE, IGUAL_IGUAL, MAIOR, MAIOR_IGUAL, MAIS, MENOR, MENOR_IGUAL, MENOS, PONTO_VIRGULA, RPAREN, VIRGULA }");
                }
            }
        } catch (SyntaxFailure failure) {
            recover("AdditiveTail", failure, FOLLOW_AdditiveTail);
        }
    }

    // AdditiveOperator -> MAIS | MENOS
    private void parseAdditiveOperator() {
        try {
            switch (lookahead().getTipo()) {
                case MAIS -> {
                    match(TipoToken.MAIS);
                    return;
                }
                case MENOS -> {
                    match(TipoToken.MENOS);
                    return;
                }
                default -> throw new SyntaxFailure("esperado um de { MAIS, MENOS }");
            }
        } catch (SyntaxFailure failure) {
            recover("AdditiveOperator", failure, FOLLOW_AdditiveOperator);
        }
    }

    // Multiplicative -> Unary MultiplicativeTail
    private void parseMultiplicative() {
        try {
            switch (lookahead().getTipo()) {
                case BOOLEANO, CHAR_LITERAL, FLOAT, IDENTIFICADOR, INTEGER, LPAREN, MAIS, MENOS, NAO, STRING -> {
                    parseUnary();
                    parseMultiplicativeTail();
                    return;
                }
                default -> throw new SyntaxFailure("esperado um de { BOOLEANO, CHAR_LITERAL, FLOAT, IDENTIFICADOR, INTEGER, LPAREN, MAIS, MENOS, NAO, STRING }");
            }
        } catch (SyntaxFailure failure) {
            recover("Multiplicative", failure, FOLLOW_Multiplicative);
        }
    }

    // MultiplicativeTail -> MultiplicativeOperator Unary MultiplicativeTail | epsilon
    private void parseMultiplicativeTail() {
        try {
            while (true) {
                switch (lookahead().getTipo()) {
                    case DIVIDIR, VEZES -> {
                        parseMultiplicativeOperator();
                        parseUnary();
                    }
                    case DIFERENTE, IGUAL_IGUAL, MAIOR, MAIOR_IGUAL, MAIS, MENOR, MENOR_IGUAL, MENOS, PONTO_VIRGULA, RPAREN, VIRGULA -> {
                        // Epsilon is selected only on FOLLOW, never by default.
                        return;
                    }
                    default -> throw new SyntaxFailure("esperado um de { DIFERENTE, DIVIDIR, IGUAL_IGUAL, MAIOR, MAIOR_IGUAL, MAIS, MENOR, MENOR_IGUAL, MENOS, PONTO_VIRGULA, RPAREN, VEZES, VIRGULA }");
                }
            }
        } catch (SyntaxFailure failure) {
            recover("MultiplicativeTail", failure, FOLLOW_MultiplicativeTail);
        }
    }

    // MultiplicativeOperator -> VEZES | DIVIDIR
    private void parseMultiplicativeOperator() {
        try {
            switch (lookahead().getTipo()) {
                case VEZES -> {
                    match(TipoToken.VEZES);
                    return;
                }
                case DIVIDIR -> {
                    match(TipoToken.DIVIDIR);
                    return;
                }
                default -> throw new SyntaxFailure("esperado um de { DIVIDIR, VEZES }");
            }
        } catch (SyntaxFailure failure) {
            recover("MultiplicativeOperator", failure, FOLLOW_MultiplicativeOperator);
        }
    }

    // Unary -> NAO Unary | MENOS Unary | MAIS Unary | Primary
    private void parseUnary() {
        try {
            while (true) {
                switch (lookahead().getTipo()) {
                    case NAO -> {
                        match(TipoToken.NAO);
                    }
                    case MENOS -> {
                        match(TipoToken.MENOS);
                    }
                    case MAIS -> {
                        match(TipoToken.MAIS);
                    }
                    case BOOLEANO, CHAR_LITERAL, FLOAT, IDENTIFICADOR, INTEGER, LPAREN, STRING -> {
                        parsePrimary();
                        return;
                    }
                    default -> throw new SyntaxFailure("esperado um de { BOOLEANO, CHAR_LITERAL, FLOAT, IDENTIFICADOR, INTEGER, LPAREN, MAIS, MENOS, NAO, STRING }");
                }
            }
        } catch (SyntaxFailure failure) {
            recover("Unary", failure, FOLLOW_Unary);
        }
    }

    // Primary -> IDENTIFICADOR CallSuffix | INTEGER | FLOAT | BOOLEANO | CHAR_LITERAL | STRING | LPAREN Expression RPAREN
    private void parsePrimary() {
        try {
            switch (lookahead().getTipo()) {
                case IDENTIFICADOR -> {
                    match(TipoToken.IDENTIFICADOR);
                    parseCallSuffix();
                    return;
                }
                case INTEGER -> {
                    match(TipoToken.INTEGER);
                    return;
                }
                case FLOAT -> {
                    match(TipoToken.FLOAT);
                    return;
                }
                case BOOLEANO -> {
                    match(TipoToken.BOOLEANO);
                    return;
                }
                case CHAR_LITERAL -> {
                    match(TipoToken.CHAR_LITERAL);
                    return;
                }
                case STRING -> {
                    match(TipoToken.STRING);
                    return;
                }
                case LPAREN -> {
                    match(TipoToken.LPAREN);
                    parseExpression();
                    match(TipoToken.RPAREN);
                    return;
                }
                default -> throw new SyntaxFailure("esperado um de { BOOLEANO, CHAR_LITERAL, FLOAT, IDENTIFICADOR, INTEGER, LPAREN, STRING }");
            }
        } catch (SyntaxFailure failure) {
            recover("Primary", failure, FOLLOW_Primary);
        }
    }

    // CallSuffix -> LPAREN Arguments RPAREN | epsilon
    private void parseCallSuffix() {
        try {
            switch (lookahead().getTipo()) {
                case LPAREN -> {
                    match(TipoToken.LPAREN);
                    parseArguments();
                    match(TipoToken.RPAREN);
                    return;
                }
                case DIFERENTE, DIVIDIR, IGUAL_IGUAL, MAIOR, MAIOR_IGUAL, MAIS, MENOR, MENOR_IGUAL, MENOS, PONTO_VIRGULA, RPAREN, VEZES, VIRGULA -> {
                    // Epsilon is selected only on FOLLOW, never by default.
                    return;
                }
                default -> throw new SyntaxFailure("esperado um de { DIFERENTE, DIVIDIR, IGUAL_IGUAL, LPAREN, MAIOR, MAIOR_IGUAL, MAIS, MENOR, MENOR_IGUAL, MENOS, PONTO_VIRGULA, RPAREN, VEZES, VIRGULA }");
            }
        } catch (SyntaxFailure failure) {
            recover("CallSuffix", failure, FOLLOW_CallSuffix);
        }
    }
}
