import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

/** Test-only bridge for comparing the parser with an independent recognizer. */
public final class TokenBatch {
    public static void main(String[] args) throws Exception {
        BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
        for (String line; (line = input.readLine()) != null;) {
            List<Token> tokens = new ArrayList<>();
            if (!line.isBlank()) {
                for (String name : line.split(" ")) {
                    tokens.add(new Token(TipoToken.valueOf(name), name, 1, tokens.size() + 1));
                }
            }
            tokens.add(new Token(TipoToken.EOF, "", 1, tokens.size() + 1));
            System.out.println(new Parser(tokens).parse() ? "1" : "0");
        }
    }
}
