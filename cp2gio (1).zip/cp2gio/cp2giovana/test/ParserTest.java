import java.util.List;

/** End-to-end tests using the unmodified CP1 scanner. */
public class ParserTest {
    private static int tests;
    private static int failures;
    public static void main(String[] args) {
        valid("five types", "int count = 3; double rate <- 2.5; bool active = true; char letter = 'a'; string message = \"hello\";");
        valid("control flow", "main() { int i = 0; while (i < 5) { if (i == 2) { i <- i + 1; } else { i = i + 2; } } if (!false) { { int local; } } }");
        valid("functions and procedures", "int add(int a, int b) { return a + b; } show(string text, char ending) { return; } main() { int n = add(1, add(2, 3)); show(\"ok\", '!'); return; }");
        valid("empty program", "");
        valid("comments and optional productions", "/* test */ main() { // line\n int x; ping(); return; } ping() {}");
        valid("operators and precedence", "int f() { return !(1 + -2 * 3 / 4 >= 5) != false; }");
        valid("comparisons", "main() { bool a = 1 < 2; bool b = 2 <= 3; bool c = 4 > 3; bool d = 4 >= 2; bool e = 1 == 1; bool f = 1 != 2; }");
        valid("all parameter types", "f(int a, double b, bool c, char d, string e) { return; }");
        valid("nested selection", "main() { if (true) { if (false) {} else {} } else {} }");
        invalid("missing semicolon", "int x = 1", 1);
        invalid("missing parenthesis", "main() { while (true { return; } }", 1);
        invalid("missing operand", "main() { int x = 1 + ; }", 1);
        invalid("bad parameter", "int f(int) { return 1; }", 1);
        invalid("trailing argument comma", "main() { f(1,); }", 1);
        invalid("unclosed block", "main() { return;", 1);
        invalid("stray else", "main() { else {} }", 1);
        invalid("brace required", "main() { if (true) return; }", 1);
        invalid("invalid initializer epsilon", "int x true;", 1);
        invalid("invalid call suffix epsilon", "int x = name true;", 1);
        invalid("invalid return epsilon", "main() { return ,; }", 1);
        invalid("invalid parameter epsilon", "main(,) {}", 1);
        invalid("invalid argument epsilon", "main() { f(,); }", 1);
        invalid("trailing garbage", "main() {} }", 1);
        invalid("top-level command", "if (true) {}", 1);
        invalid("trailing parameter comma", "f(int a,) {}", 1);
        invalid("missing declaration name", "int = 1;", 1);
        invalid("unexpected operator", "main() { x = * 2; }", 1);
        List<String> errors = invalid("panic recovery", "main() {\n    int a = ;\n    int b = 2;\n    b <- ;\n    ping();\n    return;\n}\n", 2);
        check(errors.stream().anyMatch(e -> e.contains("linha 2, coluna 13")), "first error position");
        check(errors.stream().anyMatch(e -> e.contains("linha 4, coluna 10")), "recovered second error position");
        Parser reusable = new Parser(new Scanner("int x = ;").scanTokens());
        boolean first = reusable.parse();
        List<String> firstErrors = List.copyOf(reusable.getErros());
        boolean second = reusable.parse();
        check(!first && !second && firstErrors.equals(reusable.getErros()), "repeat parse is deterministic");
        valid("long declaration list", "int x;\n".repeat(10000));
        valid("long expression", "int x = 1" + " + 1".repeat(10000) + ";");
        invalid("long invalid input", ";".repeat(10000), 1);
        System.out.printf("%d checks, %d failures%n", tests, failures);
        if (failures != 0) throw new AssertionError("Parser tests failed");
    }
    private static void valid(String name, String source) {
        Parser parser = new Parser(new Scanner(source).scanTokens());
        boolean accepted = parser.parse();
        check(accepted && parser.getErros().isEmpty(), name + " " + parser.getErros());
    }
    private static List<String> invalid(String name, String source, int minimum) {
        Parser parser = new Parser(new Scanner(source).scanTokens());
        boolean accepted = parser.parse();
        check(!accepted && parser.getErros().size() >= minimum, name);
        parser.getErros().forEach(System.out::println);
        return parser.getErros();
    }
    private static void check(boolean condition, String name) {
        tests++;
        System.out.println((condition ? "PASS " : "FAIL ") + name);
        if (!condition) failures++;
    }
}
