"""Independent Earley membership oracle; does not use FIRST/FOLLOW or SELECT.

Run after compiling: python test/differential.py [path/to/java]
"""
from pathlib import Path
import random
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
grammar = {}
for line in (ROOT / "grammar.bnf").read_text(encoding="utf-8-sig").splitlines():
    name, rhs = line.split(" -> ")
    grammar[name] = [tuple(p.split()) if p.strip() != "EPS" else () for p in rhs.split("|")]


def accepts(tokens):
    tokens = tokens + ["EOF"]
    chart = [set() for _ in range(len(tokens) + 1)]
    chart[0].add(("Start", ("Program",), 0, 0))
    for position in range(len(chart)):
        changed = True
        while changed:
            before = len(chart[position])
            for lhs, rhs, dot, origin in list(chart[position]):
                if dot == len(rhs):
                    for parent, body, cursor, start in list(chart[origin]):
                        if cursor < len(body) and body[cursor] == lhs:
                            chart[position].add((parent, body, cursor + 1, start))
                elif rhs[dot] in grammar:
                    for body in grammar[rhs[dot]]:
                        chart[position].add((rhs[dot], body, 0, position))
                elif position < len(tokens) and rhs[dot] == tokens[position]:
                    chart[position + 1].add((lhs, rhs, dot + 1, origin))
            changed = before != len(chart[position])
    return ("Start", ("Program",), 1, 0) in chart[-1]


rng = random.Random(20261013)
terminals = sorted({s for alternatives in grammar.values() for rhs in alternatives
                    for s in rhs if s not in grammar and s != "EOF"})


def derive(symbol, depth=0):
    if symbol not in grammar:
        return [symbol]
    choices = grammar[symbol]
    if depth > 8:
        # Prefer finite leaf derivations as the depth grows.
        choices = sorted(choices, key=lambda rhs: (sum(s in grammar for s in rhs), len(rhs)))[:1]
    rhs = rng.choice(choices)
    return [t for part in rhs for t in derive(part, depth + 1)]


cases = [[], ["INT", "IDENTIFICADOR", "PONTO_VIRGULA"]]
for _ in range(250):
    valid = derive("Program")[:-1]
    cases.append(valid)
    if valid:
        pos = rng.randrange(len(valid))
        cases.append(valid[:pos] + valid[pos + 1:])
        cases.append(valid[:pos] + [rng.choice(terminals)] + valid[pos + 1:])
        cases.append(valid[:pos] + [rng.choice(terminals)] + valid[pos:])
for _ in range(1000):
    cases.append(rng.choices(terminals, k=rng.randrange(40)))

expected = [accepts(case) for case in cases]
run = subprocess.run([sys.argv[1] if len(sys.argv) > 1 else "java", "-cp", str(ROOT / "out"), "TokenBatch"],
                     input="\n".join(" ".join(case) for case in cases) + "\n",
                     text=True, capture_output=True, timeout=30, check=True)
actual = run.stdout.splitlines()
assert len(actual) == len(cases), (len(actual), len(cases), run.stderr)
for index, (wanted, observed) in enumerate(zip(expected, actual)):
    assert observed == ("1" if wanted else "0"), (index, cases[index], wanted, observed)
print(f"OK: {len(cases)} differential cases; {sum(expected)} accepted; no discrepancies or hangs.")
