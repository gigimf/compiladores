# Checkpoint 2 — smollang

## 1. Decisões e gramática final

Esta é uma implementação de referência para estudo, construída a partir do scanner do CP1 fornecido. Não foi encontrada uma gramática sintática anterior: havia apenas documentação léxica e um esqueleto de CP2. Portanto, as escolhas sintáticas abaixo são propostas desta revisão, não decisões históricas atribuídas às autoras.

### Sintaxe e escopo

- Programa: zero ou mais declarações globais, seguidas de EOF. Programa vazio é válido; não é exigida função `main`.
- Variáveis: `int x;`, `double x = 2.5;` ou `double x <- 2.5;`. Os dois operadores de atribuição já existem no CP1 e têm o mesmo papel sintático.
- Funções: `int soma(int a, int b) { return a + b; }`.
- Procedimentos: `mostrar(string texto) { return; }`. A ausência do tipo distingue procedimentos, pois o CP1 não possui palavra reservada `void`. Não há alteração nem reclassificação de tokens pelo lexema.
- Funções e procedimentos são declarados somente no nível global. Parâmetros são tipados; chamadas podem ter zero ou mais argumentos.
- Comandos dentro de blocos: declaração de variável, atribuição, chamada, seleção, repetição, retorno e bloco aninhado. Não há comando vazio `;` nem expressão isolada `1 + 2;`.
- `if (condição) { ... } else { ... }` e `while (condição) { ... }` exigem chaves. `else` é opcional; `else if` pode ser escrito como `else { if (...) { ... } }`.
- `return;` e `return expressão;` são reconhecidos. Tipos de retorno, símbolos declarados, aridade e uso de procedimentos em expressões são questões semânticas, fora deste reconhecedor. Assim, um procedimento com `return 1;` é sintaticamente válido, embora possa ser rejeitado em etapa semântica futura.
- Literais: inteiros, decimais, booleanos, caracteres e strings exatamente como tokenizados pelo CP1. Comentários e espaços são descartados pelo scanner.
- Precedência, da menor para a maior: igualdade (`==`, `!=`), relação (`<`, `<=`, `>`, `>=`), adição/subtração, multiplicação/divisão, unários (`!`, `-`, `+`) e primários/chamadas/parênteses. As caudas representam sequências de operadores binários; a futura avaliação deve dobrá-las à esquerda. Unários se agrupam à direita. Não há AST nem avaliação neste checkpoint.
- Comparações encadeadas são sintaticamente permitidas. Atribuições não são expressões; não se aceita `a = b = 1;`. `&&`, `||`, arrays e `for` não pertencem ao vocabulário desta versão.

### Antes/depois: transformações didáticas

As produções "antes" abaixo ilustram os problemas evitados; não são apresentadas como uma gramática antiga recuperada do grupo.

1. Recursão à esquerda: `Additive → Additive AdditiveOperator Multiplicative | Multiplicative` passaria a chamar a si mesma sem consumir tokens. Depois: `Additive → Multiplicative AdditiveTail` e `AdditiveTail → AdditiveOperator Multiplicative AdditiveTail | ε`. A mesma transformação se aplica aos demais níveis binários. A BNF final não tem ciclos no grafo de chamadas por prefixos anuláveis, inclusive indiretos.
2. Declarações com prefixo comum: `Declaration → Type IDENTIFICADOR LPAREN ... | Type IDENTIFICADOR Initializer PONTO_VIRGULA`. Depois: `Declaration → Type IDENTIFICADOR DeclarationRest`; `DeclarationRest` decide entre função (`LPAREN`) e variável (`IGUAL`, `ATRIBUI` ou `PONTO_VIRGULA`). A alternativa de procedimento começa diretamente por `IDENTIFICADOR`.
3. Atribuição/chamada: `Statement → IDENTIFICADOR AssignmentOperator ... | IDENTIFICADOR LPAREN ...`. Depois: `Statement → IDENTIFICADOR IdentifierStatement`.
4. Variável/chamada em expressão: `Primary → IDENTIFICADOR | IDENTIFICADOR LPAREN ...`. Depois: `Primary → IDENTIFICADOR CallSuffix`, com `CallSuffix → LPAREN Arguments RPAREN | ε`.
5. *Dangling else*: permitir `if (...) Statement ElsePart` faz `ELSE` entrar no FOLLOW de `ElsePart`, conflitando com FIRST da alternativa não vazia. A correção adotada é exigir `Block` nos ramos. Com chaves, `ELSE` não pertence a FOLLOW(ElsePart), e a escolha fica LL(1).

### BNF completa

Os nomes em maiúsculas são exatamente os membros de `TipoToken`. Os demais símbolos são não-terminais. `EPS` representa ε (sequência vazia), não um token. `EOF` é o token final emitido pelo scanner; também representa o limite físico da entrada no FOLLOW do símbolo inicial.

```bnf
Program -> Declarations EOF
Declarations -> Declaration Declarations | EPS
Declaration -> Type IDENTIFICADOR DeclarationRest | IDENTIFICADOR LPAREN Parameters RPAREN Block
DeclarationRest -> LPAREN Parameters RPAREN Block | Initializer PONTO_VIRGULA
Type -> INT | DOUBLE | BOOL | CHAR | STRING_TYPE
Initializer -> AssignmentOperator Expression | EPS
AssignmentOperator -> IGUAL | ATRIBUI
Parameters -> Parameter ParametersTail | EPS
ParametersTail -> VIRGULA Parameter ParametersTail | EPS
Parameter -> Type IDENTIFICADOR
Block -> ABRE_CHAVE Statements FECHA_CHAVE
Statements -> Statement Statements | EPS
Statement -> Type IDENTIFICADOR Initializer PONTO_VIRGULA | IDENTIFICADOR IdentifierStatement | IF LPAREN Expression RPAREN Block ElsePart | WHILE LPAREN Expression RPAREN Block | RETURN ReturnValue PONTO_VIRGULA | Block
IdentifierStatement -> AssignmentOperator Expression PONTO_VIRGULA | LPAREN Arguments RPAREN PONTO_VIRGULA
ElsePart -> ELSE Block | EPS
ReturnValue -> Expression | EPS
Arguments -> Expression ArgumentsTail | EPS
ArgumentsTail -> VIRGULA Expression ArgumentsTail | EPS
Expression -> Equality
Equality -> Relational EqualityTail
EqualityTail -> EqualityOperator Relational EqualityTail | EPS
EqualityOperator -> IGUAL_IGUAL | DIFERENTE
Relational -> Additive RelationalTail
RelationalTail -> RelationalOperator Additive RelationalTail | EPS
RelationalOperator -> MENOR | MENOR_IGUAL | MAIOR | MAIOR_IGUAL
Additive -> Multiplicative AdditiveTail
AdditiveTail -> AdditiveOperator Multiplicative AdditiveTail | EPS
AdditiveOperator -> MAIS | MENOS
Multiplicative -> Unary MultiplicativeTail
MultiplicativeTail -> MultiplicativeOperator Unary MultiplicativeTail | EPS
MultiplicativeOperator -> VEZES | DIVIDIR
Unary -> NAO Unary | MENOS Unary | MAIS Unary | Primary
Primary -> IDENTIFICADOR CallSuffix | INTEGER | FLOAT | BOOLEANO | CHAR_LITERAL | STRING | LPAREN Expression RPAREN
CallSuffix -> LPAREN Arguments RPAREN | EPS
```

### Como a BNF vira código

Cada não-terminal `A` tem exatamente um método `parseA()`. Cada alternativa vira um ramo do `switch` de lookahead. Um terminal vira `match(TipoToken.X)`; um não-terminal vira `parseX()`. As alternativas ε têm casos explícitos correspondentes a FOLLOW(A), nunca um `default` que silenciosamente aceita vazio. O `default` registra um erro e inicia recuperação.

As caudas recursivas à direita são traduzidas para `while`, mantendo o método correspondente: por exemplo, `Declarations → Declaration Declarations | ε` repete `parseDeclaration()`. Isso preserva a gramática e evita consumir a pilha em listas longas. Não há parser por tabela em produção, reflexão ou interpretação genérica da gramática. A ferramenta Python apenas reproduz a tradução para os métodos Java explícitos, que compilam e executam sem Python.

### Recuperação e término

Cada `parseA()` captura uma falha local de predição ou de `match`, registra não-terminal, token encontrado, linha e coluna, e descarta tokens até `FOLLOW(A) ∪ {EOF}`. O sincronizador preserva o token encontrado; o chamador continua a produção. Por exemplo, numa expressão ausente antes de `;`, o token `;` já pertence a FOLLOW(Expression): nenhum descarte é necessário e o chamador consome o delimitador.

Qualquer erro torna o resultado final falso, mesmo quando o restante é reconhecido. A recuperação pode produzir diagnósticos em cascata ou descartar parte de um comando danificado; ela não tenta corrigir o programa nem construir AST.

O descarte sempre avança ou termina em EOF. Cada repetição de uma cauda não vazia consome um terminal: operadores, vírgula ou o início de uma declaração/comando; as alternativas vazias retornam e os caminhos de exceção saem do método após sincronizar. Não há recursão à esquerda. Essas propriedades eliminam ciclos sem progresso para entradas finitas. Aninhamento extremo de parênteses/blocos ainda está sujeito ao limite de pilha da JVM, como em um parser recursivo convencional; isso é uma limitação de recursos, não um laço de recuperação.

### Traço de recuperação verificável

Entrada `examples/07-multiple-errors.smol`:

```text
main() {
    int a = ;
    int b = 2;
    b <- ;
    ping();
    return;
}
```

1. Linha 2, coluna 13: `parseExpression()` encontra `PONTO_VIRGULA`, que não pertence ao seu FIRST. Registra erro; sincroniza no próprio `;`, que está em FOLLOW(Expression).
2. A declaração consome `;`; a declaração válida da linha 3 é reconhecida.
3. Linha 4, coluna 10: nova expressão ausente na atribuição; ocorre outro erro independente, recuperado no `;`.
4. A chamada, o retorno, a chave final e EOF são processados. O programa é rejeitado, com os dois erros na mesma rodada. Os testes conferem ambas as posições.

### Compatibilidade com o CP1

`Scanner.java`, `Token.java` e `TipoToken.java` foram preservados byte a byte. A documentação léxica menciona `_` no início de identificadores, mas `ehLetra` usa `Character.isLetter`, portanto `_` inicial provoca erro; `_` interno é aceito. O scanner aceita letras Unicode, apesar da descrição ASCII. Ele também não implementa escapes em strings/chars e não impõe exatamente a restrição a barras invertidas descrita no README. Os exemplos evitam essas divergências, que ficam registradas sem alterar o CP1.

O scanner imprime erros léxicos e pode descartar caracteres inválidos. Por isso `Parser.parse()` responde somente sobre a lista de tokens recebida. A CLI `Main` captura os diagnósticos do scanner e rejeita a entrada se houver erro léxico **ou** sintático, impedindo aceitar silenciosamente `@` como programa vazio. Essa captura é restrita à execução sequencial da CLI; não é uma API concorrente.

### Método de cálculo e leitura das tabelas

FIRST é calculado até ponto fixo, propagando terminais e anulabilidade pelas produções. Para cada ocorrência `A → α B β`, FIRST(β) sem ε entra em FOLLOW(B); se β é anulável, FOLLOW(A) também entra. A propagação de FOLLOW também termina em ponto fixo. As tabelas abaixo listam os conjuntos completos, sem abreviações.

O verificador checa recursão à esquerda por prefixos anuláveis e disjunção de SELECT por alternativa. A disjunção implica (a) FIRST não vazios disjuntos e (c) ausência de conflito FIRST/FOLLOW quando há ε; a quantidade de alternativas anuláveis é checada separadamente para (b). A suíte adicional usa um reconhecedor Earley independente, sem FIRST/FOLLOW, para comparar a linguagem reconhecida pelo Java.

<!-- BEGIN VERIFIED TABLES -->
<!-- Computed from grammar.bnf; regenerate with tools/verify_grammar.py --write. -->

## Tabela completa FIRST/FOLLOW

| Não-terminal | FIRST | FOLLOW |
|---|---|---|
| Program | { BOOL, CHAR, DOUBLE, EOF, IDENTIFICADOR, INT, STRING_TYPE } | { EOF } |
| Declarations | { BOOL, CHAR, DOUBLE, ε, IDENTIFICADOR, INT, STRING_TYPE } | { EOF } |
| Declaration | { BOOL, CHAR, DOUBLE, IDENTIFICADOR, INT, STRING_TYPE } | { BOOL, CHAR, DOUBLE, EOF, IDENTIFICADOR, INT, STRING_TYPE } |
| DeclarationRest | { ATRIBUI, IGUAL, LPAREN, PONTO_VIRGULA } | { BOOL, CHAR, DOUBLE, EOF, IDENTIFICADOR, INT, STRING_TYPE } |
| Type | { BOOL, CHAR, DOUBLE, INT, STRING_TYPE } | { IDENTIFICADOR } |
| Initializer | { ATRIBUI, ε, IGUAL } | { PONTO_VIRGULA } |
| AssignmentOperator | { ATRIBUI, IGUAL } | { BOOLEANO, CHAR_LITERAL, FLOAT, IDENTIFICADOR, INTEGER, LPAREN, MAIS, MENOS, NAO, STRING } |
| Parameters | { BOOL, CHAR, DOUBLE, ε, INT, STRING_TYPE } | { RPAREN } |
| ParametersTail | { ε, VIRGULA } | { RPAREN } |
| Parameter | { BOOL, CHAR, DOUBLE, INT, STRING_TYPE } | { RPAREN, VIRGULA } |
| Block | { ABRE_CHAVE } | { ABRE_CHAVE, BOOL, CHAR, DOUBLE, ELSE, EOF, FECHA_CHAVE, IDENTIFICADOR, IF, INT, RETURN, STRING_TYPE, WHILE } |
| Statements | { ABRE_CHAVE, BOOL, CHAR, DOUBLE, ε, IDENTIFICADOR, IF, INT, RETURN, STRING_TYPE, WHILE } | { FECHA_CHAVE } |
| Statement | { ABRE_CHAVE, BOOL, CHAR, DOUBLE, IDENTIFICADOR, IF, INT, RETURN, STRING_TYPE, WHILE } | { ABRE_CHAVE, BOOL, CHAR, DOUBLE, FECHA_CHAVE, IDENTIFICADOR, IF, INT, RETURN, STRING_TYPE, WHILE } |
| IdentifierStatement | { ATRIBUI, IGUAL, LPAREN } | { ABRE_CHAVE, BOOL, CHAR, DOUBLE, FECHA_CHAVE, IDENTIFICADOR, IF, INT, RETURN, STRING_TYPE, WHILE } |
| ElsePart | { ELSE, ε } | { ABRE_CHAVE, BOOL, CHAR, DOUBLE, FECHA_CHAVE, IDENTIFICADOR, IF, INT, RETURN, STRING_TYPE, WHILE } |
| ReturnValue | { BOOLEANO, CHAR_LITERAL, ε, FLOAT, IDENTIFICADOR, INTEGER, LPAREN, MAIS, MENOS, NAO, STRING } | { PONTO_VIRGULA } |
| Arguments | { BOOLEANO, CHAR_LITERAL, ε, FLOAT, IDENTIFICADOR, INTEGER, LPAREN, MAIS, MENOS, NAO, STRING } | { RPAREN } |
| ArgumentsTail | { ε, VIRGULA } | { RPAREN } |
| Expression | { BOOLEANO, CHAR_LITERAL, FLOAT, IDENTIFICADOR, INTEGER, LPAREN, MAIS, MENOS, NAO, STRING } | { PONTO_VIRGULA, RPAREN, VIRGULA } |
| Equality | { BOOLEANO, CHAR_LITERAL, FLOAT, IDENTIFICADOR, INTEGER, LPAREN, MAIS, MENOS, NAO, STRING } | { PONTO_VIRGULA, RPAREN, VIRGULA } |
| EqualityTail | { DIFERENTE, ε, IGUAL_IGUAL } | { PONTO_VIRGULA, RPAREN, VIRGULA } |
| EqualityOperator | { DIFERENTE, IGUAL_IGUAL } | { BOOLEANO, CHAR_LITERAL, FLOAT, IDENTIFICADOR, INTEGER, LPAREN, MAIS, MENOS, NAO, STRING } |
| Relational | { BOOLEANO, CHAR_LITERAL, FLOAT, IDENTIFICADOR, INTEGER, LPAREN, MAIS, MENOS, NAO, STRING } | { DIFERENTE, IGUAL_IGUAL, PONTO_VIRGULA, RPAREN, VIRGULA } |
| RelationalTail | { ε, MAIOR, MAIOR_IGUAL, MENOR, MENOR_IGUAL } | { DIFERENTE, IGUAL_IGUAL, PONTO_VIRGULA, RPAREN, VIRGULA } |
| RelationalOperator | { MAIOR, MAIOR_IGUAL, MENOR, MENOR_IGUAL } | { BOOLEANO, CHAR_LITERAL, FLOAT, IDENTIFICADOR, INTEGER, LPAREN, MAIS, MENOS, NAO, STRING } |
| Additive | { BOOLEANO, CHAR_LITERAL, FLOAT, IDENTIFICADOR, INTEGER, LPAREN, MAIS, MENOS, NAO, STRING } | { DIFERENTE, IGUAL_IGUAL, MAIOR, MAIOR_IGUAL, MENOR, MENOR_IGUAL, PONTO_VIRGULA, RPAREN, VIRGULA } |
| AdditiveTail | { ε, MAIS, MENOS } | { DIFERENTE, IGUAL_IGUAL, MAIOR, MAIOR_IGUAL, MENOR, MENOR_IGUAL, PONTO_VIRGULA, RPAREN, VIRGULA } |
| AdditiveOperator | { MAIS, MENOS } | { BOOLEANO, CHAR_LITERAL, FLOAT, IDENTIFICADOR, INTEGER, LPAREN, MAIS, MENOS, NAO, STRING } |
| Multiplicative | { BOOLEANO, CHAR_LITERAL, FLOAT, IDENTIFICADOR, INTEGER, LPAREN, MAIS, MENOS, NAO, STRING } | { DIFERENTE, IGUAL_IGUAL, MAIOR, MAIOR_IGUAL, MAIS, MENOR, MENOR_IGUAL, MENOS, PONTO_VIRGULA, RPAREN, VIRGULA } |
| MultiplicativeTail | { DIVIDIR, ε, VEZES } | { DIFERENTE, IGUAL_IGUAL, MAIOR, MAIOR_IGUAL, MAIS, MENOR, MENOR_IGUAL, MENOS, PONTO_VIRGULA, RPAREN, VIRGULA } |
| MultiplicativeOperator | { DIVIDIR, VEZES } | { BOOLEANO, CHAR_LITERAL, FLOAT, IDENTIFICADOR, INTEGER, LPAREN, MAIS, MENOS, NAO, STRING } |
| Unary | { BOOLEANO, CHAR_LITERAL, FLOAT, IDENTIFICADOR, INTEGER, LPAREN, MAIS, MENOS, NAO, STRING } | { DIFERENTE, DIVIDIR, IGUAL_IGUAL, MAIOR, MAIOR_IGUAL, MAIS, MENOR, MENOR_IGUAL, MENOS, PONTO_VIRGULA, RPAREN, VEZES, VIRGULA } |
| Primary | { BOOLEANO, CHAR_LITERAL, FLOAT, IDENTIFICADOR, INTEGER, LPAREN, STRING } | { DIFERENTE, DIVIDIR, IGUAL_IGUAL, MAIOR, MAIOR_IGUAL, MAIS, MENOR, MENOR_IGUAL, MENOS, PONTO_VIRGULA, RPAREN, VEZES, VIRGULA } |
| CallSuffix | { ε, LPAREN } | { DIFERENTE, DIVIDIR, IGUAL_IGUAL, MAIOR, MAIOR_IGUAL, MAIS, MENOR, MENOR_IGUAL, MENOS, PONTO_VIRGULA, RPAREN, VEZES, VIRGULA } |

## Verificação individual LL(1)

A numeração das alternativas segue a ordem da BNF. SELECT(A → α) = FIRST(α) − {ε}, acrescentando FOLLOW(A) se α for anulável. Os SELECT de cada linha são disjuntos. Uma produção com uma só alternativa satisfaz (a) trivialmente. '—' em (c) significa que não há alternativa anulável.

| Não-terminal | (a) FIRST disjuntos | (b) alternativas anuláveis | (c) FIRST das demais ∩ FOLLOW | SELECT por alternativa |
|---|---|---|---|---|
| Program | sim | 0 | — | 1: { BOOL, CHAR, DOUBLE, EOF, IDENTIFICADOR, INT, STRING_TYPE } |
| Declarations | sim | 1 | ∅ | 1: { BOOL, CHAR, DOUBLE, IDENTIFICADOR, INT, STRING_TYPE }<br>2: { EOF } |
| Declaration | sim | 0 | — | 1: { BOOL, CHAR, DOUBLE, INT, STRING_TYPE }<br>2: { IDENTIFICADOR } |
| DeclarationRest | sim | 0 | — | 1: { LPAREN }<br>2: { ATRIBUI, IGUAL, PONTO_VIRGULA } |
| Type | sim | 0 | — | 1: { INT }<br>2: { DOUBLE }<br>3: { BOOL }<br>4: { CHAR }<br>5: { STRING_TYPE } |
| Initializer | sim | 1 | ∅ | 1: { ATRIBUI, IGUAL }<br>2: { PONTO_VIRGULA } |
| AssignmentOperator | sim | 0 | — | 1: { IGUAL }<br>2: { ATRIBUI } |
| Parameters | sim | 1 | ∅ | 1: { BOOL, CHAR, DOUBLE, INT, STRING_TYPE }<br>2: { RPAREN } |
| ParametersTail | sim | 1 | ∅ | 1: { VIRGULA }<br>2: { RPAREN } |
| Parameter | sim | 0 | — | 1: { BOOL, CHAR, DOUBLE, INT, STRING_TYPE } |
| Block | sim | 0 | — | 1: { ABRE_CHAVE } |
| Statements | sim | 1 | ∅ | 1: { ABRE_CHAVE, BOOL, CHAR, DOUBLE, IDENTIFICADOR, IF, INT, RETURN, STRING_TYPE, WHILE }<br>2: { FECHA_CHAVE } |
| Statement | sim | 0 | — | 1: { BOOL, CHAR, DOUBLE, INT, STRING_TYPE }<br>2: { IDENTIFICADOR }<br>3: { IF }<br>4: { WHILE }<br>5: { RETURN }<br>6: { ABRE_CHAVE } |
| IdentifierStatement | sim | 0 | — | 1: { ATRIBUI, IGUAL }<br>2: { LPAREN } |
| ElsePart | sim | 1 | ∅ | 1: { ELSE }<br>2: { ABRE_CHAVE, BOOL, CHAR, DOUBLE, FECHA_CHAVE, IDENTIFICADOR, IF, INT, RETURN, STRING_TYPE, WHILE } |
| ReturnValue | sim | 1 | ∅ | 1: { BOOLEANO, CHAR_LITERAL, FLOAT, IDENTIFICADOR, INTEGER, LPAREN, MAIS, MENOS, NAO, STRING }<br>2: { PONTO_VIRGULA } |
| Arguments | sim | 1 | ∅ | 1: { BOOLEANO, CHAR_LITERAL, FLOAT, IDENTIFICADOR, INTEGER, LPAREN, MAIS, MENOS, NAO, STRING }<br>2: { RPAREN } |
| ArgumentsTail | sim | 1 | ∅ | 1: { VIRGULA }<br>2: { RPAREN } |
| Expression | sim | 0 | — | 1: { BOOLEANO, CHAR_LITERAL, FLOAT, IDENTIFICADOR, INTEGER, LPAREN, MAIS, MENOS, NAO, STRING } |
| Equality | sim | 0 | — | 1: { BOOLEANO, CHAR_LITERAL, FLOAT, IDENTIFICADOR, INTEGER, LPAREN, MAIS, MENOS, NAO, STRING } |
| EqualityTail | sim | 1 | ∅ | 1: { DIFERENTE, IGUAL_IGUAL }<br>2: { PONTO_VIRGULA, RPAREN, VIRGULA } |
| EqualityOperator | sim | 0 | — | 1: { IGUAL_IGUAL }<br>2: { DIFERENTE } |
| Relational | sim | 0 | — | 1: { BOOLEANO, CHAR_LITERAL, FLOAT, IDENTIFICADOR, INTEGER, LPAREN, MAIS, MENOS, NAO, STRING } |
| RelationalTail | sim | 1 | ∅ | 1: { MAIOR, MAIOR_IGUAL, MENOR, MENOR_IGUAL }<br>2: { DIFERENTE, IGUAL_IGUAL, PONTO_VIRGULA, RPAREN, VIRGULA } |
| RelationalOperator | sim | 0 | — | 1: { MENOR }<br>2: { MENOR_IGUAL }<br>3: { MAIOR }<br>4: { MAIOR_IGUAL } |
| Additive | sim | 0 | — | 1: { BOOLEANO, CHAR_LITERAL, FLOAT, IDENTIFICADOR, INTEGER, LPAREN, MAIS, MENOS, NAO, STRING } |
| AdditiveTail | sim | 1 | ∅ | 1: { MAIS, MENOS }<br>2: { DIFERENTE, IGUAL_IGUAL, MAIOR, MAIOR_IGUAL, MENOR, MENOR_IGUAL, PONTO_VIRGULA, RPAREN, VIRGULA } |
| AdditiveOperator | sim | 0 | — | 1: { MAIS }<br>2: { MENOS } |
| Multiplicative | sim | 0 | — | 1: { BOOLEANO, CHAR_LITERAL, FLOAT, IDENTIFICADOR, INTEGER, LPAREN, MAIS, MENOS, NAO, STRING } |
| MultiplicativeTail | sim | 1 | ∅ | 1: { DIVIDIR, VEZES }<br>2: { DIFERENTE, IGUAL_IGUAL, MAIOR, MAIOR_IGUAL, MAIS, MENOR, MENOR_IGUAL, MENOS, PONTO_VIRGULA, RPAREN, VIRGULA } |
| MultiplicativeOperator | sim | 0 | — | 1: { VEZES }<br>2: { DIVIDIR } |
| Unary | sim | 0 | — | 1: { NAO }<br>2: { MENOS }<br>3: { MAIS }<br>4: { BOOLEANO, CHAR_LITERAL, FLOAT, IDENTIFICADOR, INTEGER, LPAREN, STRING } |
| Primary | sim | 0 | — | 1: { IDENTIFICADOR }<br>2: { INTEGER }<br>3: { FLOAT }<br>4: { BOOLEANO }<br>5: { CHAR_LITERAL }<br>6: { STRING }<br>7: { LPAREN } |
| CallSuffix | sim | 1 | ∅ | 1: { LPAREN }<br>2: { DIFERENTE, DIVIDIR, IGUAL_IGUAL, MAIOR, MAIOR_IGUAL, MAIS, MENOR, MENOR_IGUAL, MENOS, PONTO_VIRGULA, RPAREN, VEZES, VIRGULA } |

## Sincronização por não-terminal

Em todos os métodos, SYNC(A) = FOLLOW(A) ∪ {EOF}. O token de sincronização é preservado para o chamador. EOF sempre encerra o descarte, mesmo quando não pertence ao FOLLOW formal.

| Não-terminal | SYNC |
|---|---|
| Program | { EOF } |
| Declarations | { EOF } |
| Declaration | { BOOL, CHAR, DOUBLE, EOF, IDENTIFICADOR, INT, STRING_TYPE } |
| DeclarationRest | { BOOL, CHAR, DOUBLE, EOF, IDENTIFICADOR, INT, STRING_TYPE } |
| Type | { EOF, IDENTIFICADOR } |
| Initializer | { EOF, PONTO_VIRGULA } |
| AssignmentOperator | { BOOLEANO, CHAR_LITERAL, EOF, FLOAT, IDENTIFICADOR, INTEGER, LPAREN, MAIS, MENOS, NAO, STRING } |
| Parameters | { EOF, RPAREN } |
| ParametersTail | { EOF, RPAREN } |
| Parameter | { EOF, RPAREN, VIRGULA } |
| Block | { ABRE_CHAVE, BOOL, CHAR, DOUBLE, ELSE, EOF, FECHA_CHAVE, IDENTIFICADOR, IF, INT, RETURN, STRING_TYPE, WHILE } |
| Statements | { EOF, FECHA_CHAVE } |
| Statement | { ABRE_CHAVE, BOOL, CHAR, DOUBLE, EOF, FECHA_CHAVE, IDENTIFICADOR, IF, INT, RETURN, STRING_TYPE, WHILE } |
| IdentifierStatement | { ABRE_CHAVE, BOOL, CHAR, DOUBLE, EOF, FECHA_CHAVE, IDENTIFICADOR, IF, INT, RETURN, STRING_TYPE, WHILE } |
| ElsePart | { ABRE_CHAVE, BOOL, CHAR, DOUBLE, EOF, FECHA_CHAVE, IDENTIFICADOR, IF, INT, RETURN, STRING_TYPE, WHILE } |
| ReturnValue | { EOF, PONTO_VIRGULA } |
| Arguments | { EOF, RPAREN } |
| ArgumentsTail | { EOF, RPAREN } |
| Expression | { EOF, PONTO_VIRGULA, RPAREN, VIRGULA } |
| Equality | { EOF, PONTO_VIRGULA, RPAREN, VIRGULA } |
| EqualityTail | { EOF, PONTO_VIRGULA, RPAREN, VIRGULA } |
| EqualityOperator | { BOOLEANO, CHAR_LITERAL, EOF, FLOAT, IDENTIFICADOR, INTEGER, LPAREN, MAIS, MENOS, NAO, STRING } |
| Relational | { DIFERENTE, EOF, IGUAL_IGUAL, PONTO_VIRGULA, RPAREN, VIRGULA } |
| RelationalTail | { DIFERENTE, EOF, IGUAL_IGUAL, PONTO_VIRGULA, RPAREN, VIRGULA } |
| RelationalOperator | { BOOLEANO, CHAR_LITERAL, EOF, FLOAT, IDENTIFICADOR, INTEGER, LPAREN, MAIS, MENOS, NAO, STRING } |
| Additive | { DIFERENTE, EOF, IGUAL_IGUAL, MAIOR, MAIOR_IGUAL, MENOR, MENOR_IGUAL, PONTO_VIRGULA, RPAREN, VIRGULA } |
| AdditiveTail | { DIFERENTE, EOF, IGUAL_IGUAL, MAIOR, MAIOR_IGUAL, MENOR, MENOR_IGUAL, PONTO_VIRGULA, RPAREN, VIRGULA } |
| AdditiveOperator | { BOOLEANO, CHAR_LITERAL, EOF, FLOAT, IDENTIFICADOR, INTEGER, LPAREN, MAIS, MENOS, NAO, STRING } |
| Multiplicative | { DIFERENTE, EOF, IGUAL_IGUAL, MAIOR, MAIOR_IGUAL, MAIS, MENOR, MENOR_IGUAL, MENOS, PONTO_VIRGULA, RPAREN, VIRGULA } |
| MultiplicativeTail | { DIFERENTE, EOF, IGUAL_IGUAL, MAIOR, MAIOR_IGUAL, MAIS, MENOR, MENOR_IGUAL, MENOS, PONTO_VIRGULA, RPAREN, VIRGULA } |
| MultiplicativeOperator | { BOOLEANO, CHAR_LITERAL, EOF, FLOAT, IDENTIFICADOR, INTEGER, LPAREN, MAIS, MENOS, NAO, STRING } |
| Unary | { DIFERENTE, DIVIDIR, EOF, IGUAL_IGUAL, MAIOR, MAIOR_IGUAL, MAIS, MENOR, MENOR_IGUAL, MENOS, PONTO_VIRGULA, RPAREN, VEZES, VIRGULA } |
| Primary | { DIFERENTE, DIVIDIR, EOF, IGUAL_IGUAL, MAIOR, MAIOR_IGUAL, MAIS, MENOR, MENOR_IGUAL, MENOS, PONTO_VIRGULA, RPAREN, VEZES, VIRGULA } |
| CallSuffix | { DIFERENTE, DIVIDIR, EOF, IGUAL_IGUAL, MAIOR, MAIOR_IGUAL, MAIS, MENOR, MENOR_IGUAL, MENOS, PONTO_VIRGULA, RPAREN, VEZES, VIRGULA } |
