# CP2 — smollang: gramática e parser recursivo descendente

Versão completa de referência para **estudo**, baseada no CP1 de Tarcila e Giovana fornecido. A sintaxe foi definida nesta revisão; o CP1 fornecido especificava o léxico, não uma gramática sintática completa. O uso integral de IA está registrado em [log-uso-ia.md](log-uso-ia.md).

## Conteúdo

| Requisito | Arquivo |
|---|---|
| BNF, transformações antes/depois, FIRST/FOLLOW, verificação individual LL(1), sincronização e explicações | [gramatica-first-follow.md](gramatica-first-follow.md) |
| Gramática em formato legível por ferramenta | [grammar.bnf](grammar.bnf) |
| Um método Java por não-terminal, ε robusto, recuperação e resultado booleano, sem AST | [src/Parser.java](src/Parser.java) |
| Scanner e tokens do CP1, intactos | `src/Scanner.java`, `src/Token.java`, `src/TipoToken.java` |
| Entrada por arquivo e tratamento separado de erros léxicos/sintáticos | [src/Main.java](src/Main.java) |
| Testes válidos, inválidos, recuperação, posições e listas extensas | [test/ParserTest.java](test/ParserTest.java) |
| Comparação com reconhecedor Earley independente | [test/differential.py](test/differential.py) |
| Programas prontos para execução | [examples](examples) |
| Resultado da verificação executada | [test/verification.log](test/verification.log) |

## Compilar e testar

Requisito: **JDK 17 ou posterior**. Sem Maven, Gradle ou bibliotecas externas. Execute dentro da pasta `cp2-tarcila-giovana`:

```powershell
javac --release 17 -encoding UTF-8 -Xlint:all -Werror -d out src/*.java test/*.java
java -cp out ParserTest
java -cp out Main examples/03-routines.smol
java -cp out Main examples/07-multiple-errors.smol
```

Os testes usam verificações explícitas e falham com código de saída diferente de zero; `-ea` não é necessário. Os mesmos comandos funcionam em um shell Linux/macOS com JDK instalado.

`Main` imprime `ACEITO` ou `REJEITADO`. Diagnósticos vão para stderr. Códigos de saída: **0** aceito; **1** erro léxico/sintático; **2** uso incorreto ou falha de leitura. Os exemplos 01–03 são válidos; 04–06 têm erros sintáticos distintos; 07 contém dois erros; 08 contém erro léxico. O programa é apenas reconhecido, não executado.

### Verificação ampliada e reproduzível

Python 3.10+ é opcional, sem dependências adicionais. Com Java no PATH:

```powershell
python tools/verify_all.py
```

Se o PATH apontar para um encaminhador antigo da Oracle, informe o JDK diretamente. Este foi o comando usado neste ambiente:

```powershell
python tools/verify_all.py --jdk "C:\Program Files\Java\jdk-21"
```

A ferramenta confere os hashes do CP1, recalcula FIRST/FOLLOW, verifica LL(1), compila com avisos tratados como erros, executa os testes e os exemplos pela CLI e testa erros léxicos. Cada subprocesso tem timeout. O resultado fica em `test/verification.log`; classes compiladas ficam em `out/` e não são incluídas no ZIP.

Para conferir apenas a gramática e sua correspondência com o parser e o documento:

```powershell
python tools/verify_grammar.py
```

`python tools/verify_grammar.py --write` reproduz os métodos Java e as tabelas a partir da BNF. O Java entregue é explícito e autossuficiente; a geração é uma ferramenta de auditoria opcional. Se alterar a BNF, atualize também o bloco BNF do documento antes de regenerar. O texto explicativo e os testes devem ser revisados para refletir mudanças de linguagem.

## Roteiro de estudo

1. Comece por `Declaration`: um tipo inicia variável/função; identificador inicia procedimento. Depois de `Type IDENTIFICADOR`, `DeclarationRest` distingue `(` de inicialização/`;`.
2. Compare `Parameters` e `Arguments`: ambos aceitam vazio somente em `RPAREN`, mas os FIRST das alternativas não vazias são diferentes.
3. Veja `CallSuffix`: após um identificador numa expressão, `(` inicia chamada; vazio só é permitido diante dos tokens de FOLLOW.
4. Acompanhe `1 + 2 * 3`: `Additive` chama `Multiplicative`, que reconhece a multiplicação antes de voltar ao nível aditivo. Não há cálculo numérico nesta fase.
5. Execute o exemplo 07 e acompanhe os dois erros, nas linhas 2 e 4. Cada `;` é preservado pelo sincronizador e consumido pelo método chamador.

## Limites declarados

A análise não verifica tipos, escopo, aridade, retorno obrigatório nem existência de função `main`. Todas essas verificações seriam semânticas. O scanner original tem divergências em relação à documentação do CP1, detalhadas no documento da gramática; foi preservado byte a byte. A CLI captura seu canal de diagnóstico em execução sequencial. Aninhamento extremo permanece limitado pela pilha da JVM; listas e caudas de expressões usam iteração.
