"""Compute FIRST/FOLLOW to a fixed point and check every LL(1) alternative.

No third-party packages. --write regenerates the Java translation and tables;
the default verifies that checked-in artifacts match the verified grammar.
"""
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
EPS = "EPS"
grammar = {}
for line in (ROOT / "grammar.bnf").read_text(encoding="utf-8-sig").splitlines():
    if not line.strip():
        continue
    name, rhs = line.split(" -> ")
    assert name not in grammar, f"Duplicate rule: {name}"
    grammar[name] = [([] if p.strip() == EPS else p.split()) for p in rhs.split("|")]

first = {name: set() for name in grammar}
follow = {name: set() for name in grammar}
# EOF is the explicit final terminal, also used as the physical end marker.
follow["Program"].add("EOF")


def sequence_first(sequence):
    result = set()
    for symbol in sequence:
        values = first[symbol] if symbol in grammar else {symbol}
        result |= values - {EPS}
        if EPS not in values:
            return result
    return result | {EPS}


changed = True
while changed:
    changed = False
    for name, alternatives in grammar.items():
        before = len(first[name])
        for sequence in alternatives:
            first[name] |= sequence_first(sequence)
        changed |= before != len(first[name])

changed = True
while changed:
    changed = False
    for name, alternatives in grammar.items():
        for sequence in alternatives:
            for index, symbol in enumerate(sequence):
                if symbol not in grammar:
                    continue
                tail = sequence_first(sequence[index + 1:])
                before = len(follow[symbol])
                follow[symbol] |= tail - {EPS}
                if EPS in tail:
                    follow[symbol] |= follow[name]
                changed |= before != len(follow[symbol])

# Check nullable-prefix cycles, including indirect left recursion.
edges = {name: set() for name in grammar}
for name, alternatives in grammar.items():
    for sequence in alternatives:
        for symbol in sequence:
            if symbol not in grammar:
                break
            edges[name].add(symbol)
            if EPS not in first[symbol]:
                break


def visit(origin, node, seen):
    for child in edges[node]:
        assert child != origin, f"Left recursion: {origin}"
        if child not in seen:
            visit(origin, child, seen | {child})


select = {}
for name, alternatives in grammar.items():
    visit(name, name, {name})
    alternative_first = [sequence_first(sequence) for sequence in alternatives]
    nullable = [i for i, values in enumerate(alternative_first) if EPS in values]
    assert len(nullable) <= 1, f"Multiple nullable alternatives: {name}"
    select[name] = []
    seen = set()
    for index, values in enumerate(alternative_first):
        prediction = values - {EPS}
        if EPS in values:
            prediction |= follow[name]
        assert not seen & prediction, f"LL(1) conflict in {name}: {seen & prediction}"
        seen |= prediction
        select[name].append(prediction)


def display(values):
    return "{ " + ", ".join("ε" if v == EPS else v for v in sorted(values)) + " }"


table = ["<!-- Computed from grammar.bnf; regenerate with tools/verify_grammar.py --write. -->",
         "", "## Tabela completa FIRST/FOLLOW", "",
         "| Não-terminal | FIRST | FOLLOW |", "|---|---|---|"]
for name in grammar:
    table.append(f"| {name} | {display(first[name])} | {display(follow[name])} |")
table += ["", "## Verificação individual LL(1)", "",
          "A numeração das alternativas segue a ordem da BNF. SELECT(A → α) = FIRST(α) − {ε}, "
          "acrescentando FOLLOW(A) se α for anulável. Os SELECT de cada linha são disjuntos. "
          "Uma produção com uma só alternativa satisfaz (a) trivialmente. '—' em (c) significa que não há alternativa anulável.", "",
          "| Não-terminal | (a) FIRST disjuntos | (b) alternativas anuláveis | (c) FIRST das demais ∩ FOLLOW | SELECT por alternativa |",
          "|---|---|---|---|---|"]
for name, alternatives in grammar.items():
    nullable_count = sum(EPS in sequence_first(seq) for seq in alternatives)
    prediction_text = "<br>".join(f"{i + 1}: {display(values)}" for i, values in enumerate(select[name]))
    table.append(f"| {name} | sim | {nullable_count} | {'∅' if nullable_count else '—'} | {prediction_text} |")
table += ["", "## Sincronização por não-terminal", "",
          "Em todos os métodos, SYNC(A) = FOLLOW(A) ∪ {EOF}. O token de sincronização é preservado "
          "para o chamador. EOF sempre encerra o descarte, mesmo quando não pertence ao FOLLOW formal.", "",
          "| Não-terminal | SYNC |", "|---|---|"]
for name in grammar:
    table.append(f"| {name} | {display(follow[name] | {'EOF'})} |")

header = '''import java.util.ArrayList;
import java.util.EnumSet;
import java.util.List;
import java.util.Set;

/**
 * LL(1) recursive-descent recognizer. No AST and no semantic analysis.
 * Each switch is the SELECT table of exactly one BNF nonterminal.
 * Right-tail recursion is implemented as iteration to bound stack usage.
 * Reproduce/check the translation with tools/verify_grammar.py.
 */
public final class Parser {
    private final List<Token> tokens;
    private final List<String> errors = new ArrayList<>();
    private int current;

    public Parser(List<Token> tokens) {
        if (tokens == null || tokens.isEmpty()) {
            throw new IllegalArgumentException("Token stream must end in EOF");
        }
        this.tokens = List.copyOf(tokens);
        for (int i = 0; i < tokens.size(); i++) {
            if (tokens.get(i).getTipo() == null
                    || (tokens.get(i).getTipo() == TipoToken.EOF) != (i == tokens.size() - 1)) {
                throw new IllegalArgumentException("Exactly one EOF is required, at the end");
            }
        }
    }

    /** Restart recognition, returning true only if no syntax errors occurred. */
    public boolean parse() {
        current = 0;
        errors.clear();
        parseProgram();
        return errors.isEmpty();
    }

    public List<String> getErros() {
        return List.copyOf(errors);
    }

    private Token lookahead() { return tokens.get(current); }

    private void advance() {
        if (lookahead().getTipo() != TipoToken.EOF) current++;
    }

    private void match(TipoToken expected) {
        if (lookahead().getTipo() != expected) {
            throw new SyntaxFailure("esperado " + expected);
        }
        advance();
    }

    private void recover(String rule, SyntaxFailure failure, Set<TipoToken> follow) {
        Token token = lookahead();
        errors.add("erro sintatico na linha " + token.getLinha() + ", coluna "
                + token.getColuna() + " em " + rule + ": " + failure.getMessage()
                + "; encontrado " + token.getTipo() + " '" + token.getLexema() + "'");
        while (lookahead().getTipo() != TipoToken.EOF
                && !follow.contains(lookahead().getTipo())) {
            advance();
        }
    }

    private static final class SyntaxFailure extends RuntimeException {
        private static final long serialVersionUID = 1L;
        SyntaxFailure(String message) { super(message, null, false, false); }
    }
'''

java = [header]
for name in grammar:
    members = ", ".join("TipoToken." + v for v in sorted(follow[name]))
    java.append(f"    private static final Set<TipoToken> FOLLOW_{name} = EnumSet.of({members});")

for name, alternatives in grammar.items():
    looping = any(seq and seq[-1] == name for seq in alternatives)
    java += ["", f"    // {name} -> " + " | ".join(" ".join(seq) if seq else "epsilon" for seq in alternatives),
             f"    private void parse{name}() {{", "        try {"]
    indent = "            "
    if looping:
        java.append(indent + "while (true) {")
        indent += "    "
    java.append(indent + "switch (lookahead().getTipo()) {")
    for seq, prediction in zip(alternatives, select[name]):
        java.append(indent + "    case " + ", ".join(sorted(prediction)) + " -> {")
        body = seq[:-1] if seq and seq[-1] == name else seq
        for symbol in body:
            call = f"parse{symbol}()" if symbol in grammar else f"match(TipoToken.{symbol})"
            java.append(indent + "        " + call + ";")
        if not seq:
            java.append(indent + "        // Epsilon is selected only on FOLLOW, never by default.")
        if not (seq and seq[-1] == name):
            java.append(indent + "        return;")
        java.append(indent + "    }")
    expected = display(set.union(*select[name])).replace('"', '\\"')
    java.append(indent + f'    default -> throw new SyntaxFailure("esperado um de {expected}");')
    java.append(indent + "}")
    if looping:
        java.append("            }")
    java += ["        } catch (SyntaxFailure failure) {",
             f'            recover("{name}", failure, FOLLOW_{name});', "        }", "    }"]
java.append("}")

document_path = ROOT / "gramatica-first-follow.md"
marker = "<!-- BEGIN VERIFIED TABLES -->"
document = document_path.read_text(encoding="utf-8-sig")
assert document.count(marker) == 1, "Missing or repeated table marker"
prefix = document.split(marker)[0]
# Ensure that the human-facing BNF is the same grammar used by the checker.
document_bnf = prefix.split("```bnf\n", 1)[1].split("```", 1)[0].strip()
assert document_bnf == (ROOT / "grammar.bnf").read_text(encoding="utf-8-sig").strip(), "Document BNF is outdated"
outputs = {ROOT / "src/Parser.java": "\n".join(java) + "\n",
           document_path: prefix + marker + "\n" + "\n".join(table) + "\n"}
for path, content in outputs.items():
    if "--write" in sys.argv:
        path.write_text(content, encoding="utf-8")
    else:
        assert path.read_text(encoding="utf-8-sig") == content, f"Outdated artifact: {path.name}"
print(f"OK: {len(grammar)} nonterminals; no left recursion; all LL(1) clauses verified.")
print("Artifacts " + ("generated." if "--write" in sys.argv else "consistent."))
