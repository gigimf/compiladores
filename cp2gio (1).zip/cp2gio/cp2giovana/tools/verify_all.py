"""Reproducible verification with bounded execution time and persisted output."""
import argparse
import hashlib
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile

sys.stdout.reconfigure(encoding="utf-8")
ROOT = Path(__file__).resolve().parents[1]
arguments = argparse.ArgumentParser()
arguments.add_argument("--jdk", help="JDK root (not bin); otherwise use JAVA_HOME or PATH")
options = arguments.parse_args()
jdk = options.jdk or os.environ.get("JAVA_HOME")
suffix = ".exe" if os.name == "nt" else ""


def executable(name):
    path = str(Path(jdk) / "bin" / (name + suffix)) if jdk else shutil.which(name)
    if not path or not Path(path).is_file():
        raise SystemExit(f"Missing {name}; provide --jdk with JDK 17 or later")
    return path


java, javac = executable("java"), executable("javac")
log = []


def record(message):
    log.append(message)
    print(message)


def run(title, command, expected=0):
    if command[0] == java:
        command = [java, "-Dfile.encoding=UTF-8", "-Dstdout.encoding=UTF-8",
                   "-Dstderr.encoding=UTF-8", *command[1:]]
    result = subprocess.run(command, cwd=ROOT, text=True, encoding="utf-8", errors="replace",
                            capture_output=True, timeout=60)
    record(f"\n[{title}] exit={result.returncode}\n{result.stdout}{result.stderr}".rstrip())
    if result.returncode != expected:
        raise AssertionError(f"{title}: expected exit {expected}, received {result.returncode}")
    return result


try:
    run("Java version", [java, "-version"])
    for line in (ROOT / "cp1-sha256.txt").read_text().splitlines():
        expected, name = line.split()
        actual = hashlib.sha256((ROOT / "src" / name).read_bytes()).hexdigest().upper()
        assert actual == expected, f"CP1 file modified: {name}"
        record(f"CP1 SHA256 OK: {name} {actual}")
    run("FIRST/FOLLOW and LL(1)", [sys.executable, "tools/verify_grammar.py"])
    (ROOT / "out").mkdir(exist_ok=True)
    sources = sorted((ROOT / "src").glob("*.java")) + sorted((ROOT / "test").glob("*.java"))
    run("Compile Java 17 with all warnings", [javac, "--release", "17", "-encoding", "UTF-8",
         "-Xlint:all", "-Werror", "-d", "out", *map(str, sources)])
    run("Parser regression suite", [java, "-cp", "out", "ParserTest"])
    run("Independent Earley oracle", [sys.executable, "test/differential.py", java])
    for path in sorted((ROOT / "examples").glob("*.smol")):
        expected = 0 if int(path.name[:2]) <= 3 else 1
        result = run(f"CLI {path.name}", [java, "-cp", "out", "Main", str(path)], expected)
        assert result.stdout.strip() == ("ACEITO" if expected == 0 else "REJEITADO")
        if expected:
            assert "linha " in result.stderr and "coluna " in result.stderr
        if path.name.startswith("07"):
            assert "linha 2, coluna 13" in result.stderr and "linha 4, coluna 10" in result.stderr
    for index, source in enumerate(['"unterminated', "/* unterminated", "'ab'", "_name", "int x = @;"]):
        with tempfile.TemporaryDirectory(dir=ROOT / "out") as directory:
            sample = Path(directory) / "invalid.smol"
            sample.write_text(source, encoding="utf-8")
            result = run(f"Lexical error {index + 1}", [java, "-cp", "out", "Main", str(sample)], 1)
            assert "erro na linha" in result.stderr and result.stdout.strip() == "REJEITADO"
    run("CLI missing arguments", [java, "-cp", "out", "Main"], 2)
    run("CLI missing file", [java, "-cp", "out", "Main", "examples/nonexistent.smol"], 2)
    record("\nALL CHECKS PASSED")
finally:
    (ROOT / "test/verification.log").write_text("\n".join(log) + "\n", encoding="utf-8")
