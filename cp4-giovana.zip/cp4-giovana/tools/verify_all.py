"""Reproducible verification for CP4."""
import argparse
import hashlib
import os
from pathlib import Path
import shutil
import subprocess
import sys

sys.stdout.reconfigure(encoding="utf-8")
ROOT = Path(__file__).resolve().parents[1]
arguments = argparse.ArgumentParser()
arguments.add_argument("--jdk", help="JDK root (not bin); otherwise use JAVA_HOME or PATH")
options = arguments.parse_args()
jdk = options.jdk or os.environ.get("JAVA_HOME")
suffix = ".exe" if os.name == "nt" else ""


def executable(name):
    path = str(Path(jdk) / "bin" / (name + suffix)) if jdk else shutil.which(name)
    if not path or not Path(path).is_file():
        raise SystemExit(f"Missing {name}; provide --jdk with JDK 17 or later")
    return path


java, javac = executable("java"), executable("javac")
log = []


def record(message):
    log.append(message)
    print(message)


def run(title, command, expected=0):
    if command[0] == java:
        command = [java, "-Dfile.encoding=UTF-8", "-Dstdout.encoding=UTF-8",
                   "-Dstderr.encoding=UTF-8", *command[1:]]
    result = subprocess.run(command, cwd=ROOT, text=True, encoding="utf-8", errors="replace",
                            capture_output=True, timeout=120)
    record(f"\n[{title}] exit={result.returncode}\n{result.stdout}{result.stderr}".rstrip())
    if result.returncode != expected:
        raise AssertionError(f"{title}: expected exit {expected}, received {result.returncode}")
    return result


try:
    run("Java version", [java, "-version"])
    for line in (ROOT / "cp1-sha256.txt").read_text().splitlines():
        if not line.strip():
            continue
        expected, name = line.split()
        actual = hashlib.sha256((ROOT / "src" / name).read_bytes()).hexdigest().upper()
        assert actual == expected, f"CP1 file modified: {name} (got {actual}, want {expected})"
        record(f"CP1 SHA256 OK: {name} {actual}")
    (ROOT / "out").mkdir(exist_ok=True)
    sources = []
    for pattern in ("src/*.java", "src/ast/*.java", "src/visitor/*.java", "src/symbols/*.java", "test/*.java"):
        sources.extend(sorted(ROOT.glob(pattern)))
    run("Compile Java 17", [javac, "--release", "17", "-encoding", "UTF-8",
         "-Xlint:all", "-Werror", "-d", "out", *map(str, sources)])
    run("SymbolTable unit suite", [java, "-cp", "out", "SymbolTableTest"])
    run("Identification semantic suite", [java, "-cp", "out", "IdentificationTest"])
    run("CP2 regression suite (Parser)", [java, "-cp", "out", "ParserTest"])
    run("CP3 regression suite (AST)", [java, "-cp", "out", "AstTest"])
    record("\nALL CHECKS PASSED")
finally:
    (ROOT / "test/verification.log").write_text("\n".join(log) + "\n", encoding="utf-8")
