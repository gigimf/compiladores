import java.util.ArrayList;
import java.util.List;

/**
 * Utilitário para inspecionar e serializar as resoluções da AST decorada.
 * Percorre a árvore e gera a lista determinística de resolução de identificadores
 * no formato 'linha L: nome -> nome@Ldecl'.
 */
public final class ResolutionPrinter implements Visitor<Void> {
    private final List<String> resolutions = new ArrayList<>();

    public String print(Node root) {
        resolutions.clear();
        if (root != null) {
            root.accept(this);
        }
        return String.join("\n", resolutions);
    }

    public List<String> getResolutions() {
        return List.copyOf(resolutions);
    }

    @Override
    public Void visitProgram(ProgramNode node) {
        for (Node decl : node.getDeclarations()) {
            decl.accept(this);
        }
        return null;
    }

    @Override
    public Void visitVarDecl(VarDeclNode node) {
        if (node.hasInitializer()) {
            node.getInitializer().accept(this);
        }
        return null;
    }

    @Override
    public Void visitFuncDecl(FuncDeclNode node) {
        for (ParamNode param : node.getParameters()) {
            param.accept(this);
        }
        node.getBody().accept(this);
        return null;
    }

    @Override
    public Void visitProcDecl(ProcDeclNode node) {
        for (ParamNode param : node.getParameters()) {
            param.accept(this);
        }
        node.getBody().accept(this);
        return null;
    }

    @Override
    public Void visitParam(ParamNode node) {
        return null;
    }

    @Override
    public Void visitBlock(BlockNode node) {
        for (Node stmt : node.getStatements()) {
            stmt.accept(this);
        }
        return null;
    }

    @Override
    public Void visitAssignStmt(AssignStmtNode node) {
        node.getExpression().accept(this);
        return null;
    }

    @Override
    public Void visitCallStmt(CallStmtNode node) {
        for (Node arg : node.getArguments()) {
            arg.accept(this);
        }
        return null;
    }

    @Override
    public Void visitCallExpr(CallExprNode node) {
        for (Node arg : node.getArguments()) {
            arg.accept(this);
        }
        return null;
    }

    @Override
    public Void visitIfStmt(IfStmtNode node) {
        node.getCondition().accept(this);
        node.getThenBranch().accept(this);
        if (node.hasElse()) {
            node.getElseBranch().accept(this);
        }
        return null;
    }

    @Override
    public Void visitWhileStmt(WhileStmtNode node) {
        node.getCondition().accept(this);
        node.getBody().accept(this);
        return null;
    }

    @Override
    public Void visitReturnStmt(ReturnStmtNode node) {
        if (node.hasValue()) {
            node.getValue().accept(this);
        }
        return null;
    }

    @Override
    public Void visitIntLit(IntLitNode node) {
        return null;
    }

    @Override
    public Void visitFloatLit(FloatLitNode node) {
        return null;
    }

    @Override
    public Void visitBoolLit(BoolLitNode node) {
        return null;
    }

    @Override
    public Void visitCharLit(CharLitNode node) {
        return null;
    }

    @Override
    public Void visitStringLit(StringLitNode node) {
        return null;
    }

    @Override
    public Void visitIdent(IdentNode node) {
        Symbol decl = node.getDecl();
        if (decl != null && decl.getDeclNode() != null) {
            resolutions.add("linha " + node.getLinha() + ": " + node.getName()
                    + " -> " + decl.getName() + "@" + decl.getDeclNode().getLinha());
        } else {
            resolutions.add("linha " + node.getLinha() + ": " + node.getName() + " -> [nao declarado]");
        }
        return null;
    }

    @Override
    public Void visitBinOp(BinOpNode node) {
        node.getLeft().accept(this);
        node.getRight().accept(this);
        return null;
    }

    @Override
    public Void visitUnaryOp(UnaryOpNode node) {
        node.getOperand().accept(this);
        return null;
    }
}
