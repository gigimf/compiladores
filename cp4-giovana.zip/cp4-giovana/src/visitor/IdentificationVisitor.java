import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Passada de identificação (Aula 11).
 * Implementa Visitor<Void> sobre a AST sem nenhum instanceof ou switch sobre tipos de nós.
 * Responsabilidades:
 * - Abre e fecha escopos léxicos usando a SymbolTable.
 * - Registra declarações de variáveis, parâmetros, procedimentos e funções.
 * - Detecta redeclarações no mesmo escopo, descartando a segunda e preservando a primeira.
 * - Resolve usos de identificadores através de lookup, gravando a referência Symbol em decl.
 * - Detecta usos de identificadores não declarados.
 * - Acumula todos os erros de identificação em ordem do texto de forma determinística.
 */
public final class IdentificationVisitor implements Visitor<Void> {
    private final SymbolTable table;
    private final List<String> erros = new ArrayList<>();

    public IdentificationVisitor() {
        this(new ScopedSymbolTable());
    }

    public IdentificationVisitor(SymbolTable table) {
        this.table = table;
    }

    public List<String> getErros() {
        return Collections.unmodifiableList(erros);
    }

    public boolean hasErrors() {
        return !erros.isEmpty();
    }

    public SymbolTable getTable() {
        return table;
    }

    private void reportError(int linha, String msg) {
        erros.add("linha " + linha + ": " + msg);
    }

    @Override
    public Void visitProgram(ProgramNode node) {
        for (Node decl : node.getDeclarations()) {
            decl.accept(this);
        }
        return null;
    }

    @Override
    public Void visitVarDecl(VarDeclNode node) {
        // Avalia o inicializador antes da declaração (garantindo regra declarar-antes-de-usar)
        if (node.hasInitializer()) {
            node.getInitializer().accept(this);
        }

        Symbol sym = new Symbol(node.getName(), SymbolCategory.VARIABLE, node, table.level(), node.getType());
        boolean success = table.declare(sym);
        if (!success) {
            Symbol existing = table.lookupLocal(node.getName());
            int prevLine = existing != null && existing.getDeclNode() != null ? existing.getDeclNode().getLinha() : node.getLinha();
            reportError(node.getLinha(), "'" + node.getName() + "' já declarado neste escopo (linha " + prevLine + ")");
        }
        return null;
    }

    @Override
    public Void visitFuncDecl(FuncDeclNode node) {
        // Declara a função no escopo externo antes de abrir o escopo interno (permite recursão)
        Symbol funcSym = new Symbol(node.getName(), SymbolCategory.FUNCTION, node, table.level(), node.getReturnType());
        boolean success = table.declare(funcSym);
        if (!success) {
            Symbol existing = table.lookupLocal(node.getName());
            int prevLine = existing != null && existing.getDeclNode() != null ? existing.getDeclNode().getLinha() : node.getLinha();
            reportError(node.getLinha(), "'" + node.getName() + "' já declarado neste escopo (linha " + prevLine + ")");
        }

        // Abre escopo para os parâmetros e o corpo da função
        table.openScope();
        for (ParamNode param : node.getParameters()) {
            param.accept(this);
        }

        // Decisão de projeto: Parâmetros e corpo compartilham o mesmo escopo.
        // Os comandos do corpo são visitados diretamente no escopo dos parâmetros.
        for (Node stmt : node.getBody().getStatements()) {
            stmt.accept(this);
        }
        table.closeScope();
        return null;
    }

    @Override
    public Void visitProcDecl(ProcDeclNode node) {
        // Declara o procedimento no escopo externo antes de abrir o escopo interno
        Symbol procSym = new Symbol(node.getName(), SymbolCategory.PROCEDURE, node, table.level(), null);
        boolean success = table.declare(procSym);
        if (!success) {
            Symbol existing = table.lookupLocal(node.getName());
            int prevLine = existing != null && existing.getDeclNode() != null ? existing.getDeclNode().getLinha() : node.getLinha();
            reportError(node.getLinha(), "'" + node.getName() + "' já declarado neste escopo (linha " + prevLine + ")");
        }

        table.openScope();
        for (ParamNode param : node.getParameters()) {
            param.accept(this);
        }

        for (Node stmt : node.getBody().getStatements()) {
            stmt.accept(this);
        }
        table.closeScope();
        return null;
    }

    @Override
    public Void visitParam(ParamNode node) {
        Symbol paramSym = new Symbol(node.getName(), SymbolCategory.PARAMETER, node, table.level(), node.getType());
        boolean success = table.declare(paramSym);
        if (!success) {
            Symbol existing = table.lookupLocal(node.getName());
            int prevLine = existing != null && existing.getDeclNode() != null ? existing.getDeclNode().getLinha() : node.getLinha();
            reportError(node.getLinha(), "'" + node.getName() + "' já declarado neste escopo (linha " + prevLine + ")");
        }
        return null;
    }

    @Override
    public Void visitBlock(BlockNode node) {
        // Blocos: openScope, filhos na ordem, closeScope
        table.openScope();
        for (Node stmt : node.getStatements()) {
            stmt.accept(this);
        }
        table.closeScope();
        return null;
    }

    @Override
    public Void visitIdent(IdentNode node) {
        // Uso de identificador: busca na tabela; se achou, grava em decl; se não, reporta erro
        Symbol s = table.lookup(node.getName());
        if (s == null) {
            reportError(node.getLinha(), "'" + node.getName() + "' não declarado");
            node.setDecl(null);
        } else {
            node.setDecl(s);
        }
        return null;
    }

    @Override
    public Void visitAssignStmt(AssignStmtNode node) {
        // Verifica se o identificador de destino foi declarado
        Symbol s = table.lookup(node.getName());
        if (s == null) {
            reportError(node.getLinha(), "'" + node.getName() + "' não declarado");
        }
        node.getExpression().accept(this);
        return null;
    }

    @Override
    public Void visitCallStmt(CallStmtNode node) {
        // Verifica se a rotina chamada foi declarada
        Symbol s = table.lookup(node.getName());
        if (s == null) {
            reportError(node.getLinha(), "'" + node.getName() + "' não declarado");
        }
        for (Node arg : node.getArguments()) {
            arg.accept(this);
        }
        return null;
    }

    @Override
    public Void visitCallExpr(CallExprNode node) {
        // Verifica se a função chamada foi declarada
        Symbol s = table.lookup(node.getName());
        if (s == null) {
            reportError(node.getLinha(), "'" + node.getName() + "' não declarado");
        }
        for (Node arg : node.getArguments()) {
            arg.accept(this);
        }
        return null;
    }

    @Override
    public Void visitIfStmt(IfStmtNode node) {
        node.getCondition().accept(this);
        node.getThenBranch().accept(this);
        if (node.hasElse()) {
            node.getElseBranch().accept(this);
        }
        return null;
    }

    @Override
    public Void visitWhileStmt(WhileStmtNode node) {
        node.getCondition().accept(this);
        node.getBody().accept(this);
        return null;
    }

    @Override
    public Void visitReturnStmt(ReturnStmtNode node) {
        if (node.hasValue()) {
            node.getValue().accept(this);
        }
        return null;
    }

    @Override
    public Void visitBinOp(BinOpNode node) {
        node.getLeft().accept(this);
        node.getRight().accept(this);
        return null;
    }

    @Override
    public Void visitUnaryOp(UnaryOpNode node) {
        node.getOperand().accept(this);
        return null;
    }

    @Override
    public Void visitIntLit(IntLitNode node) {
        return null;
    }

    @Override
    public Void visitFloatLit(FloatLitNode node) {
        return null;
    }

    @Override
    public Void visitBoolLit(BoolLitNode node) {
        return null;
    }

    @Override
    public Void visitCharLit(CharLitNode node) {
        return null;
    }

    @Override
    public Void visitStringLit(StringLitNode node) {
        return null;
    }
}
