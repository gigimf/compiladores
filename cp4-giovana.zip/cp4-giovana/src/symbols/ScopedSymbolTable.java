import java.util.ArrayDeque;
import java.util.Deque;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Implementação de SymbolTable baseada em Pilha de Mapas (Stack of Maps).
 * Cada escopo léxico é representado por um Map<String, Symbol>.
 * O escopo global (nível 0) é aberto na inicialização.
 */
public final class ScopedSymbolTable implements SymbolTable {
    private final Deque<Map<String, Symbol>> scopes = new ArrayDeque<>();

    public ScopedSymbolTable() {
        // Inicializa com o escopo global (nível 0)
        scopes.push(new LinkedHashMap<>());
    }

    @Override
    public void openScope() {
        scopes.push(new LinkedHashMap<>());
    }

    @Override
    public void closeScope() {
        if (scopes.size() <= 1) {
            throw new IllegalStateException("Tentativa de fechar escopo inexistente: o escopo global (nível 0) não pode ser fechado.");
        }
        scopes.pop();
    }

    @Override
    public boolean declare(Symbol s) {
        if (s == null || s.getName() == null) {
            return false;
        }
        Map<String, Symbol> current = scopes.peek();
        if (current == null) {
            throw new IllegalStateException("Nenhum escopo ativo disponível para declaração.");
        }
        if (current.containsKey(s.getName())) {
            // Contrato: declare não substitui um símbolo existente; a primeira declaração permanece.
            return false;
        }
        current.put(s.getName(), s);
        return true;
    }

    @Override
    public Symbol lookupLocal(String name) {
        if (name == null || scopes.isEmpty()) {
            return null;
        }
        Map<String, Symbol> current = scopes.peek();
        return current != null ? current.get(name) : null;
    }

    @Override
    public Symbol lookup(String name) {
        if (name == null || scopes.isEmpty()) {
            return null;
        }
        // Busca do escopo mais interno (topo da pilha) ao mais externo (global)
        for (Map<String, Symbol> scope : scopes) {
            Symbol found = scope.get(name);
            if (found != null) {
                return found;
            }
        }
        return null;
    }

    @Override
    public int level() {
        return Math.max(0, scopes.size() - 1);
    }
}
