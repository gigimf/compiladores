public final class Symbol {
    private final String name;
    private final SymbolCategory category;
    private final Node declNode;
    private final int level;

    // Campos reservados para as Aulas 12 a 19 (CP5 e CP6)
    private TypeKind type;
    private int offset;

    public Symbol(String name, SymbolCategory category, Node declNode, int level) {
        this(name, category, declNode, level, null);
    }

    public Symbol(String name, SymbolCategory category, Node declNode, int level, TypeKind type) {
        this.name = name;
        this.category = category;
        this.declNode = declNode;
        this.level = level;
        this.type = type;
        this.offset = 0;
    }

    public String getName() {
        return name;
    }

    public SymbolCategory getCategory() {
        return category;
    }

    public Node getDeclNode() {
        return declNode;
    }

    public int getLevel() {
        return level;
    }

    public TypeKind getType() {
        return type;
    }

    public void setType(TypeKind type) {
        this.type = type;
    }

    public int getOffset() {
        return offset;
    }

    public void setOffset(int offset) {
        this.offset = offset;
    }

    @Override
    public String toString() {
        return name + "@" + (declNode != null ? declNode.getLinha() : "?")
                + " (" + category + ", level " + level + (type != null ? ", type " + type : "") + ")";
    }
}
