public enum SymbolCategory {
    VARIABLE,
    PARAMETER,
    FUNCTION,
    PROCEDURE
}
