public final class IdentNode extends Node {
    private final String name;
    private Symbol decl;

    public IdentNode(String name, int linha, int coluna) {
        super(linha, coluna);
        this.name = name;
        this.decl = null;
    }

    public String getName() {
        return name;
    }

    public Symbol getDecl() {
        return decl;
    }

    public void setDecl(Symbol decl) {
        this.decl = decl;
    }

    @Override
    public <T> T accept(Visitor<T> visitor) {
        return visitor.visitIdent(this);
    }
}
