# CP4 — Giovana (Tabela de Símbolos + Passada de Identificação)

Entrega do Checkpoint 4 (Compiladores) em nome de **Giovana Ferreira**.  
Implementação da análise contextual baseada na AST do CP3, tabela de símbolos (`SymbolTable`) da Aula 11 e passada de identificação (`IdentificationVisitor`).

## Estrutura do Projeto

- `escopo-design.md` — Documento de projeto: evolução passo a passo do ambiente, campos do `Symbol`, justificativa da implementação (`ScopedSymbolTable` via pilha de mapas), detalhamento das 5 decisões de projeto e suíte de testes.
- `grammar.bnf` — Gramática livre de contexto LL(1) da linguagem.
- `cp1-sha256.txt` — Hashes SHA256 que garantem a integridade dos arquivos originais do CP1 (`Scanner.java`, `Token.java`, `TipoToken.java`).
- `src/`
  - `Scanner.java`, `Token.java`, `TipoToken.java` (CP1 preservado)
  - `Parser.java`, `ParseResult.java` (CP2/CP3)
  - `Main.java` — CLI completa: executa scanner, parser e passada de identificação contextual.
  - `src/ast/` — Hierarquia de nós da AST (com campo `decl` adicionado a `IdentNode.java`).
  - `src/visitor/` — `Visitor.java`, `TreePrinter.java`, `SourcePrinter.java`, `IdentificationVisitor.java`, `ResolutionPrinter.java`.
  - `src/symbols/` — `SymbolTable.java` (interface da Aula 11), `ScopedSymbolTable.java` (pilha de mapas), `Symbol.java`, `SymbolCategory.java`.
- `programas/` — Programas de teste na linguagem (`.smol`):
  - `valido-sombreamento.smol` (programa obrigatório 1 — aninhamento de blocos, sombreamento e uso após fechamento)
  - `redeclaracao.smol` (programa obrigatório 2 — redeclaração no mesmo escopo)
  - `nao-declarado.smol` (programa obrigatório 3 — identificador não declarado)
  - `decisao1-sombreamento.smol` a `decisao5-espaco-nomes.smol` (as 5 decisões de projeto)
  - `tres-erros.smol` (múltiplos erros acumulados)
  - `procedimento-recursivo.smol` (recursão direta válida)
  - `uso-apos-bloco.smol` (verificação de fechamento de escopo)
- `test/`
  - `SymbolTableTest.java` — Testes unitários da tabela de símbolos isolada (24 verificações).
  - `IdentificationTest.java` — Testes da passada de identificação semântica (24 verificações).
  - `ParserTest.java` — Regressão sintática do CP2 (35 verificações).
  - `AstTest.java` — Regressão da AST do CP3 (15 verificações).
  - `esperado/` — Saídas esperadas escritas à mão para comparação nos testes.
- `tools/`
  - `verify_all.py` — Script automatizado de verificação completa (Java 17, SHA256 do CP1, compilação com `-Werror` e execução de todas as suítes).

## Como Compilar e Testar

Requisitos: JDK 17 ou superior e Python 3.

```bash
cd cp4-giovana

# 1. Compilar todo o projeto
mkdir -p out
javac --release 17 -encoding UTF-8 -Xlint:all -Werror -d out $(find src test -name '*.java')

# 2. Executar suíte de testes unitários da Tabela de Símbolos
java -cp out SymbolTableTest

# 3. Executar suíte de testes da Passada de Identificação
java -cp out IdentificationTest

# 4. Executar regressões do CP2 (Parser) e CP3 (AST)
java -cp out ParserTest
java -cp out AstTest

# 5. Executar verificação automatizada completa (SHA256, build e todos os testes)
python3 tools/verify_all.py
```

## Como Usar o Compilador (CLI)

Para analisar um arquivo fonte `.smol`:

```bash
# Programa válido (imprime ACEITO e código de retorno 0):
java -cp out Main programas/valido-sombreamento.smol

# Programa com erro contextual (imprime erros no stderr, REJEITADO no stdout e código 1):
java -cp out Main programas/redeclaracao.smol
```
