import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

/**
 * Suíte de testes da passada de identificação contextual (Aula 11).
 * Cobre todos os requisitos da Seção 5:
 * - Três programas obrigatórios (válido com sombreamento, redeclaração, nome não declarado)
 * - Um programa por decisão de projeto (decisões 1 a 5)
 * - Pelo menos três erros reportados em uma rodada na ordem do texto
 * - Procedimento recursivo
 * - Uso depois do fechamento do bloco
 * - Saídas esperadas confrontadas contra arquivos em test/esperado/
 */
public class IdentificationTest {
    private static int tests = 0;
    private static int failures = 0;
    private static final Path ROOT = resolveRoot();

    public static void main(String[] args) throws IOException {
        // 1. Três programas obrigatórios
        testValidResolutions("valido-sombreamento");
        testExpectedErrors("redeclaracao");
        testExpectedErrors("nao-declarado");

        // 2. Cinco decisões de projeto
        testExpectedErrors("decisao1-sombreamento");
        testExpectedErrors("decisao2-declarar-antes-usar");
        testExpectedErrors("decisao3-recursao-mutua");
        testExpectedErrors("decisao4-param-corpo");
        testExpectedErrors("decisao5-espaco-nomes");

        // 3. Programas adicionais requeridos
        testExpectedErrors("tres-erros");
        testValidResolutions("procedimento-recursivo");
        testExpectedErrors("uso-apos-bloco");

        // 4. Teste de robustez (não lança NPE, acumula erros)
        testRobustez();

        System.out.printf("IdentificationTest: %d checks, %d failures%n", tests, failures);
        if (failures != 0) {
            throw new AssertionError("Falhas nos testes de identificação");
        }
    }

    private static void testValidResolutions(String basename) throws IOException {
        String source = Files.readString(ROOT.resolve("programas/" + basename + ".smol"), StandardCharsets.UTF_8);
        ProgramNode program = parseValid(source);

        IdentificationVisitor visitor = new IdentificationVisitor();
        program.accept(visitor);

        check(!visitor.hasErrors(), basename + " sem erros contextuais");
        if (visitor.hasErrors()) {
            System.err.println("Erros inesperados em " + basename + ": " + visitor.getErros());
        }

        ResolutionPrinter printer = new ResolutionPrinter();
        String actual = printer.print(program).stripTrailing();
        String expected = Files.readString(ROOT.resolve("test/esperado/" + basename + ".txt"), StandardCharsets.UTF_8)
                .replace("\r\n", "\n").stripTrailing();

        if (!actual.equals(expected)) {
            System.err.println("--- esperado " + basename + " ---");
            System.err.println(expected);
            System.err.println("--- obtido ---");
            System.err.println(actual);
        }
        check(actual.equals(expected), "resolucoes " + basename);
    }

    private static void testExpectedErrors(String basename) throws IOException {
        String source = Files.readString(ROOT.resolve("programas/" + basename + ".smol"), StandardCharsets.UTF_8);
        ProgramNode program = parseValid(source);

        IdentificationVisitor visitor = new IdentificationVisitor();
        program.accept(visitor);

        check(visitor.hasErrors(), basename + " possui erros contextuais reportados");

        String actual = String.join("\n", visitor.getErros()).stripTrailing();
        String expected = Files.readString(ROOT.resolve("test/esperado/" + basename + ".txt"), StandardCharsets.UTF_8)
                .replace("\r\n", "\n").stripTrailing();

        if (!actual.equals(expected)) {
            System.err.println("--- esperado " + basename + " ---");
            System.err.println(expected);
            System.err.println("--- obtido ---");
            System.err.println(actual);
        }
        check(actual.equals(expected), "mensagens de erro " + basename);
    }

    private static void testRobustez() {
        // Programa com múltiplos erros e uso antes de bloco não deve crashar
        String source = "main() { a = 1; { b = 2; } c = 3; }";
        ProgramNode program = parseValid(source);
        IdentificationVisitor visitor = new IdentificationVisitor();
        boolean completedWithoutCrash = false;
        try {
            program.accept(visitor);
            completedWithoutCrash = true;
        } catch (Exception e) {
            completedWithoutCrash = false;
        }
        check(completedWithoutCrash, "passada completa sem NPE ou excecoes inesperadas");
        check(visitor.getErros().size() == 3, "tres erros identificados com sucesso na ordem");
    }

    private static ProgramNode parseValid(String source) {
        Parser parser = new Parser(new Scanner(source).scanTokens());
        ParseResult result = parser.parseWithAst();
        if (!result.isValid()) {
            throw new AssertionError("esperava parse sintatico valido: " + parser.getErros());
        }
        return result.getProgram();
    }

    private static Path resolveRoot() {
        Path cwd = Path.of("").toAbsolutePath().normalize();
        if (Files.isDirectory(cwd.resolve("programas"))) {
            return cwd;
        }
        if (Files.isDirectory(cwd.resolve("cp4-giovana/programas"))) {
            return cwd.resolve("cp4-giovana");
        }
        throw new IllegalStateException("Nao foi possivel localizar o diretorio raiz do projeto cp4");
    }

    private static void check(boolean cond, String name) {
        tests++;
        if (cond) {
            System.out.println("PASS " + name);
        } else {
            System.out.println("FAIL " + name);
            failures++;
        }
    }
}
