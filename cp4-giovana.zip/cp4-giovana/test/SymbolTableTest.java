/**
 * Testes unitários para a Tabela de Símbolos isolada.
 * Cobre todos os requisitos da Seção 5:
 * - declarar e buscar (declare, lookup)
 * - sombreamento e restauração após closeScope
 * - redeclaração (declare devolve false, primeiro símbolo permanece inalterado)
 * - lookupLocal não enxerga escopo externo
 * - lookup de nome inexistente devolve null
 * - level() atualizado corretamente
 * - closeScope sem escopo aberto lança IllegalStateException (nunca NullPointerException)
 */
public class SymbolTableTest {
    private static int tests = 0;
    private static int failures = 0;

    public static void main(String[] args) {
        testDeclararEBuscar();
        testSombreamentoERestauracao();
        testRedeclaracaoMantemPrimeiro();
        testLookupLocalNaoEnxergaExterno();
        testLookupInexistenteDevolveNull();
        testLevelTracking();
        testCloseScopeSemEscopoAberto();

        System.out.printf("SymbolTableTest: %d checks, %d failures%n", tests, failures);
        if (failures != 0) {
            throw new AssertionError("Falhas nos testes unitários da SymbolTable");
        }
    }

    private static void testDeclararEBuscar() {
        SymbolTable table = new ScopedSymbolTable();
        Symbol x = new Symbol("x", SymbolCategory.VARIABLE, null, table.level());
        check(table.declare(x), "declarar x no escopo global");
        check(table.lookup("x") == x, "buscar x encontra símbolo declarado");
        check(table.lookupLocal("x") == x, "lookupLocal acha x no escopo global");
    }

    private static void testSombreamentoERestauracao() {
        SymbolTable table = new ScopedSymbolTable();
        Symbol globalX = new Symbol("x", SymbolCategory.VARIABLE, null, 0);
        table.declare(globalX);

        table.openScope(); // nível 1
        check(table.level() == 1, "level apos openScope eh 1");
        check(table.lookup("x") == globalX, "lookup no escopo interno enxerga global antes de sombrear");

        Symbol localX = new Symbol("x", SymbolCategory.VARIABLE, null, 1);
        check(table.declare(localX), "declarar x no escopo interno sombreia global");
        check(table.lookup("x") == localX, "lookup retorna o x interno sombreado");
        check(table.lookupLocal("x") == localX, "lookupLocal retorna x interno");

        table.closeScope(); // volta ao nível 0
        check(table.level() == 0, "level apos closeScope volta a 0");
        check(table.lookup("x") == globalX, "lookup restaura o x global apos fechar bloco interno");
    }

    private static void testRedeclaracaoMantemPrimeiro() {
        SymbolTable table = new ScopedSymbolTable();
        Symbol primeiro = new Symbol("a", SymbolCategory.VARIABLE, null, 0);
        Symbol segundo = new Symbol("a", SymbolCategory.VARIABLE, null, 0);

        check(table.declare(primeiro), "primeira declaracao de 'a' sucede");
        check(!table.declare(segundo), "segunda declaracao de 'a' no mesmo escopo devolve false");
        check(table.lookup("a") == primeiro, "o primeiro simbolo permanece inalterado");
        check(table.lookupLocal("a") == primeiro, "lookupLocal confirma primeiro simbolo inalterado");
    }

    private static void testLookupLocalNaoEnxergaExterno() {
        SymbolTable table = new ScopedSymbolTable();
        Symbol globalA = new Symbol("a", SymbolCategory.VARIABLE, null, 0);
        table.declare(globalA);

        table.openScope(); // nível 1
        check(table.lookup("a") == globalA, "lookup enxerga escopo externo");
        check(table.lookupLocal("a") == null, "lookupLocal nao enxerga escopo externo (devolve null)");
        table.closeScope();
    }

    private static void testLookupInexistenteDevolveNull() {
        SymbolTable table = new ScopedSymbolTable();
        check(table.lookup("fantasma") == null, "lookup de nome inexistente devolve null");
        check(table.lookupLocal("fantasma") == null, "lookupLocal de nome inexistente devolve null");
    }

    private static void testLevelTracking() {
        SymbolTable table = new ScopedSymbolTable();
        check(table.level() == 0, "nivel inicial eh 0");
        table.openScope();
        check(table.level() == 1, "nivel apos 1 openScope eh 1");
        table.openScope();
        check(table.level() == 2, "nivel apos 2 openScope eh 2");
        table.closeScope();
        check(table.level() == 1, "nivel apos 1 closeScope eh 1");
        table.closeScope();
        check(table.level() == 0, "nivel apos fechar tudo eh 0");
    }

    private static void testCloseScopeSemEscopoAberto() {
        SymbolTable table = new ScopedSymbolTable();
        boolean threwExpected = false;
        try {
            table.closeScope(); // escopo global no nivel 0 nao pode ser fechado
        } catch (IllegalStateException e) {
            threwExpected = true;
        } catch (Exception e) {
            // Se lancar NullPointerException ou outra, falha
            threwExpected = false;
        }
        check(threwExpected, "closeScope sem escopo aberto lanca IllegalStateException documentada e nunca NPE");
    }

    private static void check(boolean cond, String name) {
        tests++;
        if (cond) {
            System.out.println("PASS " + name);
        } else {
            System.out.println("FAIL " + name);
            failures++;
        }
    }
}
