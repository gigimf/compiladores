import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;

public class AstTest {
    private static int tests;
    private static int failures;
    private static final Path ROOT = resolveTestRoot();
    private static final TreePrinter TREE = new TreePrinter();
    private static final SourcePrinter SOURCE = new SourcePrinter();

    public static void main(String[] args) throws IOException {
        expectTree("five-types", "int count = 3; double rate <- 2.5; bool active = true; char letter = 'a'; string message = \"hello\";");
        expectTree("control-flow", "main() { if (true) { int x = 1; } else { x = 0; } while (x < 2) { x <- x + 1; } }");
        expectTree("functions", "int f(int a) { return a; } p() { return; } main() { int x = f(1); p(); }");
        expectTree("prec-add-mul", "int x = a + b * c;");
        expectTree("prec-sub-left", "int x = a - b - c;");
        expectTree("prec-parens", "int x = a - (b - c);");
        expectTree("parens-redundant", "int x = (((a)));");
        expectTree("parens-plain", "int x = a;");
        roundTrip("five-types", "int count = 3; double rate <- 2.5; bool active = true; char letter = 'a'; string message = \"hello\";");
        roundTrip("control-flow", "main() { if (true) { int x = 1; } else { x = 0; } while (x < 2) { x <- x + 1; } }");
        roundTrip("functions", "int f(int a) { return a; } p() { return; } main() { int x = f(1); p(); }");
        sameTreeAfterParens("parens-redundant vs plain");
        System.out.printf("%d checks, %d failures%n", tests, failures);
        if (failures != 0) {
            throw new AssertionError("AST tests failed");
        }
    }

    private static void expectTree(String basename, String source) throws IOException {
        ProgramNode program = parseValid(source);
        String actual = TREE.print(program);
        String expected = Files.readString(ROOT.resolve("esperado/" + basename + ".txt"), StandardCharsets.UTF_8)
                .replace("\r\n", "\n").stripTrailing();
        if (!actual.equals(expected)) {
            System.err.println("--- expected " + basename + " ---");
            System.err.println(expected);
            System.err.println("--- actual ---");
            System.err.println(actual);
        }
        check(actual.equals(expected), "tree " + basename);
    }

    private static void roundTrip(String name, String source) {
        ProgramNode first = parseValid(source);
        String printed = SOURCE.print(first);
        ProgramNode second = parseValid(printed);
        String again = SOURCE.print(second);
        check(again.equals(printed), "round-trip source " + name);
        check(withoutPositions(TREE.print(first)).equals(withoutPositions(TREE.print(second))),
                "round-trip tree " + name);
    }

    private static Path resolveTestRoot() {
        Path cwd = Path.of("").toAbsolutePath().normalize();
        if (Files.isRegularFile(cwd.resolve("test/esperado/five-types.txt"))) {
            return cwd.resolve("test");
        }
        Path nested = cwd.resolve("cp3-giovana/test/esperado/five-types.txt");
        if (Files.isRegularFile(nested)) {
            return cwd.resolve("cp3-giovana/test");
        }
        throw new IllegalStateException("Run AstTest from project root (test/esperado missing)");
    }

    private static void sameTreeAfterParens(String name) {
        ProgramNode withParens = parseValid("int x = (((a)));");
        ProgramNode plain = parseValid("int x = a;");
        check(withoutPositions(TREE.print(withParens)).equals(withoutPositions(TREE.print(plain))), name);
    }

    private static ProgramNode parseValid(String source) {
        Parser parser = new Parser(new Scanner(source).scanTokens());
        ParseResult result = parser.parseWithAst();
        if (!result.isValid()) {
            throw new AssertionError("expected valid parse: " + parser.getErros());
        }
        return result.getProgram();
    }

    private static String withoutPositions(String tree) {
        StringBuilder out = new StringBuilder();
        for (String line : tree.split("\n")) {
            if (!line.stripLeading().startsWith("@L")) {
                out.append(line).append('\n');
            }
        }
        return out.toString().stripTrailing();
    }

    private static void check(boolean condition, String name) {
        tests++;
        System.out.println((condition ? "PASS " : "FAIL ") + name);
        if (!condition) {
            failures++;
        }
    }
}
