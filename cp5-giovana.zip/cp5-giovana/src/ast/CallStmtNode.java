import java.util.List;

public final class CallStmtNode extends Node {
    private final String name;
    /** CP5: Symbol resolvido pela passada de identificação (null se não declarado). */
    private Symbol decl;
    private final List<Node> arguments;

    public CallStmtNode(String name, List<Node> arguments, int linha, int coluna) {
        super(linha, coluna);
        this.name = name;
        this.arguments = List.copyOf(arguments);
    }

    public String getName() {
        return name;
    }

    public Symbol getDecl() {
        return decl;
    }

    public void setDecl(Symbol decl) {
        this.decl = decl;
    }

    public List<Node> getArguments() {
        return arguments;
    }

    @Override
    public <T> T accept(Visitor<T> visitor) {
        return visitor.visitCallStmt(this);
    }
}
