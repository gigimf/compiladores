public abstract class Node {
    private final int linha;
    private final int coluna;
    /** CP5: tipo calculado pelo verificador (null até o TypeChecker passar). Só expressões o preenchem. */
    private TypeKind tipo;

    protected Node(int linha, int coluna) {
        this.linha = linha;
        this.coluna = coluna;
    }

    public int getLinha() {
        return linha;
    }

    public int getColuna() {
        return coluna;
    }

    public TypeKind getTipo() {
        return tipo;
    }

    public void setTipo(TypeKind tipo) {
        this.tipo = tipo;
    }

    public abstract <T> T accept(Visitor<T> visitor);
}
