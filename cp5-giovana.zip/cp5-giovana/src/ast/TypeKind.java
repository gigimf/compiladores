public enum TypeKind {
    INT, DOUBLE, BOOL, CHAR, STRING,
    /** CP5: tipo de procedimentos (não devolvem valor). Nunca aparece em declarações. */
    VOID,
    /** CP5: tipo de uma expressão já reportada como errada; compatível com tudo, sem nova mensagem. */
    ERRO;

    public static TypeKind fromToken(TipoToken token) {
        return switch (token) {
            case INT -> INT;
            case DOUBLE -> DOUBLE;
            case BOOL -> BOOL;
            case CHAR -> CHAR;
            case STRING_TYPE -> STRING;
            default -> throw new IllegalArgumentException("not a type token: " + token);
        };
    }

    public String keyword() {
        return switch (this) {
            case INT -> "int";
            case DOUBLE -> "double";
            case BOOL -> "bool";
            case CHAR -> "char";
            case STRING -> "string";
            case VOID -> "void";
            case ERRO -> "erro";
        };
    }
}
