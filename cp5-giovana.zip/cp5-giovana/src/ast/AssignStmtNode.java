public final class AssignStmtNode extends Node {
    private final String name;
    /** CP5: Symbol resolvido pela passada de identificação (null se não declarado). */
    private Symbol decl;
    private final AssignOp operator;
    private final Node expression;

    public AssignStmtNode(String name, AssignOp operator, Node expression, int linha, int coluna) {
        super(linha, coluna);
        this.name = name;
        this.operator = operator;
        this.expression = expression;
    }

    public String getName() {
        return name;
    }

    public Symbol getDecl() {
        return decl;
    }

    public void setDecl(Symbol decl) {
        this.decl = decl;
    }

    public AssignOp getOperator() {
        return operator;
    }

    public Node getExpression() {
        return expression;
    }

    @Override
    public <T> T accept(Visitor<T> visitor) {
        return visitor.visitAssignStmt(this);
    }
}
