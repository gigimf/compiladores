import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;

/** CLI do Checkpoint 5 (Léxico + Sintático + Identificação + Verificação de tipos). */
public final class Main {
    private Main() {}

    public static void main(String[] args) {
        if (args.length != 1) {
            System.err.println("Uso: java -cp out Main arquivo.smol");
            System.exit(2);
        }
        try {
            String source = Files.readString(Path.of(args[0]), StandardCharsets.UTF_8);
            Analise analise = Analise.executar(source);

            if (!analise.isSintaxeValida()) {
                analise.getErrosSintaticos().forEach(System.err::println);
                System.out.println("REJEITADO");
                System.exit(1);
            }

            analise.getMensagens().forEach(System.err::println);

            if (analise.temErros()) {
                System.out.println("REJEITADO"); // com erro, não segue para a geração de código
                System.exit(1);
            }
            System.out.println("ACEITO");
        } catch (IOException exception) {
            System.err.println("Falha ao ler arquivo: " + exception.getMessage());
            System.exit(2);
        }
    }
}
