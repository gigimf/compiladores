import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

/**
 * Pipeline de análise do compilador até o CP5: scanner -> parser -> identificação (CP4)
 * -> verificação de tipos (CP5). Usado pelo Main e pelos testes, para que ambos
 * rodem exatamente o mesmo caminho.
 *
 * Regras de execução:
 *  - erro léxico/sintático: para aqui (não existe AST confiável);
 *  - erros de identificação NÃO impedem o verificador de tipos: nomes sem declaração
 *    viram o tipo ERRO e não geram mensagem repetida (sem cascata);
 *  - com qualquer erro (de identificação ou de tipos) o compilador não segue para
 *    a geração de código; avisos não impedem.
 */
public final class Analise {
    private final List<String> errosSintaticos = new ArrayList<>();
    private final List<String> mensagens = new ArrayList<>();
    private boolean sintaxeValida;
    private boolean temErros;
    private ProgramNode programa;

    private Analise() {}

    /** Pilha da thread de análise: árvores muito profundas (a+a+a+... com milhares de termos) não estouram. */
    private static final long TAMANHO_PILHA = 256L * 1024 * 1024;

    public static Analise executar(String fonte) {
        Analise a = new Analise();
        Throwable[] falha = new Throwable[1];
        Thread thread = new Thread(null, () -> {
            try {
                a.rodar(fonte);
            } catch (Throwable e) {
                falha[0] = e;
            }
        }, "analise", TAMANHO_PILHA);
        thread.start();
        try {
            thread.join();
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new IllegalStateException("análise interrompida", e);
        }
        if (falha[0] instanceof StackOverflowError) {
            // Último recurso: entrada absurdamente profunda vira ERRO com mensagem, nunca falha do compilador.
            String msg = "entrada profunda demais para analisar";
            if (a.programa == null) {
                a.errosSintaticos.add(msg);
            } else {
                a.mensagens.add("linha 1: " + msg);
            }
            a.temErros = true;
        } else if (falha[0] instanceof RuntimeException) {
            throw (RuntimeException) falha[0];
        } else if (falha[0] instanceof Error) {
            throw (Error) falha[0];
        }
        return a;
    }

    private void rodar(String fonte) {
        Analise a = this;
        ByteArrayOutputStream captura = new ByteArrayOutputStream();
        PrintStream original = System.out;
        List<Token> tokens;
        try (PrintStream ps = new PrintStream(captura, true, StandardCharsets.UTF_8)) {
            System.setOut(ps);
            try {
                tokens = new Scanner(fonte).scanTokens();
            } finally {
                System.setOut(original);
            }
        }
        String lexicos = captura.toString(StandardCharsets.UTF_8);
        Parser parser = new Parser(tokens);
        ParseResult resultado = parser.parseWithAst();
        if (!lexicos.isEmpty()) {
            for (String linha : lexicos.split("\\R")) {
                if (!linha.isBlank()) {
                    a.errosSintaticos.add(linha);
                }
            }
        }
        a.errosSintaticos.addAll(parser.getErros());
        a.sintaxeValida = resultado.isValid() && lexicos.isEmpty();
        if (!a.sintaxeValida) {
            a.temErros = true;
            return;
        }
        a.programa = resultado.getProgram();

        IdentificationVisitor identificacao = new IdentificationVisitor();
        a.programa.accept(identificacao);
        a.mensagens.addAll(identificacao.getErros());

        TypeChecker tipos = new TypeChecker();
        a.programa.accept(tipos);
        a.mensagens.addAll(tipos.getMensagens());

        a.temErros = identificacao.hasErrors() || tipos.hasErrors();
    }

    public boolean isSintaxeValida() {
        return sintaxeValida;
    }

    public List<String> getErrosSintaticos() {
        return List.copyOf(errosSintaticos);
    }

    /** Erros de identificação, depois erros e avisos de tipos (cada grupo na ordem do texto). */
    public List<String> getMensagens() {
        return List.copyOf(mensagens);
    }

    /** true se qualquer fase reportou ERRO (avisos não contam): não gerar código. */
    public boolean temErros() {
        return temErros;
    }

    public ProgramNode getPrograma() {
        return programa;
    }
}
