/**
 * CP5 — Tabela de operadores e regras de compatibilidade (Parte 1, itens 1 e 2).
 *
 * Este é o ÚNICO lugar onde as regras de tipos dos operadores e da compatibilidade
 * de atribuição moram. O TypeChecker só pergunta a esta classe; assim cada linha
 * da tabela do papel (tipos-a-mao.pdf) tem uma linha de código correspondente e
 * pode ser testada sem passar pelo parser (OperatorTableTest).
 *
 * Convenções:
 *  - métodos devolvem null quando a combinação é RECUSADA;
 *  - TypeKind.ERRO em qualquer operando devolve ERRO (compatível com tudo, sem cascata);
 *  - TypeKind.VOID nunca é aceito como operando.
 */
public final class TabelaOperadores {
    private TabelaOperadores() {}

    /** char, int e double formam a família numérica; bool e string ficam de fora (Decisões 2, 3 e 4). */
    public static boolean ehNumerico(TypeKind t) {
        return t == TypeKind.CHAR || t == TypeKind.INT || t == TypeKind.DOUBLE;
    }

    /** Promoção aritmética: double se algum operando for double; caso contrário int (char vira int). */
    public static TypeKind promover(TypeKind a, TypeKind b) {
        return (a == TypeKind.DOUBLE || b == TypeKind.DOUBLE) ? TypeKind.DOUBLE : TypeKind.INT;
    }

    /** Operador binário: devolve o tipo do resultado, ou null se a combinação é recusada. */
    public static TypeKind binario(TipoToken op, TypeKind esq, TypeKind dir) {
        if (esq == TypeKind.ERRO || dir == TypeKind.ERRO) {
            return TypeKind.ERRO;
        }
        switch (op) {
            case MAIS:
            case MENOS:
            case VEZES:
            case DIVIDIR:
                // [ARIT]: numéricos -> promoção (char+char = int; int+int = int; qualquer double = double)
                return (ehNumerico(esq) && ehNumerico(dir)) ? promover(esq, dir) : null;
            case MENOR:
            case MENOR_IGUAL:
            case MAIOR:
            case MAIOR_IGUAL:
                // [REL]: só numéricos (string e bool não têm ordem); resultado bool
                return (ehNumerico(esq) && ehNumerico(dir)) ? TypeKind.BOOL : null;
            case IGUAL_IGUAL:
            case DIFERENTE:
                // [IGUAL]: numérico com numérico, ou bool com bool; string nunca (Decisão 4/5)
                if (ehNumerico(esq) && ehNumerico(dir)) {
                    return TypeKind.BOOL;
                }
                return (esq == TypeKind.BOOL && dir == TypeKind.BOOL) ? TypeKind.BOOL : null;
            default:
                return null;
        }
    }

    /** Operador unário: devolve o tipo do resultado, ou null se recusado. */
    public static TypeKind unario(TipoToken op, TypeKind t) {
        if (t == TypeKind.ERRO) {
            return TypeKind.ERRO;
        }
        switch (op) {
            case MENOS:
            case MAIS:
                // [UN-NUM]: numérico; char sobe para int
                return ehNumerico(t) ? promover(t, t) : null;
            case NAO:
                // [UN-NAO]: só bool
                return t == TypeKind.BOOL ? TypeKind.BOOL : null;
            default:
                return null;
        }
    }

    /**
     * Compatibilidade de atribuição (atribuição, inicializador, argumento e return):
     * um valor de tipo 'origem' pode ir para um lugar de tipo 'destino'?
     * Iguais; ou alargamento implícito char -> int -> double (Decisões 1, 2 e 8).
     * O inverso (double -> int, int -> char) é sempre recusado.
     */
    public static boolean compativel(TypeKind destino, TypeKind origem) {
        if (destino == TypeKind.ERRO || origem == TypeKind.ERRO) {
            return true;
        }
        if (destino == TypeKind.VOID || origem == TypeKind.VOID) {
            return false;
        }
        if (destino == origem) {
            return true;
        }
        if (destino == TypeKind.INT && origem == TypeKind.CHAR) {
            return true;
        }
        return destino == TypeKind.DOUBLE && (origem == TypeKind.INT || origem == TypeKind.CHAR);
    }

    /** Texto do operador nas mensagens de erro. */
    public static String simbolo(TipoToken op) {
        switch (op) {
            case MAIS: return "+";
            case MENOS: return "-";
            case VEZES: return "*";
            case DIVIDIR: return "/";
            case MENOR: return "<";
            case MENOR_IGUAL: return "<=";
            case MAIOR: return ">";
            case MAIOR_IGUAL: return ">=";
            case IGUAL_IGUAL: return "==";
            case DIFERENTE: return "!=";
            case NAO: return "!";
            default: return op.name();
        }
    }
}
