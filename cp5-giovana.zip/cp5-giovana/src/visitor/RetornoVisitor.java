/**
 * CP5 — Decisão 9: "return em todos os caminhos".
 *
 * Análise de fluxo mínima e conservadora: responde "este comando termina
 * SEMPRE com um return?". Regras:
 *   return                  -> sim
 *   bloco                   -> sim se ALGUM comando dele sempre retorna
 *   if com else             -> sim se os DOIS ramos sempre retornam
 *   if sem else, while      -> não (o corpo pode não executar)
 *   demais comandos         -> não
 * Não avalia condições (while (true) conta como "não"): conservador, nunca aceita
 * uma função que possa cair no fim sem valor.
 */
public final class RetornoVisitor implements Visitor<Boolean> {

    public boolean retornaSempre(Node node) {
        return node != null && Boolean.TRUE.equals(node.accept(this));
    }

    @Override public Boolean visitBlock(BlockNode node) {
        for (Node stmt : node.getStatements()) {
            if (retornaSempre(stmt)) {
                return true;
            }
        }
        return false;
    }

    @Override public Boolean visitReturnStmt(ReturnStmtNode node) {
        return true;
    }

    @Override public Boolean visitIfStmt(IfStmtNode node) {
        return node.hasElse() && retornaSempre(node.getThenBranch()) && retornaSempre(node.getElseBranch());
    }

    @Override public Boolean visitWhileStmt(WhileStmtNode node) {
        return false;
    }

    // Tudo que não é comando de controle nunca "retorna sempre".
    @Override public Boolean visitProgram(ProgramNode node) { return false; }
    @Override public Boolean visitVarDecl(VarDeclNode node) { return false; }
    @Override public Boolean visitFuncDecl(FuncDeclNode node) { return false; }
    @Override public Boolean visitProcDecl(ProcDeclNode node) { return false; }
    @Override public Boolean visitParam(ParamNode node) { return false; }
    @Override public Boolean visitAssignStmt(AssignStmtNode node) { return false; }
    @Override public Boolean visitCallStmt(CallStmtNode node) { return false; }
    @Override public Boolean visitIntLit(IntLitNode node) { return false; }
    @Override public Boolean visitFloatLit(FloatLitNode node) { return false; }
    @Override public Boolean visitBoolLit(BoolLitNode node) { return false; }
    @Override public Boolean visitCharLit(CharLitNode node) { return false; }
    @Override public Boolean visitStringLit(StringLitNode node) { return false; }
    @Override public Boolean visitIdent(IdentNode node) { return false; }
    @Override public Boolean visitBinOp(BinOpNode node) { return false; }
    @Override public Boolean visitUnaryOp(UnaryOpNode node) { return false; }
    @Override public Boolean visitCallExpr(CallExprNode node) { return false; }
}
