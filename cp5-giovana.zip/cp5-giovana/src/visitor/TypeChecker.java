import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * CP5 — Verificador de tipos (Aulas 12 a 14).
 *
 * Visitor<TypeKind> sobre a AST DECORADA pelo CP4: não usa instanceof nem switch
 * sobre o tipo do nó, não faz declare/openScope/closeScope (lê tudo de decl/Symbol).
 *
 *  - Expressão: devolve o tipo E o grava no nó (Node.setTipo) — é o que o gerador lerá.
 *  - Comando: devolve VOID.
 *  - Erros: acumulados com linha, nome/operador e tipos; nunca interrompem a passada.
 *  - Sem cascata: depois do primeiro erro o tipo ERRO sobe pela árvore; ele é
 *    compatível com tudo e não gera mensagem nova.
 *  - Avisos (variável possivelmente sem valor) NÃO impedem a compilação.
 *
 * ONDE FICA CADA REGRA DO PAPEL (rótulos de tipos-a-mao.pdf):
 *   [LIT-*]                 visitIntLit ... visitStringLit
 *   [ID], [ID-FUNC]         visitIdent
 *   [ARIT] [REL] [IGUAL]    visitBinOp   (tabela em TabelaOperadores.binario)
 *   [UN-NUM] [UN-NAO]       visitUnaryOp (TabelaOperadores.unario)
 *   [ATRIB] [INIT]          visitAssignStmt / visitVarDecl (TabelaOperadores.compativel)
 *   [IF] [WHILE]            visitIfStmt / visitWhileStmt
 *   [RET-*] [FUNC-RET]      visitReturnStmt / visitFuncDecl (+ RetornoVisitor)
 *   [CALL] [CALL-CMD]       conferirChamada, visitCallExpr / visitCallStmt
 *   Regra de avisos         semValor, visitIdent / visitVarDecl / visitAssignStmt / if / while
 */
public final class TypeChecker implements Visitor<TypeKind> {
    private final List<String> erros = new ArrayList<>();
    private final List<String> avisos = new ArrayList<>();
    private final List<String> mensagens = new ArrayList<>();
    private final RetornoVisitor retorno = new RetornoVisitor();

    // Contexto: rotina corrente (para conferir return). Não há laços para 'break' (a linguagem não tem break).
    private String rotinaAtual = null;
    private TypeKind retornoAtual = null;

    // Variáveis locais que PODEM ainda não ter valor neste ponto do fluxo (identidade do VarDeclNode).
    private Set<Node> semValor = new HashSet<>();

    // ---------------------------------------------------------------- resultado

    /** Apenas erros, no formato "linha L: mensagem", na ordem do texto. */
    public List<String> getErros() {
        return Collections.unmodifiableList(erros);
    }

    /** Apenas avisos, no formato "aviso linha L: mensagem". */
    public List<String> getAvisos() {
        return Collections.unmodifiableList(avisos);
    }

    /** Erros e avisos intercalados na ordem em que foram emitidos. */
    public List<String> getMensagens() {
        return Collections.unmodifiableList(mensagens);
    }

    public boolean hasErrors() {
        return !erros.isEmpty();
    }

    private void erro(int linha, String msg) {
        String texto = "linha " + linha + ": " + msg;
        erros.add(texto);
        mensagens.add(texto);
    }

    private void aviso(int linha, String msg) {
        String texto = "aviso linha " + linha + ": " + msg;
        avisos.add(texto);
        mensagens.add(texto);
    }

    private static String tp(TypeKind t) {
        return t == null ? "erro" : t.keyword();
    }

    /** Visita um filho tolerando null (AST vinda de recuperação do parser) -> ERRO silencioso. */
    private TypeKind tipoDe(Node filho) {
        if (filho == null) {
            return TypeKind.ERRO;
        }
        TypeKind t = filho.accept(this);
        return t == null ? TypeKind.ERRO : t;
    }

    private static Set<Node> uniao(Set<Node> a, Set<Node> b) {
        Set<Node> u = new HashSet<>(a);
        u.addAll(b);
        return u;
    }

    // ---------------------------------------------------------------- declarações

    @Override
    public TypeKind visitProgram(ProgramNode node) {
        for (Node decl : node.getDeclarations()) {
            tipoDe(decl);
        }
        return TypeKind.VOID;
    }

    @Override
    public TypeKind visitVarDecl(VarDeclNode node) {
        if (node.hasInitializer()) {
            // inicializador conferido ANTES de declarar o nome (mesma ordem do CP4)
            TypeKind t = tipoDe(node.getInitializer());
            if (!TabelaOperadores.compativel(node.getType(), t)) {
                erro(node.getLinha(), "inicializador de '" + node.getName() + "': esperado "
                        + tp(node.getType()) + ", veio " + tp(t));
            }
        } else if (rotinaAtual != null) {
            // Regra de avisos: local sem valor inicial passa a ser rastreada. Globais não (podem ser
            // atribuídas por qualquer rotina; sem análise inter-procedural, não avisamos).
            semValor.add(node);
        }
        return TypeKind.VOID;
    }

    @Override
    public TypeKind visitFuncDecl(FuncDeclNode node) {
        String rotinaAnterior = rotinaAtual;
        TypeKind retornoAnterior = retornoAtual;
        Set<Node> semValorAnterior = semValor;
        rotinaAtual = node.getName();
        retornoAtual = node.getReturnType();
        semValor = new HashSet<>();

        tipoDe(node.getBody());
        // Decisão 9: análise de fluxo — todo caminho precisa terminar em return.
        if (!retorno.retornaSempre(node.getBody())) {
            erro(node.getLinha(), "função '" + node.getName() + "' pode terminar sem return");
        }

        rotinaAtual = rotinaAnterior;
        retornoAtual = retornoAnterior;
        semValor = semValorAnterior;
        return TypeKind.VOID;
    }

    @Override
    public TypeKind visitProcDecl(ProcDeclNode node) {
        String rotinaAnterior = rotinaAtual;
        TypeKind retornoAnterior = retornoAtual;
        Set<Node> semValorAnterior = semValor;
        rotinaAtual = node.getName();
        retornoAtual = TypeKind.VOID;
        semValor = new HashSet<>();

        tipoDe(node.getBody());

        rotinaAtual = rotinaAnterior;
        retornoAtual = retornoAnterior;
        semValor = semValorAnterior;
        return TypeKind.VOID;
    }

    @Override
    public TypeKind visitParam(ParamNode node) {
        return TypeKind.VOID; // assinatura já está no Symbol da rotina
    }

    // ---------------------------------------------------------------- comandos

    @Override
    public TypeKind visitBlock(BlockNode node) {
        for (Node stmt : node.getStatements()) {
            tipoDe(stmt);
        }
        return TypeKind.VOID;
    }

    @Override
    public TypeKind visitAssignStmt(AssignStmtNode node) {
        TypeKind t = tipoDe(node.getExpression()); // lado direito primeiro: "x = x + 1" usa o x antigo
        Symbol alvo = node.getDecl();
        if (alvo == null) {
            return TypeKind.VOID; // não declarado: CP4 já reportou
        }
        if (alvo.getCategory() == SymbolCategory.FUNCTION || alvo.getCategory() == SymbolCategory.PROCEDURE) {
            erro(node.getLinha(), "'" + node.getName() + "' não é variável e não pode receber atribuição");
            return TypeKind.VOID;
        }
        TypeKind destino = alvo.getType() == null ? TypeKind.ERRO : alvo.getType();
        if (!TabelaOperadores.compativel(destino, t)) {
            erro(node.getLinha(), "atribuição a '" + node.getName() + "': esperado " + tp(destino)
                    + ", veio " + tp(t));
        }
        semValor.remove(alvo.getDeclNode()); // agora tem valor neste caminho
        return TypeKind.VOID;
    }

    @Override
    public TypeKind visitCallStmt(CallStmtNode node) {
        // Decisão 6: valor de função usada como comando é descartado (sem erro).
        conferirChamada(node.getName(), node.getDecl(), node.getArguments(), node.getLinha());
        return TypeKind.VOID;
    }

    @Override
    public TypeKind visitIfStmt(IfStmtNode node) {
        TypeKind c = tipoDe(node.getCondition());
        if (c != TypeKind.BOOL && c != TypeKind.ERRO) {
            erro(node.getLinha(), "condição de 'if' deve ser bool, mas é " + tp(c));
        }
        Set<Node> antes = new HashSet<>(semValor);
        tipoDe(node.getThenBranch());
        Set<Node> aposThen = semValor;
        semValor = new HashSet<>(antes);
        if (node.hasElse()) {
            tipoDe(node.getElseBranch());
        }
        // Conservador: sem valor se faltar em QUALQUER um dos caminhos.
        semValor = uniao(aposThen, semValor);
        return TypeKind.VOID;
    }

    @Override
    public TypeKind visitWhileStmt(WhileStmtNode node) {
        TypeKind c = tipoDe(node.getCondition());
        if (c != TypeKind.BOOL && c != TypeKind.ERRO) {
            erro(node.getLinha(), "condição de 'while' deve ser bool, mas é " + tp(c));
        }
        Set<Node> antes = new HashSet<>(semValor);
        tipoDe(node.getBody());
        semValor = uniao(antes, semValor); // o corpo pode não executar nenhuma vez
        return TypeKind.VOID;
    }

    @Override
    public TypeKind visitReturnStmt(ReturnStmtNode node) {
        TypeKind t = node.hasValue() ? tipoDe(node.getValue()) : null;
        if (retornoAtual == null) {
            return TypeKind.VOID; // fora de rotina: a gramática não permite; defensivo
        }
        if (retornoAtual == TypeKind.VOID) {
            if (node.hasValue()) {
                erro(node.getLinha(), "return em procedimento '" + rotinaAtual + "' não deve ter valor");
            }
        } else if (!node.hasValue()) {
            erro(node.getLinha(), "return em '" + rotinaAtual + "': esperado " + tp(retornoAtual)
                    + ", mas não há valor");
        } else if (!TabelaOperadores.compativel(retornoAtual, t)) {
            erro(node.getLinha(), "return em '" + rotinaAtual + "': esperado " + tp(retornoAtual)
                    + ", veio " + tp(t));
        }
        return TypeKind.VOID;
    }

    // ---------------------------------------------------------------- expressões

    private TypeKind grava(Node node, TypeKind t) {
        node.setTipo(t);
        return t;
    }

    @Override public TypeKind visitIntLit(IntLitNode node) { return grava(node, TypeKind.INT); }
    @Override public TypeKind visitFloatLit(FloatLitNode node) { return grava(node, TypeKind.DOUBLE); }
    @Override public TypeKind visitBoolLit(BoolLitNode node) { return grava(node, TypeKind.BOOL); }
    @Override public TypeKind visitCharLit(CharLitNode node) { return grava(node, TypeKind.CHAR); }
    @Override public TypeKind visitStringLit(StringLitNode node) { return grava(node, TypeKind.STRING); }

    @Override
    public TypeKind visitIdent(IdentNode node) {
        Symbol d = node.getDecl();
        if (d == null) {
            return grava(node, TypeKind.ERRO); // não declarado: já reportado pelo CP4
        }
        if (d.getCategory() == SymbolCategory.FUNCTION) {
            // Decisão 11: nome de função sem parênteses é erro (não há função como valor)
            erro(node.getLinha(), "'" + node.getName() + "' é função e não pode ser usada como valor (faltam parênteses)");
            return grava(node, TypeKind.ERRO);
        }
        if (d.getCategory() == SymbolCategory.PROCEDURE) {
            erro(node.getLinha(), "'" + node.getName() + "' é procedimento e não pode ser usado como valor");
            return grava(node, TypeKind.ERRO);
        }
        if (semValor.contains(d.getDeclNode())) {
            aviso(node.getLinha(), "variável '" + node.getName() + "' pode ser usada sem valor");
            semValor.remove(d.getDeclNode()); // um aviso por caminho basta
        }
        return grava(node, d.getType() == null ? TypeKind.ERRO : d.getType());
    }

    @Override
    public TypeKind visitBinOp(BinOpNode node) {
        TypeKind esq = tipoDe(node.getLeft());
        TypeKind dir = tipoDe(node.getRight());
        TypeKind r = TabelaOperadores.binario(node.getOperator(), esq, dir);
        if (r == null) {
            erro(node.getLinha(), "operador '" + TabelaOperadores.simbolo(node.getOperator())
                    + "' não se aplica a " + tp(esq) + " e " + tp(dir));
            r = TypeKind.ERRO;
        }
        return grava(node, r);
    }

    @Override
    public TypeKind visitUnaryOp(UnaryOpNode node) {
        TypeKind t = tipoDe(node.getOperand());
        TypeKind r = TabelaOperadores.unario(node.getOperator(), t);
        if (r == null) {
            erro(node.getLinha(), "operador '" + TabelaOperadores.simbolo(node.getOperator())
                    + "' não se aplica a " + tp(t));
            r = TypeKind.ERRO;
        }
        return grava(node, r);
    }

    @Override
    public TypeKind visitCallExpr(CallExprNode node) {
        TypeKind r = conferirChamada(node.getName(), node.getDecl(), node.getArguments(), node.getLinha());
        if (r == TypeKind.VOID) {
            erro(node.getLinha(), "procedimento '" + node.getName()
                    + "' não devolve valor e não pode ser usado em expressão");
            r = TypeKind.ERRO;
        }
        return grava(node, r);
    }

    /**
     * Regras [CALL]/[CALL-CMD]: o nome é rotina? a aridade bate? cada argumento é compatível
     * com o parâmetro (Decisão 8: int->double aceito, inverso não)? Devolve o tipo de retorno
     * (VOID para procedimento, ERRO se a chamada já está errada ou o nome não resolveu).
     * Os argumentos são sempre visitados, para que erros dentro deles apareçam e os nós recebam tipo.
     */
    private TypeKind conferirChamada(String nome, Symbol d, List<Node> args, int linha) {
        List<TypeKind> tipos = new ArrayList<>();
        for (Node arg : args) {
            tipos.add(tipoDe(arg));
        }
        if (d == null) {
            return TypeKind.ERRO; // não declarado: já reportado pelo CP4
        }
        if (d.getCategory() != SymbolCategory.FUNCTION && d.getCategory() != SymbolCategory.PROCEDURE) {
            erro(linha, "'" + nome + "' não é função");
            return TypeKind.ERRO;
        }
        List<TypeKind> esperados = d.getParamTypes();
        if (esperados.size() != args.size()) {
            erro(linha, "'" + nome + "' espera " + esperados.size() + " argumento(s), recebeu " + args.size());
            return d.getReturnType(); // o tipo da chamada continua conhecido: evita cascata
        }
        for (int i = 0; i < args.size(); i++) {
            if (!TabelaOperadores.compativel(esperados.get(i), tipos.get(i))) {
                Node arg = args.get(i);
                erro(arg == null ? linha : arg.getLinha(), "argumento " + (i + 1) + " de '" + nome
                        + "': esperado " + tp(esperados.get(i)) + ", veio " + tp(tipos.get(i)));
            }
        }
        return d.getReturnType();
    }
}
