/**
 * CP5 — Parte 3: as regras de tipos ISOLADAS, sem passar pelo parser.
 *
 * Cada linha das tabelas abaixo é uma linha da "tabela de operadores" de tipos-a-mao.pdf,
 * escrita À MÃO a partir das regras (não gerada pelo código). Convenção das células:
 *   c = char, i = int, d = double, b = bool, s = string  -> tipo do resultado
 *   X = combinação recusada
 * Colunas e linhas seguem a ordem  char, int, double, bool, string.
 */
public class OperatorTableTest {
    private static int tests = 0;
    private static int failures = 0;

    private static final TypeKind[] T = {
        TypeKind.CHAR, TypeKind.INT, TypeKind.DOUBLE, TypeKind.BOOL, TypeKind.STRING
    };
    private static final String[] NOME = {"char", "int", "double", "bool", "string"};

    public static void main(String[] args) {
        // [ARIT]  +  -  *  /   (char+char = int: a aritmética promove para int)
        String[] arit = {
            /* char   */ "iidXX",
            /* int    */ "iidXX",
            /* double */ "dddXX",
            /* bool   */ "XXXXX",
            /* string */ "XXXXX",
        };
        for (TipoToken op : new TipoToken[] {TipoToken.MAIS, TipoToken.MENOS, TipoToken.VEZES, TipoToken.DIVIDIR}) {
            binario("ARIT", op, arit);
        }

        // [REL]  <  <=  >  >=   (só numéricos; resultado bool)
        String[] rel = {
            /* char   */ "bbbXX",
            /* int    */ "bbbXX",
            /* double */ "bbbXX",
            /* bool   */ "XXXXX",
            /* string */ "XXXXX",
        };
        for (TipoToken op : new TipoToken[] {TipoToken.MENOR, TipoToken.MENOR_IGUAL, TipoToken.MAIOR, TipoToken.MAIOR_IGUAL}) {
            binario("REL", op, rel);
        }

        // [IGUAL]  ==  !=   (numérico com numérico; bool com bool; string nunca)
        String[] igual = {
            /* char   */ "bbbXX",
            /* int    */ "bbbXX",
            /* double */ "bbbXX",
            /* bool   */ "XXXbX",
            /* string */ "XXXXX",
        };
        for (TipoToken op : new TipoToken[] {TipoToken.IGUAL_IGUAL, TipoToken.DIFERENTE}) {
            binario("IGUAL", op, igual);
        }

        // [UN-NUM]  -  +   (char sobe para int)      [UN-NAO]  !
        unario("UN-NUM", TipoToken.MENOS, "iidXX");
        unario("UN-NUM", TipoToken.MAIS, "iidXX");
        unario("UN-NAO", TipoToken.NAO, "XXXbX");

        // Compatibilidade de atribuição: linha = destino, coluna = origem; "ok" = aceita.
        // Alargamento char -> int -> double; nunca o inverso. (Decisões 1, 2 e 8)
        String[] compat = {
            /* destino char   */ "oXXXX",
            /* destino int    */ "ooXXX",
            /* destino double */ "oooXX",
            /* destino bool   */ "XXXoX",
            /* destino string */ "XXXXo",
        };
        for (int dst = 0; dst < 5; dst++) {
            for (int src = 0; src < 5; src++) {
                boolean esperado = compat[dst].charAt(src) == 'o';
                check(TabelaOperadores.compativel(T[dst], T[src]) == esperado,
                        "COMPAT " + NOME[dst] + " <- " + NOME[src] + (esperado ? " aceita" : " recusada"));
            }
        }

        // Tipo de erro: compatível com tudo e contagioso, sem exceção e sem mensagem
        for (TypeKind t : T) {
            check(TabelaOperadores.compativel(TypeKind.ERRO, t) && TabelaOperadores.compativel(t, TypeKind.ERRO),
                    "ERRO compativel com " + t.keyword());
            check(TabelaOperadores.binario(TipoToken.MAIS, TypeKind.ERRO, t) == TypeKind.ERRO
                    && TabelaOperadores.binario(TipoToken.IGUAL_IGUAL, t, TypeKind.ERRO) == TypeKind.ERRO,
                    "ERRO contagia operador binario com " + t.keyword());
            check(TabelaOperadores.unario(TipoToken.NAO, TypeKind.ERRO) == TypeKind.ERRO, "ERRO contagia unario");
        }
        // void nunca é valor
        check(!TabelaOperadores.compativel(TypeKind.INT, TypeKind.VOID), "void nao cabe em int");
        check(TabelaOperadores.binario(TipoToken.MAIS, TypeKind.VOID, TypeKind.INT) == null, "void + int recusado");
        // operadores que não existem na linguagem são recusados, sem exceção
        check(TabelaOperadores.binario(TipoToken.IF, TypeKind.INT, TypeKind.INT) == null, "token qualquer recusado");
        check(TabelaOperadores.unario(TipoToken.VEZES, TypeKind.INT) == null, "unario inexistente recusado");

        System.out.printf("OperatorTableTest: %d checks, %d failures%n", tests, failures);
        if (failures != 0) {
            throw new AssertionError("Falhas na tabela de operadores");
        }
    }

    private static void binario(String regra, TipoToken op, String[] tabela) {
        for (int l = 0; l < 5; l++) {
            for (int r = 0; r < 5; r++) {
                TypeKind obtido = TabelaOperadores.binario(op, T[l], T[r]);
                char esperado = tabela[l].charAt(r);
                check(confere(obtido, esperado), "[" + regra + "] " + NOME[l] + " " + TabelaOperadores.simbolo(op)
                        + " " + NOME[r] + (esperado == 'X' ? " recusado" : " -> " + esperado));
            }
        }
    }

    private static void unario(String regra, TipoToken op, String tabela) {
        for (int t = 0; t < 5; t++) {
            TypeKind obtido = TabelaOperadores.unario(op, T[t]);
            char esperado = tabela.charAt(t);
            check(confere(obtido, esperado), "[" + regra + "] " + TabelaOperadores.simbolo(op) + " "
                    + NOME[t] + (esperado == 'X' ? " recusado" : " -> " + esperado));
        }
    }

    private static boolean confere(TypeKind obtido, char esperado) {
        if (esperado == 'X') {
            return obtido == null;
        }
        return obtido != null && obtido.keyword().charAt(0) == esperado;
    }

    private static void check(boolean cond, String name) {
        tests++;
        if (cond) {
            // Para não inundar a saída, só as falhas são impressas linha a linha.
        } else {
            System.out.println("FAIL " + name);
            failures++;
        }
    }
}
