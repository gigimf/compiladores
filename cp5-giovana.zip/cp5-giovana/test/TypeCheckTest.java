import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

/**
 * CP5 — Parte 3: programas completos contra saídas esperadas ESCRITAS À MÃO.
 *
 *  - cada test/programas/X.txt roda pelo pipeline real (scanner, parser, identificação, tipos);
 *  - a saída é comparada com test/esperado/X.txt (uma mensagem por linha, ou "sem mensagens");
 *  - programa sem erro nas mensagens (só avisos) precisa ser ACEITO; com erro, REJEITADO;
 *  - mais: tipo gravado nos nós, robustez (nenhuma entrada lança exceção) e regra
 *    "sem instanceof/switch sobre nós" conferida no código-fonte do verificador.
 */
public class TypeCheckTest {
    private static int tests = 0;
    private static int failures = 0;
    private static final Path ROOT = resolveRoot();

    public static void main(String[] args) throws IOException {
        testProgramas();
        testTiposGravadosNosNos();
        testRobustez();
        testSemInstanceof();

        System.out.printf("TypeCheckTest: %d checks, %d failures%n", tests, failures);
        if (failures != 0) {
            throw new AssertionError("Falhas nos testes do verificador de tipos");
        }
    }

    // ------------------------------------------------------------ programas x esperado

    private static void testProgramas() throws IOException {
        List<Path> programas = new ArrayList<>();
        try (Stream<Path> s = Files.list(ROOT.resolve("test/programas"))) {
            s.filter(p -> p.getFileName().toString().endsWith(".txt")).sorted().forEach(programas::add);
        }
        check(programas.size() >= 20, "ha programas de teste suficientes (" + programas.size() + ")");
        for (Path programa : programas) {
            String nome = programa.getFileName().toString();
            Path esperadoPath = ROOT.resolve("test/esperado/" + nome);
            check(Files.exists(esperadoPath), nome + " tem arquivo de saida esperada");
            if (!Files.exists(esperadoPath)) {
                continue;
            }
            String fonte = Files.readString(programa, StandardCharsets.UTF_8);
            Analise analise = Analise.executar(fonte);
            check(analise.isSintaxeValida(), nome + " e sintaticamente valido " + analise.getErrosSintaticos());

            List<String> msgs = analise.getMensagens();
            String obtido = msgs.isEmpty() ? "sem mensagens" : String.join("\n", msgs);
            String esperado = Files.readString(esperadoPath, StandardCharsets.UTF_8)
                    .replace("\r\n", "\n").stripTrailing();
            if (!obtido.equals(esperado)) {
                System.err.println("--- esperado " + nome + " ---\n" + esperado + "\n--- obtido ---\n" + obtido);
            }
            check(obtido.equals(esperado), "mensagens " + nome);

            // erro bloqueia a geração de código; aviso e "sem mensagens" não bloqueiam
            boolean esperaErro = esperado.lines().anyMatch(l -> l.startsWith("linha "));
            check(analise.temErros() == esperaErro, nome + (esperaErro ? " e REJEITADO" : " e ACEITO"));
        }
    }

    // ------------------------------------------------------------ tipo gravado em cada expressão

    private static void testTiposGravadosNosNos() {
        String fonte = "int i = 1;\n"
                + "double d = i + 2.5;\n"
                + "bool b = i < 3;\n"
                + "char c = 'x';\n"
                + "int j = c + 1;\n"
                + "string s = \"t\";\n"
                + "bool n = !b;\n"
                + "int k = -i;\n"
                + "int e = -true;\n";
        Analise a = Analise.executar(fonte);
        check(a.isSintaxeValida(), "fonte de tipos gravados e valido");
        List<Node> decls = a.getPrograma().getDeclarations();
        TypeKind[] esperados = {
            TypeKind.INT,    // 1
            TypeKind.DOUBLE, // i + 2.5
            TypeKind.BOOL,   // i < 3
            TypeKind.CHAR,   // 'x'
            TypeKind.INT,    // c + 1
            TypeKind.STRING, // "t"
            TypeKind.BOOL,   // !b
            TypeKind.INT,    // -i
            TypeKind.ERRO,   // -true (recusado: sobe como tipo de erro)
        };
        check(decls.size() == esperados.length, "nove declaracoes globais");
        for (int k = 0; k < esperados.length && k < decls.size(); k++) {
            VarDeclNode v = (VarDeclNode) decls.get(k);
            TypeKind obtido = v.getInitializer().getTipo();
            check(obtido == esperados[k], "tipo gravado no inicializador de '" + v.getName() + "': "
                    + (obtido == null ? "null" : obtido.keyword()));
        }
        check(a.getMensagens().size() == 1 && a.getMensagens().get(0).equals("linha 9: operador '-' não se aplica a bool"),
                "-true gera uma unica mensagem: " + a.getMensagens());
    }

    // ------------------------------------------------------------ robustez

    private static void testRobustez() {
        String[] entradas = {
            "",
            "main() { }",
            "int ;;; )",
            "main() { x(); y = z; return 1 + ; }",
            "int f(int a, int a) { return a; } main() { f(1); f(1, 2, 3); }",
            "int f() { return f; } main() { f(f(f)); }",
            "main() { int a = a; a = a + a; }",
            "int x = x;",
            "double d = 1/0; int y = 'ab';",
            "\"nao fechada",
            "/* sem fim",
        };
        for (String entrada : entradas) {
            boolean ok;
            try {
                Analise.executar(entrada);
                ok = true;
            } catch (RuntimeException | StackOverflowError e) {
                System.err.println("Excecao em '" + entrada + "': " + e);
                ok = false;
            }
            check(ok, "entrada nao lanca excecao: " + entrada.replace("\n", " "));
        }
        // expressão longa: sem laço infinito nem estouro
        StringBuilder sb = new StringBuilder("int x = 1");
        for (int k = 0; k < 50000; k++) {
            sb.append(" + 1");
        }
        sb.append(";");
        boolean ok;
        try {
            Analise a = Analise.executar(sb.toString());
            ok = a.isSintaxeValida() && !a.temErros();
        } catch (RuntimeException | StackOverflowError e) {
            ok = false;
        }
        check(ok, "expressao com 50000 somas e aceita");
        // parênteses aninhados fundo
        StringBuilder par = new StringBuilder("int y = ");
        for (int k = 0; k < 3000; k++) {
            par.append('(');
        }
        par.append('1');
        for (int k = 0; k < 3000; k++) {
            par.append(')');
        }
        par.append(';');
        try {
            Analise ap = Analise.executar(par.toString());
            ok = ap.isSintaxeValida() && !ap.temErros();
        } catch (RuntimeException | StackOverflowError e) {
            ok = false;
        }
        check(ok, "3000 parenteses aninhados sao aceitos");
        // ordem do texto: dois programas com erros em linhas crescentes
        Analise a = Analise.executar("main() {\n int a = true;\n int b = 1.5;\n }");
        check(a.getMensagens().equals(List.of(
                "linha 2: inicializador de 'a': esperado int, veio bool",
                "linha 3: inicializador de 'b': esperado int, veio double")), "erros na ordem do texto");
    }

    // ------------------------------------------------------------ regra de projeto do Visitor

    private static void testSemInstanceof() throws IOException {
        for (String arq : new String[] {"src/visitor/TypeChecker.java", "src/visitor/RetornoVisitor.java"}) {
            String codigo = Files.readString(ROOT.resolve(arq), StandardCharsets.UTF_8);
            String semComentarios = codigo.replaceAll("(?s)/\\*.*?\\*/", "").replaceAll("//[^\n]*", "");
            check(!semComentarios.contains("instanceof"), arq + " sem instanceof");
            check(!semComentarios.contains("switch"), arq + " sem switch");
            check(!semComentarios.contains("getClass"), arq + " sem getClass");
            check(!semComentarios.contains("openScope") && !semComentarios.contains("closeScope")
                    && !semComentarios.contains(".declare("), arq + " nao mexe em escopos");
        }
    }

    private static Path resolveRoot() {
        Path cwd = Path.of("").toAbsolutePath().normalize();
        if (Files.isDirectory(cwd.resolve("test/programas"))) {
            return cwd;
        }
        if (Files.isDirectory(cwd.resolve("cp5-giovana/test/programas"))) {
            return cwd.resolve("cp5-giovana");
        }
        throw new IllegalStateException("Nao foi possivel localizar o diretorio raiz do projeto cp5");
    }

    private static void check(boolean cond, String name) {
        tests++;
        if (cond) {
            System.out.println("PASS " + name);
        } else {
            System.out.println("FAIL " + name);
            failures++;
        }
    }
}
